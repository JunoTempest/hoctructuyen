import 'package:flutter/material.dart';
import '../constants/app_enums.dart';
import '../../app/theme/app_theme.dart';

class RoleSelector extends StatelessWidget {
  const RoleSelector({
    super.key,
    required this.selected,
    required this.onChanged,
  });

  final UserRole selected;
  final ValueChanged<UserRole> onChanged;

  // Chỉ student và teacher được tự đăng ký
  static const _roles = [UserRole.student, UserRole.teacher];

  @override
  Widget build(BuildContext context) {
    return Row(
      children: _roles.map((role) {
        final isSelected = selected == role;
        return Expanded(
          child: GestureDetector(
            onTap: () => onChanged(role),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.only(right: 8),
              padding: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                color: isSelected
                    ? role.color.withOpacity(0.1)
                    : AppColors.surfaceVariant,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isSelected ? role.color : AppColors.border,
                  width: isSelected ? 2 : 1,
                ),
              ),
              child: Column(
                children: [
                  Icon(role.icon,
                      color: isSelected ? role.color : AppColors.textSub,
                      size: 22),
                  const SizedBox(height: 4),
                  Text(role.label,
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: isSelected
                              ? role.color
                              : AppColors.textSub)),
                ],
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}
