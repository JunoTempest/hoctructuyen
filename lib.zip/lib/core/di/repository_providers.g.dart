// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'repository_providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(authRepository)
const authRepositoryProvider = AuthRepositoryProvider._();

final class AuthRepositoryProvider
    extends $FunctionalProvider<AuthRepository, AuthRepository, AuthRepository>
    with $Provider<AuthRepository> {
  const AuthRepositoryProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'authRepositoryProvider',
          isAutoDispose: false,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$authRepositoryHash();

  @$internal
  @override
  $ProviderElement<AuthRepository> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  AuthRepository create(Ref ref) {
    return authRepository(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AuthRepository value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AuthRepository>(value),
    );
  }
}

String _$authRepositoryHash() => r'f628514fb6d06c2b1fea9a0a5e36f1f6c63acb18';

@ProviderFor(schedulingRepository)
const schedulingRepositoryProvider = SchedulingRepositoryProvider._();

final class SchedulingRepositoryProvider extends $FunctionalProvider<
    SchedulingRepository,
    SchedulingRepository,
    SchedulingRepository> with $Provider<SchedulingRepository> {
  const SchedulingRepositoryProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'schedulingRepositoryProvider',
          isAutoDispose: false,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$schedulingRepositoryHash();

  @$internal
  @override
  $ProviderElement<SchedulingRepository> $createElement(
          $ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  SchedulingRepository create(Ref ref) {
    return schedulingRepository(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(SchedulingRepository value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<SchedulingRepository>(value),
    );
  }
}

String _$schedulingRepositoryHash() =>
    r'017506fd8fa5391999f23e8371d5dee79db2f302';

@ProviderFor(courseRepository)
const courseRepositoryProvider = CourseRepositoryProvider._();

final class CourseRepositoryProvider extends $FunctionalProvider<
    CourseRepository,
    CourseRepository,
    CourseRepository> with $Provider<CourseRepository> {
  const CourseRepositoryProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'courseRepositoryProvider',
          isAutoDispose: false,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$courseRepositoryHash();

  @$internal
  @override
  $ProviderElement<CourseRepository> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  CourseRepository create(Ref ref) {
    return courseRepository(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(CourseRepository value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<CourseRepository>(value),
    );
  }
}

String _$courseRepositoryHash() => r'56e71a1073118fda904a6a88e855c7958dc5e10e';
