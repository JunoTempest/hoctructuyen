import 'package:riverpod_annotation/riverpod_annotation.dart';

import '../../features/auth/domain/usecases/auth_usecases.dart';
import '../../features/courses/domain/usecases/course_usecases.dart';
import '../../features/scheduling/domain/usecases/scheduling_usecases.dart';
import 'repository_providers.dart';

part 'usecase_providers.g.dart';

// Auth
@riverpod
LoginUseCase loginUseCase(Ref ref) =>
    LoginUseCase(ref.read(authRepositoryProvider));

@riverpod
RegisterUseCase registerUseCase(Ref ref) =>
    RegisterUseCase(ref.read(authRepositoryProvider));

@riverpod
LogoutUseCase logoutUseCase(Ref ref) =>
    LogoutUseCase(ref.read(authRepositoryProvider));

// Scheduling
@riverpod
GetTeacherSchedulesUseCase getTeacherSchedulesUseCase(Ref ref) =>
    GetTeacherSchedulesUseCase(ref.read(schedulingRepositoryProvider));

@riverpod
WatchTeacherSchedulesUseCase watchTeacherSchedulesUseCase(Ref ref) =>
    WatchTeacherSchedulesUseCase(ref.read(schedulingRepositoryProvider));

@riverpod
GetAvailableSchedulesUseCase getAvailableSchedulesUseCase(Ref ref) =>
    GetAvailableSchedulesUseCase(ref.read(schedulingRepositoryProvider));

@riverpod
CreateScheduleUseCase createScheduleUseCase(Ref ref) =>
    CreateScheduleUseCase(ref.read(schedulingRepositoryProvider));

@riverpod
CreateBookingUseCase createBookingUseCase(Ref ref) =>
    CreateBookingUseCase(ref.read(schedulingRepositoryProvider));

@riverpod
ConfirmBookingUseCase confirmBookingUseCase(Ref ref) =>
    ConfirmBookingUseCase(ref.read(schedulingRepositoryProvider));

@riverpod
CancelBookingUseCase cancelBookingUseCase(Ref ref) =>
    CancelBookingUseCase(ref.read(schedulingRepositoryProvider));

@riverpod
WatchUserBookingsUseCase watchUserBookingsUseCase(Ref ref) =>
    WatchUserBookingsUseCase(ref.read(schedulingRepositoryProvider));

@riverpod
WatchUserSessionsUseCase watchUserSessionsUseCase(Ref ref) =>
    WatchUserSessionsUseCase(ref.read(schedulingRepositoryProvider));

// Courses
@riverpod
GetOpenCoursesUseCase getOpenCoursesUseCase(Ref ref) =>
    GetOpenCoursesUseCase(ref.read(courseRepositoryProvider));

@riverpod
GetCourseUseCase getCourseUseCase(Ref ref) =>
    GetCourseUseCase(ref.read(courseRepositoryProvider));

@riverpod
CreateCourseUseCase createCourseUseCase(Ref ref) =>
    CreateCourseUseCase(ref.read(courseRepositoryProvider));

@riverpod
EnrollCourseUseCase enrollCourseUseCase(Ref ref) =>
    EnrollCourseUseCase(ref.read(courseRepositoryProvider));

@riverpod
ConfirmEnrollmentUseCase confirmEnrollmentUseCase(Ref ref) =>
    ConfirmEnrollmentUseCase(ref.read(courseRepositoryProvider));

@riverpod
CancelEnrollmentUseCase cancelEnrollmentUseCase(Ref ref) =>
    CancelEnrollmentUseCase(ref.read(courseRepositoryProvider));

@riverpod
WatchStudentEnrollmentsUseCase watchStudentEnrollmentsUseCase(Ref ref) =>
    WatchStudentEnrollmentsUseCase(ref.read(courseRepositoryProvider));
