import 'package:riverpod_annotation/riverpod_annotation.dart';

import '../../features/auth/data/repositories/auth_repository_impl.dart';
import '../../features/auth/domain/repositories/auth_repository.dart';
import '../../features/courses/data/repositories/course_repository_impl.dart';
import '../../features/courses/domain/repositories/course_repository.dart';
import '../../features/scheduling/data/repositories/scheduling_repository_impl.dart';
import '../../features/scheduling/domain/repositories/scheduling_repository.dart';
import 'firebase_providers.dart';

part 'repository_providers.g.dart';

@Riverpod(keepAlive: true)
AuthRepository authRepository(Ref ref) => AuthRepositoryImpl(
      firebaseAuth: ref.read(firebaseAuthProvider),
      firestore:    ref.read(firebaseFirestoreProvider),
    );

@Riverpod(keepAlive: true)
SchedulingRepository schedulingRepository(Ref ref) =>
    SchedulingRepositoryImpl(ref.read(firebaseFirestoreProvider));

@Riverpod(keepAlive: true)
CourseRepository courseRepository(Ref ref) =>
    CourseRepositoryImpl(ref.read(firebaseFirestoreProvider));
