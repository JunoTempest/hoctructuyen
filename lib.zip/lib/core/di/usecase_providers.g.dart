// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'usecase_providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(loginUseCase)
const loginUseCaseProvider = LoginUseCaseProvider._();

final class LoginUseCaseProvider
    extends $FunctionalProvider<LoginUseCase, LoginUseCase, LoginUseCase>
    with $Provider<LoginUseCase> {
  const LoginUseCaseProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'loginUseCaseProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$loginUseCaseHash();

  @$internal
  @override
  $ProviderElement<LoginUseCase> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  LoginUseCase create(Ref ref) {
    return loginUseCase(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(LoginUseCase value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<LoginUseCase>(value),
    );
  }
}

String _$loginUseCaseHash() => r'eaacbb6a3d04205b01924ecaa1a14a6304165582';

@ProviderFor(registerUseCase)
const registerUseCaseProvider = RegisterUseCaseProvider._();

final class RegisterUseCaseProvider extends $FunctionalProvider<RegisterUseCase,
    RegisterUseCase, RegisterUseCase> with $Provider<RegisterUseCase> {
  const RegisterUseCaseProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'registerUseCaseProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$registerUseCaseHash();

  @$internal
  @override
  $ProviderElement<RegisterUseCase> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  RegisterUseCase create(Ref ref) {
    return registerUseCase(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(RegisterUseCase value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<RegisterUseCase>(value),
    );
  }
}

String _$registerUseCaseHash() => r'8b850e8f518ec25cd4afa5ca714d6df644f86bea';

@ProviderFor(logoutUseCase)
const logoutUseCaseProvider = LogoutUseCaseProvider._();

final class LogoutUseCaseProvider
    extends $FunctionalProvider<LogoutUseCase, LogoutUseCase, LogoutUseCase>
    with $Provider<LogoutUseCase> {
  const LogoutUseCaseProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'logoutUseCaseProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$logoutUseCaseHash();

  @$internal
  @override
  $ProviderElement<LogoutUseCase> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  LogoutUseCase create(Ref ref) {
    return logoutUseCase(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(LogoutUseCase value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<LogoutUseCase>(value),
    );
  }
}

String _$logoutUseCaseHash() => r'293d55af2b56bd89ac30dba75e911aea0e54b865';

@ProviderFor(getTeacherSchedulesUseCase)
const getTeacherSchedulesUseCaseProvider =
    GetTeacherSchedulesUseCaseProvider._();

final class GetTeacherSchedulesUseCaseProvider extends $FunctionalProvider<
    GetTeacherSchedulesUseCase,
    GetTeacherSchedulesUseCase,
    GetTeacherSchedulesUseCase> with $Provider<GetTeacherSchedulesUseCase> {
  const GetTeacherSchedulesUseCaseProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'getTeacherSchedulesUseCaseProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$getTeacherSchedulesUseCaseHash();

  @$internal
  @override
  $ProviderElement<GetTeacherSchedulesUseCase> $createElement(
          $ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  GetTeacherSchedulesUseCase create(Ref ref) {
    return getTeacherSchedulesUseCase(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(GetTeacherSchedulesUseCase value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<GetTeacherSchedulesUseCase>(value),
    );
  }
}

String _$getTeacherSchedulesUseCaseHash() =>
    r'9a479af813e7aaf7e9232a2be742b90d9bdeaefa';

@ProviderFor(watchTeacherSchedulesUseCase)
const watchTeacherSchedulesUseCaseProvider =
    WatchTeacherSchedulesUseCaseProvider._();

final class WatchTeacherSchedulesUseCaseProvider extends $FunctionalProvider<
    WatchTeacherSchedulesUseCase,
    WatchTeacherSchedulesUseCase,
    WatchTeacherSchedulesUseCase> with $Provider<WatchTeacherSchedulesUseCase> {
  const WatchTeacherSchedulesUseCaseProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'watchTeacherSchedulesUseCaseProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$watchTeacherSchedulesUseCaseHash();

  @$internal
  @override
  $ProviderElement<WatchTeacherSchedulesUseCase> $createElement(
          $ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  WatchTeacherSchedulesUseCase create(Ref ref) {
    return watchTeacherSchedulesUseCase(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(WatchTeacherSchedulesUseCase value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<WatchTeacherSchedulesUseCase>(value),
    );
  }
}

String _$watchTeacherSchedulesUseCaseHash() =>
    r'c79ffb15738966662883e5c776f5cfbbbf6a65fb';

@ProviderFor(getAvailableSchedulesUseCase)
const getAvailableSchedulesUseCaseProvider =
    GetAvailableSchedulesUseCaseProvider._();

final class GetAvailableSchedulesUseCaseProvider extends $FunctionalProvider<
    GetAvailableSchedulesUseCase,
    GetAvailableSchedulesUseCase,
    GetAvailableSchedulesUseCase> with $Provider<GetAvailableSchedulesUseCase> {
  const GetAvailableSchedulesUseCaseProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'getAvailableSchedulesUseCaseProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$getAvailableSchedulesUseCaseHash();

  @$internal
  @override
  $ProviderElement<GetAvailableSchedulesUseCase> $createElement(
          $ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  GetAvailableSchedulesUseCase create(Ref ref) {
    return getAvailableSchedulesUseCase(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(GetAvailableSchedulesUseCase value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<GetAvailableSchedulesUseCase>(value),
    );
  }
}

String _$getAvailableSchedulesUseCaseHash() =>
    r'3c0a8d2c472a5b20768ecf3967d726e4748bc3c7';

@ProviderFor(createScheduleUseCase)
const createScheduleUseCaseProvider = CreateScheduleUseCaseProvider._();

final class CreateScheduleUseCaseProvider extends $FunctionalProvider<
    CreateScheduleUseCase,
    CreateScheduleUseCase,
    CreateScheduleUseCase> with $Provider<CreateScheduleUseCase> {
  const CreateScheduleUseCaseProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'createScheduleUseCaseProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$createScheduleUseCaseHash();

  @$internal
  @override
  $ProviderElement<CreateScheduleUseCase> $createElement(
          $ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  CreateScheduleUseCase create(Ref ref) {
    return createScheduleUseCase(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(CreateScheduleUseCase value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<CreateScheduleUseCase>(value),
    );
  }
}

String _$createScheduleUseCaseHash() =>
    r'8db61c85acfe78310ef3821696b9cb685c5a06bc';

@ProviderFor(createBookingUseCase)
const createBookingUseCaseProvider = CreateBookingUseCaseProvider._();

final class CreateBookingUseCaseProvider extends $FunctionalProvider<
    CreateBookingUseCase,
    CreateBookingUseCase,
    CreateBookingUseCase> with $Provider<CreateBookingUseCase> {
  const CreateBookingUseCaseProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'createBookingUseCaseProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$createBookingUseCaseHash();

  @$internal
  @override
  $ProviderElement<CreateBookingUseCase> $createElement(
          $ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  CreateBookingUseCase create(Ref ref) {
    return createBookingUseCase(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(CreateBookingUseCase value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<CreateBookingUseCase>(value),
    );
  }
}

String _$createBookingUseCaseHash() =>
    r'c905936791afc50380bd6d15091aeb2d1f7d4a56';

@ProviderFor(confirmBookingUseCase)
const confirmBookingUseCaseProvider = ConfirmBookingUseCaseProvider._();

final class ConfirmBookingUseCaseProvider extends $FunctionalProvider<
    ConfirmBookingUseCase,
    ConfirmBookingUseCase,
    ConfirmBookingUseCase> with $Provider<ConfirmBookingUseCase> {
  const ConfirmBookingUseCaseProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'confirmBookingUseCaseProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$confirmBookingUseCaseHash();

  @$internal
  @override
  $ProviderElement<ConfirmBookingUseCase> $createElement(
          $ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  ConfirmBookingUseCase create(Ref ref) {
    return confirmBookingUseCase(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ConfirmBookingUseCase value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ConfirmBookingUseCase>(value),
    );
  }
}

String _$confirmBookingUseCaseHash() =>
    r'1ba5b80d87ffdd1fc87509a671a9db7f4fdb5368';

@ProviderFor(cancelBookingUseCase)
const cancelBookingUseCaseProvider = CancelBookingUseCaseProvider._();

final class CancelBookingUseCaseProvider extends $FunctionalProvider<
    CancelBookingUseCase,
    CancelBookingUseCase,
    CancelBookingUseCase> with $Provider<CancelBookingUseCase> {
  const CancelBookingUseCaseProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'cancelBookingUseCaseProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$cancelBookingUseCaseHash();

  @$internal
  @override
  $ProviderElement<CancelBookingUseCase> $createElement(
          $ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  CancelBookingUseCase create(Ref ref) {
    return cancelBookingUseCase(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(CancelBookingUseCase value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<CancelBookingUseCase>(value),
    );
  }
}

String _$cancelBookingUseCaseHash() =>
    r'7edb7cddb8985ec3f8c24b5d590cb31ab263ef4b';

@ProviderFor(watchUserBookingsUseCase)
const watchUserBookingsUseCaseProvider = WatchUserBookingsUseCaseProvider._();

final class WatchUserBookingsUseCaseProvider extends $FunctionalProvider<
    WatchUserBookingsUseCase,
    WatchUserBookingsUseCase,
    WatchUserBookingsUseCase> with $Provider<WatchUserBookingsUseCase> {
  const WatchUserBookingsUseCaseProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'watchUserBookingsUseCaseProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$watchUserBookingsUseCaseHash();

  @$internal
  @override
  $ProviderElement<WatchUserBookingsUseCase> $createElement(
          $ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  WatchUserBookingsUseCase create(Ref ref) {
    return watchUserBookingsUseCase(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(WatchUserBookingsUseCase value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<WatchUserBookingsUseCase>(value),
    );
  }
}

String _$watchUserBookingsUseCaseHash() =>
    r'00a2517f863ed1ba9ae36fb2b3f552893350c4d7';

@ProviderFor(watchUserSessionsUseCase)
const watchUserSessionsUseCaseProvider = WatchUserSessionsUseCaseProvider._();

final class WatchUserSessionsUseCaseProvider extends $FunctionalProvider<
    WatchUserSessionsUseCase,
    WatchUserSessionsUseCase,
    WatchUserSessionsUseCase> with $Provider<WatchUserSessionsUseCase> {
  const WatchUserSessionsUseCaseProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'watchUserSessionsUseCaseProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$watchUserSessionsUseCaseHash();

  @$internal
  @override
  $ProviderElement<WatchUserSessionsUseCase> $createElement(
          $ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  WatchUserSessionsUseCase create(Ref ref) {
    return watchUserSessionsUseCase(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(WatchUserSessionsUseCase value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<WatchUserSessionsUseCase>(value),
    );
  }
}

String _$watchUserSessionsUseCaseHash() =>
    r'ca2ee190f60fbb8040417092e78a51bdff4ac485';

@ProviderFor(getOpenCoursesUseCase)
const getOpenCoursesUseCaseProvider = GetOpenCoursesUseCaseProvider._();

final class GetOpenCoursesUseCaseProvider extends $FunctionalProvider<
    GetOpenCoursesUseCase,
    GetOpenCoursesUseCase,
    GetOpenCoursesUseCase> with $Provider<GetOpenCoursesUseCase> {
  const GetOpenCoursesUseCaseProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'getOpenCoursesUseCaseProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$getOpenCoursesUseCaseHash();

  @$internal
  @override
  $ProviderElement<GetOpenCoursesUseCase> $createElement(
          $ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  GetOpenCoursesUseCase create(Ref ref) {
    return getOpenCoursesUseCase(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(GetOpenCoursesUseCase value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<GetOpenCoursesUseCase>(value),
    );
  }
}

String _$getOpenCoursesUseCaseHash() =>
    r'f6cd127a62eac3624e82b706595c86909d3406f9';

@ProviderFor(getCourseUseCase)
const getCourseUseCaseProvider = GetCourseUseCaseProvider._();

final class GetCourseUseCaseProvider extends $FunctionalProvider<
    GetCourseUseCase,
    GetCourseUseCase,
    GetCourseUseCase> with $Provider<GetCourseUseCase> {
  const GetCourseUseCaseProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'getCourseUseCaseProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$getCourseUseCaseHash();

  @$internal
  @override
  $ProviderElement<GetCourseUseCase> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  GetCourseUseCase create(Ref ref) {
    return getCourseUseCase(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(GetCourseUseCase value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<GetCourseUseCase>(value),
    );
  }
}

String _$getCourseUseCaseHash() => r'896f965644a979ae9cda88b527690b4c7af93431';

@ProviderFor(createCourseUseCase)
const createCourseUseCaseProvider = CreateCourseUseCaseProvider._();

final class CreateCourseUseCaseProvider extends $FunctionalProvider<
    CreateCourseUseCase,
    CreateCourseUseCase,
    CreateCourseUseCase> with $Provider<CreateCourseUseCase> {
  const CreateCourseUseCaseProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'createCourseUseCaseProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$createCourseUseCaseHash();

  @$internal
  @override
  $ProviderElement<CreateCourseUseCase> $createElement(
          $ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  CreateCourseUseCase create(Ref ref) {
    return createCourseUseCase(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(CreateCourseUseCase value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<CreateCourseUseCase>(value),
    );
  }
}

String _$createCourseUseCaseHash() =>
    r'd3cb66847548fa770f4c8815631913f3cd667f50';

@ProviderFor(enrollCourseUseCase)
const enrollCourseUseCaseProvider = EnrollCourseUseCaseProvider._();

final class EnrollCourseUseCaseProvider extends $FunctionalProvider<
    EnrollCourseUseCase,
    EnrollCourseUseCase,
    EnrollCourseUseCase> with $Provider<EnrollCourseUseCase> {
  const EnrollCourseUseCaseProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'enrollCourseUseCaseProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$enrollCourseUseCaseHash();

  @$internal
  @override
  $ProviderElement<EnrollCourseUseCase> $createElement(
          $ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  EnrollCourseUseCase create(Ref ref) {
    return enrollCourseUseCase(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(EnrollCourseUseCase value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<EnrollCourseUseCase>(value),
    );
  }
}

String _$enrollCourseUseCaseHash() =>
    r'0b00dfe9d0b278d0029832eda922ef13fe27e9b3';

@ProviderFor(confirmEnrollmentUseCase)
const confirmEnrollmentUseCaseProvider = ConfirmEnrollmentUseCaseProvider._();

final class ConfirmEnrollmentUseCaseProvider extends $FunctionalProvider<
    ConfirmEnrollmentUseCase,
    ConfirmEnrollmentUseCase,
    ConfirmEnrollmentUseCase> with $Provider<ConfirmEnrollmentUseCase> {
  const ConfirmEnrollmentUseCaseProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'confirmEnrollmentUseCaseProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$confirmEnrollmentUseCaseHash();

  @$internal
  @override
  $ProviderElement<ConfirmEnrollmentUseCase> $createElement(
          $ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  ConfirmEnrollmentUseCase create(Ref ref) {
    return confirmEnrollmentUseCase(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ConfirmEnrollmentUseCase value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ConfirmEnrollmentUseCase>(value),
    );
  }
}

String _$confirmEnrollmentUseCaseHash() =>
    r'df13ec3f6fbe4d8de0505e490bba7a34b55a3497';

@ProviderFor(cancelEnrollmentUseCase)
const cancelEnrollmentUseCaseProvider = CancelEnrollmentUseCaseProvider._();

final class CancelEnrollmentUseCaseProvider extends $FunctionalProvider<
    CancelEnrollmentUseCase,
    CancelEnrollmentUseCase,
    CancelEnrollmentUseCase> with $Provider<CancelEnrollmentUseCase> {
  const CancelEnrollmentUseCaseProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'cancelEnrollmentUseCaseProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$cancelEnrollmentUseCaseHash();

  @$internal
  @override
  $ProviderElement<CancelEnrollmentUseCase> $createElement(
          $ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  CancelEnrollmentUseCase create(Ref ref) {
    return cancelEnrollmentUseCase(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(CancelEnrollmentUseCase value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<CancelEnrollmentUseCase>(value),
    );
  }
}

String _$cancelEnrollmentUseCaseHash() =>
    r'5c63dde8f3a9d5b3e604b3346a1d98e2f96f0fce';

@ProviderFor(watchStudentEnrollmentsUseCase)
const watchStudentEnrollmentsUseCaseProvider =
    WatchStudentEnrollmentsUseCaseProvider._();

final class WatchStudentEnrollmentsUseCaseProvider extends $FunctionalProvider<
        WatchStudentEnrollmentsUseCase,
        WatchStudentEnrollmentsUseCase,
        WatchStudentEnrollmentsUseCase>
    with $Provider<WatchStudentEnrollmentsUseCase> {
  const WatchStudentEnrollmentsUseCaseProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'watchStudentEnrollmentsUseCaseProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$watchStudentEnrollmentsUseCaseHash();

  @$internal
  @override
  $ProviderElement<WatchStudentEnrollmentsUseCase> $createElement(
          $ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  WatchStudentEnrollmentsUseCase create(Ref ref) {
    return watchStudentEnrollmentsUseCase(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(WatchStudentEnrollmentsUseCase value) {
    return $ProviderOverride(
      origin: this,
      providerOverride:
          $SyncValueProvider<WatchStudentEnrollmentsUseCase>(value),
    );
  }
}

String _$watchStudentEnrollmentsUseCaseHash() =>
    r'6aea244a6788f8364ec84ec75bee78a90dc2036f';
