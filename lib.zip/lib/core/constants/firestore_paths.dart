/// Tập trung toàn bộ Firestore collection/document paths
/// KHÔNG hardcode string ở bất kỳ nơi nào khác trong app
abstract class FirestorePaths {
  // Collections
  static const users        = 'users';
  static const courses      = 'courses';
  static const enrollments  = 'enrollments';
  static const sessions     = 'sessions';
  static const bookings     = 'bookings';
  static const schedules    = 'schedules';  // teacher available slots
  static const bugReports   = 'bug_reports';
  static const chats        = 'chats';
  static const messages     = 'messages';   // sub-collection của chats

  // Sub-collections
  static String strokes(String sessionId) =>
      '$sessions/$sessionId/strokes';

  // Document paths
  static String userDoc(String uid)           => '$users/$uid';
  static String courseDoc(String id)          => '$courses/$id';
  static String enrollmentDoc(String id)      => '$enrollments/$id';
  static String sessionDoc(String id)         => '$sessions/$id';
  static String bookingDoc(String id)         => '$bookings/$id';
  static String scheduleDoc(String id)        => '$schedules/$id';
  static String chatDoc(String id)            => '$chats/$id';
  static String messageDoc(String chatId, String msgId) =>
      '$chats/$chatId/$messages/$msgId';
}