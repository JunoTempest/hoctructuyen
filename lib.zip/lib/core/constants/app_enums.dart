import 'package:flutter/material.dart';

enum UserRole { student, teacher, admin }
extension UserRoleX on UserRole {
  String get label => switch (this) {
        UserRole.student => 'Học sinh',
        UserRole.teacher => 'Giáo viên',
        UserRole.admin   => 'Quản trị viên',
      };
  Color get color => switch (this) {
        UserRole.student => const Color(0xFF16A34A),
        UserRole.teacher => const Color(0xFF0891B2),
        UserRole.admin   => const Color(0xFF7C3AED),
      };
  IconData get icon => switch (this) {
        UserRole.student => Icons.school_outlined,
        UserRole.teacher => Icons.person_outlined,
        UserRole.admin   => Icons.admin_panel_settings_outlined,
      };
  static UserRole fromString(String s) => switch (s) {
        'teacher' => UserRole.teacher,
        'admin'   => UserRole.admin,
        _         => UserRole.student,
      };
}

enum BookingStatus { pending, confirmed, cancelled, completed }
extension BookingStatusX on BookingStatus {
  String get label => switch (this) {
        BookingStatus.pending   => 'Chờ xác nhận',
        BookingStatus.confirmed => 'Đã xác nhận',
        BookingStatus.cancelled => 'Đã huỷ',
        BookingStatus.completed => 'Hoàn thành',
      };
  static BookingStatus fromString(String s) => switch (s) {
        'confirmed' => BookingStatus.confirmed,
        'cancelled' => BookingStatus.cancelled,
        'completed' => BookingStatus.completed,
        _           => BookingStatus.pending,
      };
}

enum SessionStatus { scheduled, ongoing, completed, cancelled }
extension SessionStatusX on SessionStatus {
  String get label => switch (this) {
        SessionStatus.scheduled => 'Sắp diễn ra',
        SessionStatus.ongoing   => 'Đang diễn ra',
        SessionStatus.completed => 'Hoàn thành',
        SessionStatus.cancelled => 'Đã huỷ',
      };
  static SessionStatus fromString(String s) => switch (s) {
        'ongoing'   => SessionStatus.ongoing,
        'completed' => SessionStatus.completed,
        'cancelled' => SessionStatus.cancelled,
        _           => SessionStatus.scheduled,
      };
}

// pending = chờ admin duyệt (khoá học cá nhân giáo viên tạo)
enum CourseStatus { draft, pending, open, full, closed, rejected }
extension CourseStatusX on CourseStatus {
  String get label => switch (this) {
        CourseStatus.draft    => 'Nháp',
        CourseStatus.pending  => 'Chờ duyệt',
        CourseStatus.open     => 'Đang mở',
        CourseStatus.full     => 'Đã đầy',
        CourseStatus.closed   => 'Đã đóng',
        CourseStatus.rejected => 'Bị từ chối',
      };
  Color get color => switch (this) {
        CourseStatus.draft    => const Color(0xFF94A3B8),
        CourseStatus.pending  => const Color(0xFFF59E0B),
        CourseStatus.open     => const Color(0xFF16A34A),
        CourseStatus.full     => const Color(0xFF0891B2),
        CourseStatus.closed   => const Color(0xFF475569),
        CourseStatus.rejected => const Color(0xFFDC2626),
      };
  static CourseStatus fromString(String s) => switch (s) {
        'pending'  => CourseStatus.pending,
        'open'     => CourseStatus.open,
        'full'     => CourseStatus.full,
        'closed'   => CourseStatus.closed,
        'rejected' => CourseStatus.rejected,
        _          => CourseStatus.draft,
      };
}

enum EnrollmentStatus { pending, confirmed, cancelled, completed }
extension EnrollmentStatusX on EnrollmentStatus {
  String get label => switch (this) {
        EnrollmentStatus.pending   => 'Chờ xác nhận',
        EnrollmentStatus.confirmed => 'Đã xác nhận',
        EnrollmentStatus.cancelled => 'Đã huỷ',
        EnrollmentStatus.completed => 'Hoàn thành',
      };
  static EnrollmentStatus fromString(String s) => switch (s) {
        'confirmed' => EnrollmentStatus.confirmed,
        'cancelled' => EnrollmentStatus.cancelled,
        'completed' => EnrollmentStatus.completed,
        _           => EnrollmentStatus.pending,
      };
}

enum MessageType { text, image, file, system }
extension MessageTypeX on MessageType {
  static MessageType fromString(String s) => switch (s) {
        'image'  => MessageType.image,
        'file'   => MessageType.file,
        'system' => MessageType.system,
        _        => MessageType.text,
      };
}
