abstract class AppConstants {
  // Agora App ID thật — từ Agora Console
  static const agoraAppId = '8bac8b1b37d44976977cef0e7280e1cb';

  // Gemini API key — thay bằng key thật của bạn
  // Lấy tại: https://aistudio.google.com/app/apikey
  static const geminiApiKey = 'YOUR_GEMINI_API_KEY';

  // Pagination
  static const pageSize = 20;

  // Session timeout (phút)
  static const sessionTimeoutMinutes = 120;

  // Booking: học sinh chỉ đặt trước tối thiểu 30 phút
  static const minBookingAheadMinutes = 30;

  // App name
  static const appName = 'EduApp';
}
