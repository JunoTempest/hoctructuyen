import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

import '../../core/constants/app_enums.dart';
import '../../features/admin/presentation/views/admin_dashboard_screen.dart';
import '../../features/auth/domain/entities/user_entity.dart';
import '../../features/auth/presentation/providers/auth_provider.dart';
import '../../features/auth/presentation/views/login_screen.dart';
import '../../features/auth/presentation/views/register_screen.dart';
import '../../features/auth/presentation/views/splash_screen.dart';
import '../../features/chat/presentation/views/chat_screen.dart';
import '../../features/classroom/presentation/views/classroom_screen.dart';
import '../../features/courses/presentation/views/course_detail_screen.dart';
import '../../features/courses/presentation/views/course_list_screen.dart';
import '../../features/courses/presentation/views/my_enrollments_screen.dart';
import '../../features/courses/presentation/views/teacher_courses_screen.dart';
import '../../features/dashboard/presentation/views/dashboard_screen.dart';
import '../../features/profile/presentation/views/edit_profile_screen.dart';
import '../../features/profile/presentation/views/profile_screen.dart';
import '../../features/scheduling/presentation/views/schedule_screen.dart';
import '../shell/main_shell.dart';

part 'app_router.g.dart';

abstract class AppRoutes {
  static const splash         = '/';
  static const login          = '/login';
  static const register       = '/register';
  static const dashboard      = '/dashboard';
  static const schedule       = '/schedule';
  static const courses        = '/courses';
  static const courseDetail   = '/courses/:courseId';
  static const myEnrollments  = '/my-enrollments';
  static const teacherCourses = '/teacher-courses';
  static const profile        = '/profile';
  static const editProfile    = '/profile/edit';
  static const admin          = '/admin';
  static const classroom      = '/classroom/:sessionId';
  static const chat           = '/chat/:chatId';

  static String courseDetailPath(String id) => '/courses/$id';
  static String classroomPath(String id)    => '/classroom/$id';
  static String chatPath(String id)         => '/chat/$id';
}

class _RouterNotifier extends ChangeNotifier {
  _RouterNotifier(this._ref) {
    _ref.listen<AsyncValue<UserEntity?>>(
      authStateStreamProvider,
      (_, __) => notifyListeners(),
    );
  }
  final Ref _ref;

  String? redirect(BuildContext context, GoRouterState state) {
    final authAsync = _ref.read(authStateStreamProvider);
    if (authAsync.isLoading || !authAsync.hasValue) return AppRoutes.splash;

    final user       = authAsync.value;
    final isLoggedIn = user != null;
    final loc        = state.matchedLocation;
    final isAuthRoute = loc == AppRoutes.login || loc == AppRoutes.register;

    if (!isLoggedIn && !isAuthRoute) return AppRoutes.login;
    if (isLoggedIn  && isAuthRoute)  return AppRoutes.dashboard;
    if (isLoggedIn  && loc == AppRoutes.splash) return AppRoutes.dashboard;

    if (loc == AppRoutes.admin && user?.role != UserRole.admin) {
      return AppRoutes.dashboard;
    }
    if (loc == AppRoutes.teacherCourses && user?.role == UserRole.student) {
      return AppRoutes.dashboard;
    }
    return null;
  }
}

@Riverpod(keepAlive: true)
GoRouter appRouter(Ref ref) {
  final notifier = _RouterNotifier(ref);

  return GoRouter(
    initialLocation: AppRoutes.splash,
    debugLogDiagnostics: false,
    refreshListenable: notifier,
    redirect: notifier.redirect,
    routes: [
      GoRoute(path: AppRoutes.splash,   builder: (_, __) => const SplashScreen()),
      GoRoute(path: AppRoutes.login,    builder: (_, __) => const LoginScreen()),
      GoRoute(path: AppRoutes.register, builder: (_, __) => const RegisterScreen()),
      GoRoute(path: AppRoutes.editProfile, builder: (_, __) => const EditProfileScreen()),

      GoRoute(
        path: AppRoutes.classroom,
        builder: (_, state) {
          final sessionId = state.pathParameters['sessionId']!;
          final extra = state.extra as Map<String, dynamic>? ?? {};
          return ClassroomScreen(
            sessionId:    sessionId,
            channelName:  extra['channelName'] as String? ?? sessionId,
            sessionTitle: extra['title']       as String? ?? 'Buổi học',
            startTime:    extra['startTime']   as DateTime?,
          );
        },
      ),
      GoRoute(
        path: AppRoutes.chat,
        builder: (_, state) {
          final chatId = state.pathParameters['chatId']!;
          final extra  = state.extra as Map<String, dynamic>? ?? {};
          return ChatScreen(
            chatId:    chatId,
            otherName: extra['otherName'] as String? ?? 'Người dùng',
          );
        },
      ),

      ShellRoute(
        builder: (_, __, child) => MainShell(child: child),
        routes: [
          GoRoute(path: AppRoutes.dashboard,      builder: (_, __) => const DashboardScreen()),
          GoRoute(path: AppRoutes.schedule,        builder: (_, __) => const ScheduleScreen()),
          GoRoute(path: AppRoutes.courses,         builder: (_, __) => const CourseListScreen()),
          GoRoute(path: AppRoutes.courseDetail,
              builder: (_, state) => CourseDetailScreen(
                  courseId: state.pathParameters['courseId']!)),
          GoRoute(path: AppRoutes.myEnrollments,   builder: (_, __) => const MyEnrollmentsScreen()),
          GoRoute(path: AppRoutes.teacherCourses,  builder: (_, __) => const TeacherCoursesScreen()),
          GoRoute(path: AppRoutes.profile,         builder: (_, __) => const ProfileScreen()),
          GoRoute(path: AppRoutes.admin,           builder: (_, __) => const AdminDashboardScreen()),
        ],
      ),
    ],
    errorBuilder: (_, state) => Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, size: 64, color: Colors.red),
            const SizedBox(height: 12),
            Text('Lỗi điều hướng: ${state.error}'),
          ],
        ),
      ),
    ),
  );
}
