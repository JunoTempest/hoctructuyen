import 'package:flutter/material.dart';
import '../../app/theme/app_theme.dart';

class StubScreen extends StatelessWidget {
  const StubScreen({super.key, required this.title, this.icon});
  final String title;
  final IconData? icon;

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(title)),
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon ?? Icons.construction_outlined,
                  size: 64, color: Colors.grey[300]),
              const SizedBox(height: 16),
              Text(title,
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              const Text('Đang phát triển...',
                  style: TextStyle(color: AppColors.textSub)),
            ],
          ),
        ),
      );
}
