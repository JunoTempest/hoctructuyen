import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/app_enums.dart';
import '../../features/auth/presentation/providers/auth_provider.dart';
import '../router/app_router.dart';

class MainShell extends ConsumerWidget {
  const MainShell({super.key, required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user  = ref.watch(authStateStreamProvider).value;
    final loc   = GoRouterState.of(context).matchedLocation;
    final items = _navItems(user?.role);
    final idx   = _indexFromLocation(loc, items);
    final isWide = MediaQuery.of(context).size.width >= 800;

    if (isWide) {
      // Desktop: NavigationRail on the left
      return Scaffold(
        body: Row(
          children: [
            NavigationRail(
              selectedIndex: idx,
              onDestinationSelected: (i) => context.go(items[i].path),
              labelType: NavigationRailLabelType.all,
              leading: const SizedBox(height: 8),
              destinations: items.map((item) => NavigationRailDestination(
                icon: Icon(item.icon),
                selectedIcon: Icon(item.selectedIcon),
                label: Text(item.label),
              )).toList(),
            ),
            const VerticalDivider(width: 1),
            Expanded(child: child),
          ],
        ),
      );
    }

    // Mobile: bottom NavigationBar
    return Scaffold(
      body: child,
      bottomNavigationBar: NavigationBar(
        selectedIndex: idx,
        onDestinationSelected: (i) => context.go(items[i].path),
        destinations: items.map((item) => NavigationDestination(
          icon: Icon(item.icon),
          selectedIcon: Icon(item.selectedIcon),
          label: item.label,
        )).toList(),
      ),
    );
  }

  int _indexFromLocation(String loc, List<_NavItem> items) {
    for (var i = 0; i < items.length; i++) {
      if (loc.startsWith(items[i].path)) return i;
    }
    return 0;
  }

  List<_NavItem> _navItems(UserRole? role) {
    if (role == UserRole.teacher) {
      return [
        _NavItem(AppRoutes.dashboard,      Icons.home_outlined,      Icons.home,           'Trang chủ'),
        _NavItem(AppRoutes.schedule,       Icons.calendar_today_outlined, Icons.calendar_today, 'Lịch dạy'),
        _NavItem(AppRoutes.teacherCourses, Icons.menu_book_outlined,  Icons.menu_book,      'Khóa học'),
        _NavItem(AppRoutes.profile,        Icons.person_outline,      Icons.person,         'Tôi'),
      ];
    }
    if (role == UserRole.admin) {
      return [
        _NavItem(AppRoutes.dashboard, Icons.home_outlined,     Icons.home,     'Trang chủ'),
        _NavItem(AppRoutes.admin,     Icons.admin_panel_settings_outlined, Icons.admin_panel_settings, 'Quản lý'),
        _NavItem(AppRoutes.profile,   Icons.person_outline,    Icons.person,   'Tôi'),
      ];
    }
    return [
      _NavItem(AppRoutes.dashboard,     Icons.home_outlined,           Icons.home,           'Trang chủ'),
      _NavItem(AppRoutes.schedule,      Icons.calendar_today_outlined, Icons.calendar_today, 'Lịch học'),
      _NavItem(AppRoutes.courses,       Icons.explore_outlined,        Icons.explore,        'Khóa học'),
      _NavItem(AppRoutes.profile,       Icons.person_outline,          Icons.person,         'Tôi'),
    ];
  }
}

class _NavItem {
  const _NavItem(this.path, this.icon, this.selectedIcon, this.label);
  final String path;
  final IconData icon;
  final IconData selectedIcon;
  final String label;
}
