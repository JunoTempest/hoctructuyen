class ScheduleEntity {
  const ScheduleEntity({
    required this.scheduleId,
    required this.teacherId,
    required this.startTime,
    required this.endTime,
    required this.isBooked,
    required this.createdAt,
    this.teacherName,
    this.subject,
  });

  final String scheduleId;
  final String teacherId;
  final DateTime startTime;
  final DateTime endTime;
  final bool isBooked;
  final DateTime createdAt;
  final String? teacherName;
  final String? subject;

  bool get isAvailable => !isBooked && startTime.isAfter(DateTime.now());
  Duration get duration => endTime.difference(startTime);
  int get durationMinutes => duration.inMinutes;
}
