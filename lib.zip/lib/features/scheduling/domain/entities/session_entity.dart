import '../../../../core/constants/app_enums.dart';

class SessionEntity {
  const SessionEntity({
    required this.sessionId,
    required this.bookingId,
    required this.teacherId,
    required this.studentId,
    required this.agoraChannel,
    required this.startTime,
    required this.endTime,
    required this.status,
    required this.createdAt,
    this.teacherName,
    this.studentName,
    this.subjectName,
    this.courseId,
    this.sessionNumber,
    this.totalSessions,
    this.type = 'single',
  });

  final String sessionId;
  final String bookingId;
  final String teacherId;
  final String studentId;
  final String agoraChannel;
  final DateTime startTime;
  final DateTime endTime;
  final SessionStatus status;
  final DateTime createdAt;
  final String? teacherName;
  final String? studentName;
  final String? subjectName;
  final String? courseId;
  final int? sessionNumber;
  final int? totalSessions;
  final String type; // 'single' | 'course'

  bool get isScheduled => status == SessionStatus.scheduled;
  bool get isOngoing   => status == SessionStatus.ongoing;
  bool get isCompleted => status == SessionStatus.completed;
  bool get isCourse    => type == 'course';

  bool get isUpcoming  => startTime.isAfter(DateTime.now());
  bool get isPast      => endTime.isBefore(DateTime.now());

  // "3/8" nếu là buổi thuộc khóa
  String? get progressLabel => sessionNumber != null && totalSessions != null
      ? '$sessionNumber/$totalSessions'
      : null;
}
