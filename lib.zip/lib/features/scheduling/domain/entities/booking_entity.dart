import '../../../../core/constants/app_enums.dart';

class BookingEntity {
  const BookingEntity({
    required this.bookingId,
    required this.studentId,
    required this.teacherId,
    required this.scheduleId,
    required this.startTime,
    required this.endTime,
    required this.status,
    required this.createdAt,
    this.studentName,
    this.teacherName,
    this.subjectName,
    this.sessionId,
    this.note,
  });

  final String bookingId;
  final String studentId;
  final String teacherId;
  final String scheduleId;
  final DateTime startTime;
  final DateTime endTime;
  final BookingStatus status;
  final DateTime createdAt;
  final String? studentName;
  final String? teacherName;
  final String? subjectName;
  final String? sessionId;
  final String? note;

  bool get isPending   => status == BookingStatus.pending;
  bool get isConfirmed => status == BookingStatus.confirmed;
  bool get isCancelled => status == BookingStatus.cancelled;
  bool get isCompleted => status == BookingStatus.completed;

  Duration get duration => endTime.difference(startTime);
  int get durationMinutes => duration.inMinutes;
}
