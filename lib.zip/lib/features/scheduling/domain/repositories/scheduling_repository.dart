import '../entities/booking_entity.dart';
import '../entities/schedule_entity.dart';
import '../entities/session_entity.dart';

abstract interface class SchedulingRepository {
  Future<ScheduleEntity> createSchedule({
    required String teacherId,
    required DateTime startTime,
    required DateTime endTime,
    String? subject,
  });

  Future<List<ScheduleEntity>> getTeacherSchedules(String teacherId);
  Stream<List<ScheduleEntity>> watchTeacherSchedules(String teacherId);

  // Học sinh: lấy lịch rảnh còn trống của tất cả giáo viên
  Future<List<ScheduleEntity>> getAvailableSchedules();

  Future<BookingEntity> createBooking({
    required String studentId,
    required String teacherId,
    required String scheduleId,
  });

  Future<BookingEntity> confirmBooking(String bookingId);
  Future<BookingEntity> cancelBooking(String bookingId);

  Stream<List<BookingEntity>> watchUserBookings(String userId);
  Stream<List<SessionEntity>> watchUserSessions(String userId);
}
