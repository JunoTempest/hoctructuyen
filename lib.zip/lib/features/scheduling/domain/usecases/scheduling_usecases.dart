import '../entities/booking_entity.dart';
import '../entities/schedule_entity.dart';
import '../entities/session_entity.dart';
import '../repositories/scheduling_repository.dart';

class GetTeacherSchedulesUseCase {
  const GetTeacherSchedulesUseCase(this._repo);
  final SchedulingRepository _repo;
  Future<List<ScheduleEntity>> call(String teacherId) =>
      _repo.getTeacherSchedules(teacherId);
}

class WatchTeacherSchedulesUseCase {
  const WatchTeacherSchedulesUseCase(this._repo);
  final SchedulingRepository _repo;
  Stream<List<ScheduleEntity>> call(String teacherId) =>
      _repo.watchTeacherSchedules(teacherId);
}

// Lấy tất cả lịch rảnh còn trống (student dùng)
class GetAvailableSchedulesUseCase {
  const GetAvailableSchedulesUseCase(this._repo);
  final SchedulingRepository _repo;
  Future<List<ScheduleEntity>> call() => _repo.getAvailableSchedules();
}

class CreateScheduleUseCase {
  const CreateScheduleUseCase(this._repo);
  final SchedulingRepository _repo;

  Future<ScheduleEntity> call({
    required String teacherId,
    required DateTime startTime,
    required DateTime endTime,
    String? subject,
  }) {
    if (startTime.isBefore(DateTime.now())) {
      throw ArgumentError('Thời gian bắt đầu phải trong tương lai');
    }
    if (endTime.isBefore(startTime)) {
      throw ArgumentError('Thời gian kết thúc phải sau thời gian bắt đầu');
    }
    return _repo.createSchedule(
        teacherId: teacherId,
        startTime: startTime,
        endTime:   endTime,
        subject:   subject);
  }
}

class CreateBookingUseCase {
  const CreateBookingUseCase(this._repo);
  final SchedulingRepository _repo;

  Future<BookingEntity> call({
    required String studentId,
    required String teacherId,
    required String scheduleId,
  }) => _repo.createBooking(
        studentId: studentId,
        teacherId: teacherId,
        scheduleId: scheduleId);
}

class ConfirmBookingUseCase {
  const ConfirmBookingUseCase(this._repo);
  final SchedulingRepository _repo;
  Future<BookingEntity> call(String bookingId) => _repo.confirmBooking(bookingId);
}

class CancelBookingUseCase {
  const CancelBookingUseCase(this._repo);
  final SchedulingRepository _repo;
  Future<BookingEntity> call(String bookingId) => _repo.cancelBooking(bookingId);
}

class WatchUserBookingsUseCase {
  const WatchUserBookingsUseCase(this._repo);
  final SchedulingRepository _repo;
  Stream<List<BookingEntity>> call(String userId) => _repo.watchUserBookings(userId);
}

class WatchUserSessionsUseCase {
  const WatchUserSessionsUseCase(this._repo);
  final SchedulingRepository _repo;
  Stream<List<SessionEntity>> call(String userId) => _repo.watchUserSessions(userId);
}
