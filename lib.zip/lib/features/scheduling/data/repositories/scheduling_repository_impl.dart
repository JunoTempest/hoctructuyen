import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';

import '../../../../core/constants/firestore_paths.dart';
import '../../domain/entities/booking_entity.dart';
import '../../domain/entities/schedule_entity.dart';
import '../../domain/entities/session_entity.dart';
import '../../domain/repositories/scheduling_repository.dart';
import '../models/scheduling_models.dart';

class SchedulingRepositoryImpl implements SchedulingRepository {
  SchedulingRepositoryImpl(this._db);
  final FirebaseFirestore _db;
  final _uuid = const Uuid();

  @override
  Future<ScheduleEntity> createSchedule({
    required String teacherId,
    required DateTime startTime,
    required DateTime endTime,
    String? subject,
  }) async {
    final ref = _db.collection(FirestorePaths.schedules).doc();
    final model = ScheduleModel(
      scheduleId: ref.id,
      teacherId:  teacherId,
      startTime:  startTime,
      endTime:    endTime,
      isBooked:   false,
      createdAt:  DateTime.now(),
      subject:    subject,
    );
    await ref.set(model.toFirestore());
    return model.toEntity();
  }

  @override
  Future<List<ScheduleEntity>> getAvailableSchedules() async {
    // Chỉ 1 where → không cần composite index; lọc + sort phía client
    final snap = await _db.collection(FirestorePaths.schedules)
        .where('isBooked', isEqualTo: false)
        .get();
    final now = DateTime.now();
    final list = snap.docs
        .map((d) => ScheduleModel.fromFirestore(d).toEntity())
        .where((s) => s.startTime.isAfter(now))
        .toList()
      ..sort((a, b) => a.startTime.compareTo(b.startTime));
    return list;
  }

  @override
  Future<List<ScheduleEntity>> getTeacherSchedules(String teacherId) async {
    // Bỏ orderBy → không cần index; sort client-side
    final snap = await _db.collection(FirestorePaths.schedules)
        .where('teacherId', isEqualTo: teacherId)
        .get();
    final list = snap.docs
        .map((d) => ScheduleModel.fromFirestore(d).toEntity())
        .toList()
      ..sort((a, b) => a.startTime.compareTo(b.startTime));
    return list;
  }

  @override
  Stream<List<ScheduleEntity>> watchTeacherSchedules(String teacherId) =>
      _db.collection(FirestorePaths.schedules)
          .where('teacherId', isEqualTo: teacherId)
          .snapshots()                               // bỏ orderBy → không cần index
          .map((s) {
            final list = s.docs
                .map((d) => ScheduleModel.fromFirestore(d).toEntity())
                .toList()
              ..sort((a, b) => a.startTime.compareTo(b.startTime));
            return list;
          });

  @override
  Future<BookingEntity> createBooking({
    required String studentId,
    required String teacherId,
    required String scheduleId,
  }) async {
    return _db.runTransaction((tx) async {
      final scheduleRef  = _db.collection(FirestorePaths.schedules).doc(scheduleId);
      final scheduleSnap = await tx.get(scheduleRef);
      if (!scheduleSnap.exists) throw Exception('Slot không tồn tại');
      final schedule = ScheduleModel.fromFirestore(scheduleSnap);
      if (schedule.isBooked) throw Exception('Slot đã được đặt');

      // Lấy tên học sinh
      final studentSnap = await _db.collection(FirestorePaths.users).doc(studentId).get();
      final studentName = studentSnap.data()?['displayName'] as String? ?? 'Học sinh';

      // Lấy tên giáo viên
      final teacherSnap = await _db.collection(FirestorePaths.users).doc(teacherId).get();
      final teacherName = teacherSnap.data()?['displayName'] as String? ?? 'Giáo viên';

      final bookingRef = _db.collection(FirestorePaths.bookings).doc();
      final booking = BookingModel(
        bookingId:   bookingRef.id,
        studentId:   studentId,
        teacherId:   teacherId,
        scheduleId:  scheduleId,
        startTime:   schedule.startTime,
        endTime:     schedule.endTime,
        status:      'pending',
        createdAt:   DateTime.now(),
        studentName: studentName,
        teacherName: teacherName,
        subjectName: schedule.subject,
      );
      tx.set(bookingRef, booking.toFirestore());
      tx.update(scheduleRef, {'isBooked': true});
      return booking.toEntity();
    });
  }

  @override
  Future<BookingEntity> confirmBooking(String bookingId) async {
    return _db.runTransaction((tx) async {
      final bookingRef  = _db.collection(FirestorePaths.bookings).doc(bookingId);
      final snap        = await tx.get(bookingRef);
      if (!snap.exists) throw Exception('Booking không tồn tại');
      final booking = BookingModel.fromFirestore(snap);

      // Tạo session để cả 2 có thể vào lớp
      final sessionRef  = _db.collection(FirestorePaths.sessions).doc();
      final channelName = 'session_${sessionRef.id.substring(0, 8)}';
      tx.set(sessionRef, {
        'sessionId':    sessionRef.id,
        'bookingId':    bookingId,
        'teacherId':    booking.teacherId,
        'studentId':    booking.studentId,
        'agoraChannel': channelName,
        'startTime':    Timestamp.fromDate(booking.startTime),
        'endTime':      Timestamp.fromDate(booking.endTime),
        'status':       'scheduled',
        'createdAt':    FieldValue.serverTimestamp(),
        'teacherName':  booking.teacherName,
        'studentName':  booking.studentName,
        'subjectName':  booking.subjectName ?? 'Buổi học 1:1',
        'type':         'single',
      });
      tx.update(bookingRef, {'status': 'confirmed', 'sessionId': sessionRef.id});
      return booking.toEntity();
    });
  }

  @override
  Future<BookingEntity> cancelBooking(String bookingId) async {
    return _db.runTransaction((tx) async {
      final bookingRef = _db.collection(FirestorePaths.bookings).doc(bookingId);
      final snap       = await tx.get(bookingRef);
      if (!snap.exists) throw Exception('Booking không tồn tại');
      final booking = BookingModel.fromFirestore(snap);
      if (booking.status == 'cancelled') throw Exception('Booking đã bị huỷ');

      tx.update(bookingRef, {'status': 'cancelled'});
      tx.update(
        _db.collection(FirestorePaths.schedules).doc(booking.scheduleId),
        {'isBooked': false},
      );
      return booking.toEntity();
    });
  }

  @override
  Stream<List<BookingEntity>> watchUserBookings(String userId) {
    // 2 query riêng, không dùng orderBy → không cần composite index
    final studentStream = _db.collection(FirestorePaths.bookings)
        .where('studentId', isEqualTo: userId)
        .snapshots();

    return studentStream.asyncMap((studentSnap) async {
      final teacherSnap = await _db.collection(FirestorePaths.bookings)
          .where('teacherId', isEqualTo: userId)
          .get();
      final all = <String, BookingEntity>{};
      for (final d in studentSnap.docs) {
        final e = BookingModel.fromFirestore(d).toEntity();
        all[e.bookingId] = e;
      }
      for (final d in teacherSnap.docs) {
        final e = BookingModel.fromFirestore(d).toEntity();
        all[e.bookingId] = e;
      }
      return all.values.toList()
        ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    });
  }

  @override
  Stream<List<SessionEntity>> watchUserSessions(String userId) {
    // 2 query riêng, không dùng orderBy → không cần composite index
    final studentStream = _db.collection(FirestorePaths.sessions)
        .where('studentId', isEqualTo: userId)
        .snapshots();

    return studentStream.asyncMap((studentSnap) async {
      final teacherSnap = await _db.collection(FirestorePaths.sessions)
          .where('teacherId', isEqualTo: userId)
          .get();
      final all = <String, SessionEntity>{};
      for (final d in studentSnap.docs) {
        final e = SessionModel.fromFirestore(d).toEntity();
        all[e.sessionId] = e;
      }
      for (final d in teacherSnap.docs) {
        final e = SessionModel.fromFirestore(d).toEntity();
        all[e.sessionId] = e;
      }
      return all.values.toList()
        ..sort((a, b) => a.startTime.compareTo(b.startTime));
    });
  }
}
