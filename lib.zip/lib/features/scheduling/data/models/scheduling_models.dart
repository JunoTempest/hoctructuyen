import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../../core/constants/app_enums.dart';
import '../../domain/entities/booking_entity.dart';
import '../../domain/entities/schedule_entity.dart';
import '../../domain/entities/session_entity.dart';

class ScheduleModel {
  const ScheduleModel({
    required this.scheduleId,
    required this.teacherId,
    required this.startTime,
    required this.endTime,
    required this.isBooked,
    required this.createdAt,
    this.teacherName,
    this.subject,
  });

  final String scheduleId;
  final String teacherId;
  final DateTime startTime;
  final DateTime endTime;
  final bool isBooked;
  final DateTime createdAt;
  final String? teacherName;
  final String? subject;

  factory ScheduleModel.fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data()!;
    return ScheduleModel(
      scheduleId:  doc.id,
      teacherId:   d['teacherId'] as String,
      startTime:   (d['startTime'] as Timestamp).toDate(),
      endTime:     (d['endTime'] as Timestamp).toDate(),
      isBooked:    d['isBooked'] as bool? ?? false,
      createdAt:   (d['createdAt'] as Timestamp).toDate(),
      teacherName: d['teacherName'] as String?,
      subject:     d['subject'] as String?,
    );
  }

  Map<String, dynamic> toFirestore() => {
        'teacherId':   teacherId,
        'startTime':   Timestamp.fromDate(startTime),
        'endTime':     Timestamp.fromDate(endTime),
        'isBooked':    isBooked,
        'createdAt':   Timestamp.fromDate(createdAt),
        'teacherName': teacherName,
        'subject':     subject,
      };

  ScheduleEntity toEntity() => ScheduleEntity(
        scheduleId:  scheduleId,
        teacherId:   teacherId,
        startTime:   startTime,
        endTime:     endTime,
        isBooked:    isBooked,
        createdAt:   createdAt,
        teacherName: teacherName,
        subject:     subject,
      );
}

class BookingModel {
  const BookingModel({
    required this.bookingId,
    required this.studentId,
    required this.teacherId,
    required this.scheduleId,
    required this.startTime,
    required this.endTime,
    required this.status,
    required this.createdAt,
    this.studentName,
    this.teacherName,
    this.subjectName,
    this.sessionId,
    this.note,
  });

  final String bookingId;
  final String studentId;
  final String teacherId;
  final String scheduleId;
  final DateTime startTime;
  final DateTime endTime;
  final String status;
  final DateTime createdAt;
  final String? studentName;
  final String? teacherName;
  final String? subjectName;
  final String? sessionId;
  final String? note;

  factory BookingModel.fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data()!;
    return BookingModel(
      bookingId:   doc.id,
      studentId:   d['studentId'] as String,
      teacherId:   d['teacherId'] as String,
      scheduleId:  d['scheduleId'] as String,
      startTime:   (d['startTime'] as Timestamp).toDate(),
      endTime:     (d['endTime'] as Timestamp).toDate(),
      status:      d['status'] as String? ?? 'pending',
      createdAt:   (d['createdAt'] as Timestamp).toDate(),
      studentName: d['studentName'] as String?,
      teacherName: d['teacherName'] as String?,
      subjectName: d['subjectName'] as String?,
      sessionId:   d['sessionId'] as String?,
      note:        d['note'] as String?,
    );
  }

  Map<String, dynamic> toFirestore() => {
        'studentId':   studentId,
        'teacherId':   teacherId,
        'scheduleId':  scheduleId,
        'startTime':   Timestamp.fromDate(startTime),
        'endTime':     Timestamp.fromDate(endTime),
        'status':      status,
        'createdAt':   Timestamp.fromDate(createdAt),
        'studentName': studentName,
        'teacherName': teacherName,
        'subjectName': subjectName,
        'sessionId':   sessionId,
        'note':        note,
      };

  BookingEntity toEntity() => BookingEntity(
        bookingId:   bookingId,
        studentId:   studentId,
        teacherId:   teacherId,
        scheduleId:  scheduleId,
        startTime:   startTime,
        endTime:     endTime,
        status:      BookingStatusX.fromString(status),
        createdAt:   createdAt,
        studentName: studentName,
        teacherName: teacherName,
        subjectName: subjectName,
        sessionId:   sessionId,
        note:        note,
      );
}

class SessionModel {
  const SessionModel({
    required this.sessionId,
    required this.bookingId,
    required this.teacherId,
    required this.studentId,
    required this.agoraChannel,
    required this.startTime,
    required this.endTime,
    required this.status,
    required this.createdAt,
    this.teacherName,
    this.studentName,
    this.subjectName,
    this.courseId,
    this.sessionNumber,
    this.totalSessions,
    this.type = 'single',
  });

  final String sessionId;
  final String bookingId;
  final String teacherId;
  final String studentId;
  final String agoraChannel;
  final DateTime startTime;
  final DateTime endTime;
  final String status;
  final DateTime createdAt;
  final String? teacherName;
  final String? studentName;
  final String? subjectName;
  final String? courseId;
  final int? sessionNumber;
  final int? totalSessions;
  final String type;

  factory SessionModel.fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data()!;
    return SessionModel(
      sessionId:     doc.id,
      bookingId:     d['bookingId'] as String? ?? '',
      teacherId:     d['teacherId'] as String,
      studentId:     d['studentId'] as String,
      agoraChannel:  d['agoraChannel'] as String,
      startTime:     (d['startTime'] as Timestamp).toDate(),
      endTime:       (d['endTime'] as Timestamp).toDate(),
      status:        d['status'] as String? ?? 'scheduled',
      createdAt:     (d['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      teacherName:   d['teacherName'] as String?,
      studentName:   d['studentName'] as String?,
      subjectName:   d['subjectName'] as String?,
      courseId:      d['courseId'] as String?,
      sessionNumber: d['sessionNumber'] as int?,
      totalSessions: d['totalSessions'] as int?,
      type:          d['type'] as String? ?? 'single',
    );
  }

  SessionEntity toEntity() => SessionEntity(
        sessionId:     sessionId,
        bookingId:     bookingId,
        teacherId:     teacherId,
        studentId:     studentId,
        agoraChannel:  agoraChannel,
        startTime:     startTime,
        endTime:       endTime,
        status:        SessionStatusX.fromString(status),
        createdAt:     createdAt,
        teacherName:   teacherName,
        studentName:   studentName,
        subjectName:   subjectName,
        courseId:      courseId,
        sessionNumber: sessionNumber,
        totalSessions: totalSessions,
        type:          type,
      );
}
