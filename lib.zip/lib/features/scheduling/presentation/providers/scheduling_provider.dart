import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

import '../../../../core/di/usecase_providers.dart';
import '../../../auth/presentation/providers/auth_provider.dart';
import '../../domain/entities/booking_entity.dart';
import '../../domain/entities/schedule_entity.dart';
import '../../domain/entities/session_entity.dart';

part 'scheduling_provider.freezed.dart';
part 'scheduling_provider.g.dart';

// ── Streams ───────────────────────────────────────────────────
@riverpod
Stream<List<BookingEntity>> userBookings(Ref ref) {
  final user = ref.watch(authStateStreamProvider).value;
  if (user == null) return const Stream.empty();
  return ref.watch(watchUserBookingsUseCaseProvider).call(user.id);
}

@riverpod
Stream<List<SessionEntity>> userSessions(Ref ref) {
  final user = ref.watch(authStateStreamProvider).value;
  if (user == null) return const Stream.empty();
  return ref.watch(watchUserSessionsUseCaseProvider).call(user.id);
}

@riverpod
Stream<List<ScheduleEntity>> teacherSchedules(Ref ref, String teacherId) =>
    ref.watch(watchTeacherSchedulesUseCaseProvider).call(teacherId);

// Lịch rảnh có thể đặt (student dùng)
@riverpod
Future<List<ScheduleEntity>> availableSlots(Ref ref) =>
    ref.watch(getAvailableSchedulesUseCaseProvider).call();

// ── State ─────────────────────────────────────────────────────
@freezed
sealed class SchedulePageState with _$SchedulePageState {
  const factory SchedulePageState.idle()                                  = ScheduleIdle;
  const factory SchedulePageState.loading()                               = ScheduleLoading;
  const factory SchedulePageState.bookingSuccess(BookingEntity booking)   = ScheduleBookingSuccess;
  const factory SchedulePageState.error(String message)                   = ScheduleError;
}

// ── ViewModel ─────────────────────────────────────────────────
@riverpod
class ScheduleViewModel extends _$ScheduleViewModel {
  @override
  SchedulePageState build() => const SchedulePageState.idle();

  Future<void> bookSlot({
    required String studentId,
    required String teacherId,
    required String scheduleId,
  }) async {
    state = const SchedulePageState.loading();
    try {
      final booking = await ref.read(createBookingUseCaseProvider).call(
        studentId: studentId,
        teacherId: teacherId,
        scheduleId: scheduleId,
      );
      state = SchedulePageState.bookingSuccess(booking);
      ref.invalidate(availableSlotsProvider);
    } on FirebaseException catch (e) {
      state = SchedulePageState.error(e.message ?? 'Lỗi Firebase');
    } catch (e) {
      state = SchedulePageState.error(e.toString());
    }
  }

  Future<void> confirmBooking(String bookingId) async {
    state = const SchedulePageState.loading();
    try {
      final booking = await ref.read(confirmBookingUseCaseProvider).call(bookingId);
      state = SchedulePageState.bookingSuccess(booking);
    } catch (e) {
      state = SchedulePageState.error(e.toString());
    }
  }

  Future<void> cancelBooking(String bookingId) async {
    state = const SchedulePageState.loading();
    try {
      await ref.read(cancelBookingUseCaseProvider).call(bookingId);
      state = const SchedulePageState.idle();
    } catch (e) {
      state = SchedulePageState.error(e.toString());
    }
  }

  void reset() => state = const SchedulePageState.idle();
}
