// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'scheduling_provider.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$SchedulePageState {
  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is SchedulePageState);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  String toString() {
    return 'SchedulePageState()';
  }
}

/// @nodoc
class $SchedulePageStateCopyWith<$Res> {
  $SchedulePageStateCopyWith(
      SchedulePageState _, $Res Function(SchedulePageState) __);
}

/// Adds pattern-matching-related methods to [SchedulePageState].
extension SchedulePageStatePatterns on SchedulePageState {
  /// A variant of `map` that fallback to returning `orElse`.
  ///
  /// It is equivalent to doing:
  /// ```dart
  /// switch (sealedClass) {
  ///   case final Subclass value:
  ///     return ...;
  ///   case _:
  ///     return orElse();
  /// }
  /// ```

  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(ScheduleIdle value)? idle,
    TResult Function(ScheduleLoading value)? loading,
    TResult Function(ScheduleBookingSuccess value)? bookingSuccess,
    TResult Function(ScheduleError value)? error,
    required TResult orElse(),
  }) {
    final _that = this;
    switch (_that) {
      case ScheduleIdle() when idle != null:
        return idle(_that);
      case ScheduleLoading() when loading != null:
        return loading(_that);
      case ScheduleBookingSuccess() when bookingSuccess != null:
        return bookingSuccess(_that);
      case ScheduleError() when error != null:
        return error(_that);
      case _:
        return orElse();
    }
  }

  /// A `switch`-like method, using callbacks.
  ///
  /// Callbacks receives the raw object, upcasted.
  /// It is equivalent to doing:
  /// ```dart
  /// switch (sealedClass) {
  ///   case final Subclass value:
  ///     return ...;
  ///   case final Subclass2 value:
  ///     return ...;
  /// }
  /// ```

  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(ScheduleIdle value) idle,
    required TResult Function(ScheduleLoading value) loading,
    required TResult Function(ScheduleBookingSuccess value) bookingSuccess,
    required TResult Function(ScheduleError value) error,
  }) {
    final _that = this;
    switch (_that) {
      case ScheduleIdle():
        return idle(_that);
      case ScheduleLoading():
        return loading(_that);
      case ScheduleBookingSuccess():
        return bookingSuccess(_that);
      case ScheduleError():
        return error(_that);
    }
  }

  /// A variant of `map` that fallback to returning `null`.
  ///
  /// It is equivalent to doing:
  /// ```dart
  /// switch (sealedClass) {
  ///   case final Subclass value:
  ///     return ...;
  ///   case _:
  ///     return null;
  /// }
  /// ```

  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(ScheduleIdle value)? idle,
    TResult? Function(ScheduleLoading value)? loading,
    TResult? Function(ScheduleBookingSuccess value)? bookingSuccess,
    TResult? Function(ScheduleError value)? error,
  }) {
    final _that = this;
    switch (_that) {
      case ScheduleIdle() when idle != null:
        return idle(_that);
      case ScheduleLoading() when loading != null:
        return loading(_that);
      case ScheduleBookingSuccess() when bookingSuccess != null:
        return bookingSuccess(_that);
      case ScheduleError() when error != null:
        return error(_that);
      case _:
        return null;
    }
  }

  /// A variant of `when` that fallback to an `orElse` callback.
  ///
  /// It is equivalent to doing:
  /// ```dart
  /// switch (sealedClass) {
  ///   case Subclass(:final field):
  ///     return ...;
  ///   case _:
  ///     return orElse();
  /// }
  /// ```

  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? idle,
    TResult Function()? loading,
    TResult Function(BookingEntity booking)? bookingSuccess,
    TResult Function(String message)? error,
    required TResult orElse(),
  }) {
    final _that = this;
    switch (_that) {
      case ScheduleIdle() when idle != null:
        return idle();
      case ScheduleLoading() when loading != null:
        return loading();
      case ScheduleBookingSuccess() when bookingSuccess != null:
        return bookingSuccess(_that.booking);
      case ScheduleError() when error != null:
        return error(_that.message);
      case _:
        return orElse();
    }
  }

  /// A `switch`-like method, using callbacks.
  ///
  /// As opposed to `map`, this offers destructuring.
  /// It is equivalent to doing:
  /// ```dart
  /// switch (sealedClass) {
  ///   case Subclass(:final field):
  ///     return ...;
  ///   case Subclass2(:final field2):
  ///     return ...;
  /// }
  /// ```

  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() idle,
    required TResult Function() loading,
    required TResult Function(BookingEntity booking) bookingSuccess,
    required TResult Function(String message) error,
  }) {
    final _that = this;
    switch (_that) {
      case ScheduleIdle():
        return idle();
      case ScheduleLoading():
        return loading();
      case ScheduleBookingSuccess():
        return bookingSuccess(_that.booking);
      case ScheduleError():
        return error(_that.message);
    }
  }

  /// A variant of `when` that fallback to returning `null`
  ///
  /// It is equivalent to doing:
  /// ```dart
  /// switch (sealedClass) {
  ///   case Subclass(:final field):
  ///     return ...;
  ///   case _:
  ///     return null;
  /// }
  /// ```

  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? idle,
    TResult? Function()? loading,
    TResult? Function(BookingEntity booking)? bookingSuccess,
    TResult? Function(String message)? error,
  }) {
    final _that = this;
    switch (_that) {
      case ScheduleIdle() when idle != null:
        return idle();
      case ScheduleLoading() when loading != null:
        return loading();
      case ScheduleBookingSuccess() when bookingSuccess != null:
        return bookingSuccess(_that.booking);
      case ScheduleError() when error != null:
        return error(_that.message);
      case _:
        return null;
    }
  }
}

/// @nodoc

class ScheduleIdle implements SchedulePageState {
  const ScheduleIdle();

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is ScheduleIdle);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  String toString() {
    return 'SchedulePageState.idle()';
  }
}

/// @nodoc

class ScheduleLoading implements SchedulePageState {
  const ScheduleLoading();

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is ScheduleLoading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  String toString() {
    return 'SchedulePageState.loading()';
  }
}

/// @nodoc

class ScheduleBookingSuccess implements SchedulePageState {
  const ScheduleBookingSuccess(this.booking);

  final BookingEntity booking;

  /// Create a copy of SchedulePageState
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @pragma('vm:prefer-inline')
  $ScheduleBookingSuccessCopyWith<ScheduleBookingSuccess> get copyWith =>
      _$ScheduleBookingSuccessCopyWithImpl<ScheduleBookingSuccess>(
          this, _$identity);

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is ScheduleBookingSuccess &&
            (identical(other.booking, booking) || other.booking == booking));
  }

  @override
  int get hashCode => Object.hash(runtimeType, booking);

  @override
  String toString() {
    return 'SchedulePageState.bookingSuccess(booking: $booking)';
  }
}

/// @nodoc
abstract mixin class $ScheduleBookingSuccessCopyWith<$Res>
    implements $SchedulePageStateCopyWith<$Res> {
  factory $ScheduleBookingSuccessCopyWith(ScheduleBookingSuccess value,
          $Res Function(ScheduleBookingSuccess) _then) =
      _$ScheduleBookingSuccessCopyWithImpl;
  @useResult
  $Res call({BookingEntity booking});
}

/// @nodoc
class _$ScheduleBookingSuccessCopyWithImpl<$Res>
    implements $ScheduleBookingSuccessCopyWith<$Res> {
  _$ScheduleBookingSuccessCopyWithImpl(this._self, this._then);

  final ScheduleBookingSuccess _self;
  final $Res Function(ScheduleBookingSuccess) _then;

  /// Create a copy of SchedulePageState
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  $Res call({
    Object? booking = null,
  }) {
    return _then(ScheduleBookingSuccess(
      null == booking
          ? _self.booking
          : booking // ignore: cast_nullable_to_non_nullable
              as BookingEntity,
    ));
  }
}

/// @nodoc

class ScheduleError implements SchedulePageState {
  const ScheduleError(this.message);

  final String message;

  /// Create a copy of SchedulePageState
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @pragma('vm:prefer-inline')
  $ScheduleErrorCopyWith<ScheduleError> get copyWith =>
      _$ScheduleErrorCopyWithImpl<ScheduleError>(this, _$identity);

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is ScheduleError &&
            (identical(other.message, message) || other.message == message));
  }

  @override
  int get hashCode => Object.hash(runtimeType, message);

  @override
  String toString() {
    return 'SchedulePageState.error(message: $message)';
  }
}

/// @nodoc
abstract mixin class $ScheduleErrorCopyWith<$Res>
    implements $SchedulePageStateCopyWith<$Res> {
  factory $ScheduleErrorCopyWith(
          ScheduleError value, $Res Function(ScheduleError) _then) =
      _$ScheduleErrorCopyWithImpl;
  @useResult
  $Res call({String message});
}

/// @nodoc
class _$ScheduleErrorCopyWithImpl<$Res>
    implements $ScheduleErrorCopyWith<$Res> {
  _$ScheduleErrorCopyWithImpl(this._self, this._then);

  final ScheduleError _self;
  final $Res Function(ScheduleError) _then;

  /// Create a copy of SchedulePageState
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  $Res call({
    Object? message = null,
  }) {
    return _then(ScheduleError(
      null == message
          ? _self.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

// dart format on
