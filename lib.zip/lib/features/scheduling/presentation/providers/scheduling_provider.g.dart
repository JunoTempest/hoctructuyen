// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'scheduling_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(userBookings)
const userBookingsProvider = UserBookingsProvider._();

final class UserBookingsProvider extends $FunctionalProvider<
        AsyncValue<List<BookingEntity>>,
        List<BookingEntity>,
        Stream<List<BookingEntity>>>
    with
        $FutureModifier<List<BookingEntity>>,
        $StreamProvider<List<BookingEntity>> {
  const UserBookingsProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'userBookingsProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$userBookingsHash();

  @$internal
  @override
  $StreamProviderElement<List<BookingEntity>> $createElement(
          $ProviderPointer pointer) =>
      $StreamProviderElement(pointer);

  @override
  Stream<List<BookingEntity>> create(Ref ref) {
    return userBookings(ref);
  }
}

String _$userBookingsHash() => r'd58036c3e4600af49e8fca94105bb7af44d4dd2d';

@ProviderFor(userSessions)
const userSessionsProvider = UserSessionsProvider._();

final class UserSessionsProvider extends $FunctionalProvider<
        AsyncValue<List<SessionEntity>>,
        List<SessionEntity>,
        Stream<List<SessionEntity>>>
    with
        $FutureModifier<List<SessionEntity>>,
        $StreamProvider<List<SessionEntity>> {
  const UserSessionsProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'userSessionsProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$userSessionsHash();

  @$internal
  @override
  $StreamProviderElement<List<SessionEntity>> $createElement(
          $ProviderPointer pointer) =>
      $StreamProviderElement(pointer);

  @override
  Stream<List<SessionEntity>> create(Ref ref) {
    return userSessions(ref);
  }
}

String _$userSessionsHash() => r'685472579b7505f5c1c5533e3bf17e65cc03da9b';

@ProviderFor(teacherSchedules)
const teacherSchedulesProvider = TeacherSchedulesFamily._();

final class TeacherSchedulesProvider extends $FunctionalProvider<
        AsyncValue<List<ScheduleEntity>>,
        List<ScheduleEntity>,
        Stream<List<ScheduleEntity>>>
    with
        $FutureModifier<List<ScheduleEntity>>,
        $StreamProvider<List<ScheduleEntity>> {
  const TeacherSchedulesProvider._(
      {required TeacherSchedulesFamily super.from,
      required String super.argument})
      : super(
          retry: null,
          name: r'teacherSchedulesProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$teacherSchedulesHash();

  @override
  String toString() {
    return r'teacherSchedulesProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $StreamProviderElement<List<ScheduleEntity>> $createElement(
          $ProviderPointer pointer) =>
      $StreamProviderElement(pointer);

  @override
  Stream<List<ScheduleEntity>> create(Ref ref) {
    final argument = this.argument as String;
    return teacherSchedules(
      ref,
      argument,
    );
  }

  @override
  bool operator ==(Object other) {
    return other is TeacherSchedulesProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$teacherSchedulesHash() => r'49c2046a802ba63f93c853fc284c4debc6026d70';

final class TeacherSchedulesFamily extends $Family
    with $FunctionalFamilyOverride<Stream<List<ScheduleEntity>>, String> {
  const TeacherSchedulesFamily._()
      : super(
          retry: null,
          name: r'teacherSchedulesProvider',
          dependencies: null,
          $allTransitiveDependencies: null,
          isAutoDispose: true,
        );

  TeacherSchedulesProvider call(
    String teacherId,
  ) =>
      TeacherSchedulesProvider._(argument: teacherId, from: this);

  @override
  String toString() => r'teacherSchedulesProvider';
}

@ProviderFor(availableSlots)
const availableSlotsProvider = AvailableSlotsProvider._();

final class AvailableSlotsProvider extends $FunctionalProvider<
        AsyncValue<List<ScheduleEntity>>,
        List<ScheduleEntity>,
        FutureOr<List<ScheduleEntity>>>
    with
        $FutureModifier<List<ScheduleEntity>>,
        $FutureProvider<List<ScheduleEntity>> {
  const AvailableSlotsProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'availableSlotsProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$availableSlotsHash();

  @$internal
  @override
  $FutureProviderElement<List<ScheduleEntity>> $createElement(
          $ProviderPointer pointer) =>
      $FutureProviderElement(pointer);

  @override
  FutureOr<List<ScheduleEntity>> create(Ref ref) {
    return availableSlots(ref);
  }
}

String _$availableSlotsHash() => r'0ce45f428eb4b224713147f27049501853e75fd8';

@ProviderFor(ScheduleViewModel)
const scheduleViewModelProvider = ScheduleViewModelProvider._();

final class ScheduleViewModelProvider
    extends $NotifierProvider<ScheduleViewModel, SchedulePageState> {
  const ScheduleViewModelProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'scheduleViewModelProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$scheduleViewModelHash();

  @$internal
  @override
  ScheduleViewModel create() => ScheduleViewModel();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(SchedulePageState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<SchedulePageState>(value),
    );
  }
}

String _$scheduleViewModelHash() => r'69eadba30c3f272351b94422e0d6c662b8480e9b';

abstract class _$ScheduleViewModel extends $Notifier<SchedulePageState> {
  SchedulePageState build();
  @$mustCallSuper
  @override
  void runBuild() {
    final created = build();
    final ref = this.ref as $Ref<SchedulePageState, SchedulePageState>;
    final element = ref.element as $ClassProviderElement<
        AnyNotifier<SchedulePageState, SchedulePageState>,
        SchedulePageState,
        Object?,
        Object?>;
    element.handleValue(ref, created);
  }
}
