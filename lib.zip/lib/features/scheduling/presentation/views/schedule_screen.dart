import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../../app/router/app_router.dart';
import '../../../../app/theme/app_theme.dart';
import '../../../../core/constants/app_enums.dart';
import '../../../../core/di/usecase_providers.dart';
import '../../../../core/utils/responsive.dart';
import '../../../auth/domain/entities/user_entity.dart';
import '../../../auth/presentation/providers/auth_provider.dart';
import '../providers/scheduling_provider.dart';
import '../../domain/entities/session_entity.dart';
import '../../domain/entities/booking_entity.dart';

class ScheduleScreen extends ConsumerWidget {
  const ScheduleScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authStateStreamProvider).value;
    if (user == null) return const SizedBox();

    return Scaffold(
      appBar: AppBar(
        title: Text(user.isTeacher ? 'Lịch rảnh của tôi' : 'Lịch học'),
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 800),
          child: user.isTeacher
              ? _TeacherScheduleView(user: user)
              : _StudentScheduleView(user: user),
        ),
      ),
      floatingActionButton: user.isTeacher
          ? FloatingActionButton.extended(
              onPressed: () => _showCreateSlotDialog(context, ref, user),
              icon: const Icon(Icons.add),
              label: const Text('Đăng ký lịch rảnh'),
            )
          : null,
    );
  }

  void _showCreateSlotDialog(BuildContext ctx, WidgetRef ref, UserEntity user) {
    showModalBottomSheet(
      context: ctx,
      isScrollControlled: true,
      useSafeArea: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => _CreateSlotSheet(user: user),
    );
  }
}

// ── Teacher: xem lịch rảnh + booking nhận được ───────────────
class _TeacherScheduleView extends ConsumerWidget {
  const _TeacherScheduleView({required this.user});
  final UserEntity user;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return DefaultTabController(
      length: 3,
      child: Column(
        children: [
          const TabBar(
            tabs: [
              Tab(text: 'Buổi dạy'),
              Tab(text: 'Lịch rảnh'),
              Tab(text: 'Booking'),
            ],
          ),
          Expanded(
            child: TabBarView(
              children: [
                _TeacherSessionsList(user: user),
                _TeacherSlotsList(user: user),
                _TeacherBookingsList(user: user),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// Danh sách buổi dạy của GV với nút "Vào dạy"
class _TeacherSessionsList extends ConsumerWidget {
  const _TeacherSessionsList({required this.user});
  final UserEntity user;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sessionsAsync = ref.watch(userSessionsProvider);
    final df = DateFormat('HH:mm, dd/MM/yyyy');

    return sessionsAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => _ErrorView(message: e.toString()),
      data: (sessions) {
        final mySessions = sessions
            .where((s) => s.teacherId == user.id)
            .toList()
          ..sort((a, b) => b.startTime.compareTo(a.startTime));

        if (mySessions.isEmpty) {
          return const _EmptyState(
            icon: Icons.video_call_outlined,
            message: 'Chưa có buổi dạy nào\nHọc sinh sẽ đặt lịch với bạn',
          );
        }
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: mySessions.length,
          itemBuilder: (_, i) {
            final s = mySessions[i];
            final canJoin = s.isScheduled || s.isOngoing;
            return Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Row(
                  children: [
                    Container(
                      width: 50, height: 50,
                      decoration: BoxDecoration(
                        color: canJoin
                            ? AppColors.primary.withValues(alpha: 0.1)
                            : AppColors.textSub.withValues(alpha: 0.08),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(
                        canJoin ? Icons.video_call_rounded : Icons.videocam_off_outlined,
                        color: canJoin ? AppColors.primary : AppColors.textSub,
                        size: 28,
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(s.subjectName ?? 'Buổi học',
                              style: const TextStyle(fontWeight: FontWeight.w700)),
                          Text('HS: ${s.studentName ?? "Học sinh"}',
                              style: const TextStyle(
                                fontSize: 13, color: AppColors.textSecondary)),
                          Text(df.format(s.startTime),
                              style: const TextStyle(
                                fontSize: 12, color: AppColors.textSub)),
                        ],
                      ),
                    ),
                    if (canJoin)
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          minimumSize: const Size(0, 40),
                          padding: const EdgeInsets.symmetric(horizontal: 14),
                          backgroundColor: AppColors.primary,
                        ),
                        onPressed: () => context.push(
                          AppRoutes.classroomPath(s.sessionId),
                          extra: {
                            'channelName': s.agoraChannel,
                            'title': s.subjectName ?? 'Buổi dạy',
                            'startTime': s.startTime,
                          },
                        ),
                        icon: const Icon(Icons.play_arrow, size: 18),
                        label: const Text('Vào dạy'),
                      )
                    else
                      _StatusChip(
                        status: s.status.label,
                        isPending: false,
                      ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}

class _TeacherSlotsList extends ConsumerWidget {
  const _TeacherSlotsList({required this.user});
  final UserEntity user;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final slotsAsync = ref.watch(teacherSchedulesProvider(user.id));
    final df = DateFormat('HH:mm - dd/MM/yyyy');

    return slotsAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => _ErrorView(message: e.toString()),
      data: (slots) {
        if (slots.isEmpty) {
          return _EmptyState(
            icon: Icons.calendar_today_outlined,
            message: 'Chưa có lịch rảnh\nNhấn + để đăng ký khung giờ rảnh',
          );
        }
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: slots.length,
          itemBuilder: (_, i) {
            final s = slots[i];
            return Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                leading: Container(
                  width: 48, height: 48,
                  decoration: BoxDecoration(
                    color: s.isBooked
                        ? AppColors.warning.withValues(alpha: 0.12)
                        : AppColors.success.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(
                    s.isBooked ? Icons.lock_clock : Icons.event_available,
                    color: s.isBooked ? AppColors.warning : AppColors.success,
                  ),
                ),
                title: Text(df.format(s.startTime),
                    style: const TextStyle(fontWeight: FontWeight.w600)),
                subtitle: Text(
                  '${_duration(s.startTime, s.endTime)} · ${s.subject ?? "Chưa có môn"}',
                ),
                trailing: s.isBooked
                    ? const Chip(label: Text('Đã đặt'))
                    : const Chip(label: Text('Còn trống')),
              ),
            );
          },
        );
      },
    );
  }
}

class _TeacherBookingsList extends ConsumerWidget {
  const _TeacherBookingsList({required this.user});
  final UserEntity user;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final bookingsAsync = ref.watch(userBookingsProvider);
    final df = DateFormat('HH:mm, dd/MM/yyyy');

    return bookingsAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => _ErrorView(message: e.toString()),
      data: (bookings) {
        final myBookings = bookings.where((b) => b.teacherId == user.id).toList();
        if (myBookings.isEmpty) {
          return const _EmptyState(
            icon: Icons.inbox_outlined,
            message: 'Chưa có booking nào từ học sinh',
          );
        }
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: myBookings.length,
          itemBuilder: (_, i) {
            final b = myBookings[i];
            final isPending = b.status == BookingStatus.pending;
            return Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        CircleAvatar(
                          radius: 18,
                          backgroundColor: AppColors.primary.withValues(alpha: 0.1),
                          child: Text(
                            (b.studentName ?? 'H')[0].toUpperCase(),
                            style: const TextStyle(
                              color: AppColors.primary, fontWeight: FontWeight.w700),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(b.studentName ?? 'Học sinh',
                                  style: const TextStyle(fontWeight: FontWeight.w700)),
                              Text(df.format(b.startTime),
                                  style: const TextStyle(
                                    fontSize: 12, color: AppColors.textSub)),
                            ],
                          ),
                        ),
                        _StatusChip(status: b.status.label, isPending: isPending),
                      ],
                    ),
                    if (isPending) ...[
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton.icon(
                              style: OutlinedButton.styleFrom(
                                minimumSize: const Size(0, 40),
                                foregroundColor: AppColors.error,
                                side: const BorderSide(color: AppColors.error),
                              ),
                              onPressed: () => ref
                                  .read(scheduleViewModelProvider.notifier)
                                  .cancelBooking(b.bookingId),
                              icon: const Icon(Icons.close, size: 16),
                              label: const Text('Từ chối'),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: ElevatedButton.icon(
                              style: ElevatedButton.styleFrom(
                                minimumSize: const Size(0, 40),
                              ),
                              onPressed: () => ref
                                  .read(scheduleViewModelProvider.notifier)
                                  .confirmBooking(b.bookingId),
                              icon: const Icon(Icons.check, size: 16),
                              label: const Text('Xác nhận'),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}

// ── Student: xem lịch + buổi học ─────────────────────────────
class _StudentScheduleView extends ConsumerWidget {
  const _StudentScheduleView({required this.user});
  final UserEntity user;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return DefaultTabController(
      length: 2,
      child: Column(
        children: [
          const TabBar(
            tabs: [
              Tab(text: 'Buổi học của tôi'),
              Tab(text: 'Tìm giáo viên'),
            ],
          ),
          Expanded(
            child: TabBarView(
              children: [
                _StudentSessionsList(user: user),
                _AvailableSlotsList(user: user),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _StudentSessionsList extends ConsumerWidget {
  const _StudentSessionsList({required this.user});
  final UserEntity user;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sessionsAsync = ref.watch(userSessionsProvider);
    final df = DateFormat('HH:mm, dd/MM/yyyy');

    return sessionsAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => _ErrorView(message: e.toString()),
      data: (sessions) {
        if (sessions.isEmpty) {
          return const _EmptyState(
            icon: Icons.school_outlined,
            message: 'Chưa có buổi học\nĐặt lịch với giáo viên ở tab "Tìm giáo viên"',
          );
        }
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: sessions.length,
          itemBuilder: (_, i) {
            final s = sessions[i];
            final canJoin = s.isScheduled || s.isOngoing;
            return Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Row(
                  children: [
                    Container(
                      width: 50, height: 50,
                      decoration: BoxDecoration(
                        color: AppColors.primary.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(Icons.video_call_rounded,
                          color: AppColors.primary, size: 28),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(s.subjectName ?? 'Buổi học',
                              style: const TextStyle(fontWeight: FontWeight.w700)),
                          Text('GV: ${s.teacherName ?? "Giáo viên"}',
                              style: const TextStyle(
                                fontSize: 13, color: AppColors.textSecondary)),
                          Text(df.format(s.startTime),
                              style: const TextStyle(
                                fontSize: 12, color: AppColors.textSub)),
                        ],
                      ),
                    ),
                    if (canJoin)
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          minimumSize: const Size(0, 40),
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                        ),
                        onPressed: () => context.push(
                          AppRoutes.classroomPath(s.sessionId),
                          extra: {
                            'channelName': s.agoraChannel,
                            'title': s.subjectName ?? 'Buổi học',
                            'startTime': s.startTime,
                          },
                        ),
                        icon: const Icon(Icons.play_arrow, size: 18),
                        label: const Text('Vào học'),
                      )
                    else
                      _StatusChip(
                        status: s.status.label,
                        isPending: false,
                      ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}

class _AvailableSlotsList extends ConsumerWidget {
  const _AvailableSlotsList({required this.user});
  final UserEntity user;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final slotsAsync = ref.watch(availableSlotsProvider);
    final df = DateFormat('HH:mm - dd/MM/yyyy');

    return slotsAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => _ErrorView(message: e.toString()),
      data: (slots) {
        if (slots.isEmpty) {
          return const _EmptyState(
            icon: Icons.search_off,
            message: 'Hiện chưa có giáo viên nào tạo lịch rảnh',
          );
        }
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: slots.length,
          itemBuilder: (_, i) {
            final s = slots[i];
            return Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                leading: CircleAvatar(
                  backgroundColor: AppColors.teacherColor.withValues(alpha: 0.1),
                  child: const Icon(Icons.person, color: AppColors.teacherColor),
                ),
                title: Text(s.subject ?? 'Dạy học',
                    style: const TextStyle(fontWeight: FontWeight.w600)),
                subtitle: Text('${df.format(s.startTime)}\n${_duration(s.startTime, s.endTime)}'),
                isThreeLine: true,
                trailing: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    minimumSize: const Size(80, 38),
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                  ),
                  onPressed: () => _confirmBook(context, ref, s.scheduleId, user.id, s.teacherId),
                  child: const Text('Đặt'),
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _confirmBook(BuildContext ctx, WidgetRef ref,
      String scheduleId, String studentId, String teacherId) {
    showDialog(
      context: ctx,
      builder: (dCtx) => AlertDialog(
        title: const Text('Xác nhận đặt lịch'),
        content: const Text('Bạn muốn đặt lịch học với giáo viên này?\nGiáo viên sẽ cần xác nhận.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dCtx),
            child: const Text('Huỷ'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(minimumSize: const Size(80, 40)),
            onPressed: () {
              Navigator.pop(dCtx);
              ref.read(scheduleViewModelProvider.notifier).bookSlot(
                studentId: studentId,
                teacherId: teacherId,
                scheduleId: scheduleId,
              );
            },
            child: const Text('Xác nhận'),
          ),
        ],
      ),
    );
  }
}

// ── Create slot sheet ─────────────────────────────────────────
class _CreateSlotSheet extends ConsumerStatefulWidget {
  const _CreateSlotSheet({required this.user});
  final UserEntity user;

  @override
  ConsumerState<_CreateSlotSheet> createState() => _CreateSlotSheetState();
}

class _CreateSlotSheetState extends ConsumerState<_CreateSlotSheet> {
  DateTime? _start;
  DateTime? _end;
  final _subjectCtrl = TextEditingController();
  bool _loading = false;
  bool _isNow = false; // Chế độ "ngay bây giờ"
  int _durationMinutes = 60; // Thời lượng mặc định khi chọn "ngay bây giờ"

  @override
  void dispose() { _subjectCtrl.dispose(); super.dispose(); }

  void _setNow(bool v) {
    setState(() {
      _isNow = v;
      if (v) {
        final now = DateTime.now();
        _start = now;
        _end = now.add(Duration(minutes: _durationMinutes));
      } else {
        _start = null;
        _end = null;
      }
    });
  }

  void _setDuration(int minutes) {
    setState(() {
      _durationMinutes = minutes;
      if (_isNow) {
        _start = DateTime.now();
        _end = _start!.add(Duration(minutes: minutes));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
        left: 20, right: 20, top: 24,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              const Icon(Icons.calendar_today, color: AppColors.primary),
              const SizedBox(width: 10),
              const Text('Đăng ký lịch rảnh',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const Spacer(),
              IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close)),
            ],
          ),
          const SizedBox(height: 4),
          const Text('Học sinh sẽ thấy khung giờ này và có thể đặt lịch',
              style: TextStyle(color: AppColors.textSub, fontSize: 13)),
          const SizedBox(height: 16),

          // Môn học
          TextFormField(
            controller: _subjectCtrl,
            decoration: const InputDecoration(
              labelText: 'Môn học (tuỳ chọn)',
              prefixIcon: Icon(Icons.subject),
            ),
          ),
          const SizedBox(height: 16),

          // Toggle: Ngay bây giờ vs Chọn thời gian
          Row(
            children: [
              Expanded(
                child: _ModeBtn(
                  icon: Icons.bolt,
                  label: 'Ngay bây giờ',
                  selected: _isNow,
                  onTap: () => _setNow(true),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _ModeBtn(
                  icon: Icons.schedule,
                  label: 'Chọn thời gian',
                  selected: !_isNow,
                  onTap: () => _setNow(false),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),

          // Nếu chọn "Ngay bây giờ" → chọn thời lượng
          if (_isNow) ...[
            const Text('Thời lượng buổi học:',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: [30, 45, 60, 90, 120].map((m) => ChoiceChip(
                label: Text(m >= 60
                    ? '${m ~/ 60}h${m % 60 > 0 ? "${m % 60}p" : ""}'
                    : '${m}p'),
                selected: _durationMinutes == m,
                onSelected: (_) => _setDuration(m),
              )).toList(),
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppColors.primary.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  const Icon(Icons.info_outline, size: 16, color: AppColors.primary),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Bắt đầu ngay · kết thúc lúc ${_end != null ? DateFormat("HH:mm").format(_end!) : "--:--"}',
                      style: const TextStyle(fontSize: 12, color: AppColors.primary),
                    ),
                  ),
                ],
              ),
            ),
          ] else ...[
            // Chọn thời gian thủ công
            _DateTimePicker(
              label: 'Thời gian bắt đầu',
              value: _start,
              onPicked: (dt) => setState(() => _start = dt),
            ),
            const SizedBox(height: 12),
            _DateTimePicker(
              label: 'Thời gian kết thúc',
              value: _end,
              onPicked: (dt) => setState(() => _end = dt),
            ),
          ],

          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _loading || _start == null || _end == null ? null : _submit,
              icon: _loading
                  ? const SizedBox(width: 18, height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : Icon(_isNow ? Icons.bolt : Icons.check),
              label: Text(_isNow ? 'Mở lớp ngay' : 'Tạo lịch rảnh'),
            ),
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  Future<void> _submit() async {
    if (!_isNow && _end!.isBefore(_start!)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Thời gian kết thúc phải sau bắt đầu'),
            backgroundColor: AppColors.error));
      return;
    }
    setState(() => _loading = true);
    try {
      await ref.read(createScheduleUseCaseProvider).call(
        teacherId: widget.user.id,
        startTime: _start!,
        endTime:   _end!,
        subject:   _subjectCtrl.text.trim().isEmpty ? null : _subjectCtrl.text.trim(),
      );
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString()), backgroundColor: AppColors.error));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }
}

// Nút chọn chế độ lịch
class _ModeBtn extends StatelessWidget {
  const _ModeBtn({
    required this.icon,
    required this.label,
    required this.selected,
    required this.onTap,
  });
  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: selected
                ? AppColors.primary.withValues(alpha: 0.12)
                : Theme.of(context).inputDecorationTheme.fillColor,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: selected ? AppColors.primary : AppColors.border,
              width: selected ? 1.5 : 1,
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon,
                  size: 18,
                  color: selected ? AppColors.primary : AppColors.textSub),
              const SizedBox(width: 6),
              Text(label,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: selected ? FontWeight.w700 : FontWeight.normal,
                    color: selected ? AppColors.primary : AppColors.textSub,
                  )),
            ],
          ),
        ),
      );
}

class _DateTimePicker extends StatelessWidget {
  const _DateTimePicker({required this.label, required this.value, required this.onPicked});
  final String label;
  final DateTime? value;
  final ValueChanged<DateTime> onPicked;

  @override
  Widget build(BuildContext context) {
    final df = DateFormat('HH:mm, dd/MM/yyyy');
    return GestureDetector(
      onTap: () async {
        final date = await showDatePicker(
          context: context,
          initialDate: DateTime.now(),
          firstDate: DateTime.now(),
          lastDate: DateTime.now().add(const Duration(days: 90)),
        );
        if (date == null || !context.mounted) return;
        final time = await showTimePicker(
          context: context,
          initialTime: TimeOfDay.fromDateTime(DateTime.now()),
        );
        if (time == null) return;
        onPicked(DateTime(date.year, date.month, date.day, time.hour, time.minute));
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        decoration: BoxDecoration(
          color: Theme.of(context).inputDecorationTheme.fillColor,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            const Icon(Icons.schedule, size: 18, color: AppColors.textSub),
            const SizedBox(width: 10),
            Text(
              value != null ? df.format(value!) : label,
              style: TextStyle(color: value != null ? null : AppColors.textSub),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Helpers ───────────────────────────────────────────────────
String _duration(DateTime start, DateTime end) {
  final diff = end.difference(start);
  if (diff.inHours >= 1) return '${diff.inHours}h${diff.inMinutes % 60 > 0 ? "${diff.inMinutes % 60}p" : ""}';
  return '${diff.inMinutes} phút';
}

class _StatusChip extends StatelessWidget {
  const _StatusChip({required this.status, required this.isPending});
  final String status;
  final bool isPending;

  @override
  Widget build(BuildContext context) => Chip(
    label: Text(status, style: const TextStyle(fontSize: 11)),
    backgroundColor: isPending
        ? AppColors.warning.withValues(alpha: 0.1)
        : AppColors.success.withValues(alpha: 0.1),
    side: BorderSide.none,
    padding: EdgeInsets.zero,
  );
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.icon, required this.message});
  final IconData icon;
  final String message;

  @override
  Widget build(BuildContext context) => Center(
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 56, color: AppColors.textSub),
        const SizedBox(height: 16),
        Text(message,
          style: const TextStyle(color: AppColors.textSub, height: 1.6),
          textAlign: TextAlign.center),
      ],
    ),
  );
}

class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.message});
  final String message;

  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.error_outline, color: AppColors.error, size: 48),
          const SizedBox(height: 12),
          Text('Có lỗi xảy ra', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Text(message,
            style: const TextStyle(color: AppColors.textSub, fontSize: 12),
            textAlign: TextAlign.center),
        ],
      ),
    ),
  );
}
