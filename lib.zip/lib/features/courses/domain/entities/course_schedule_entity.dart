class CourseScheduleEntry {
  const CourseScheduleEntry({
    required this.dayOfWeek,
    required this.hour,
    required this.minute,
    required this.durationMinutes,
  });

  final int dayOfWeek;       // 1=T2 ... 7=CN
  final int hour;
  final int minute;
  final int durationMinutes;

  String get dayLabel => const {
        1:'Thứ 2', 2:'Thứ 3', 3:'Thứ 4',
        4:'Thứ 5', 5:'Thứ 6', 6:'Thứ 7', 7:'CN',
      }[dayOfWeek] ?? 'CN';

  String get timeLabel {
    final sh = hour.toString().padLeft(2, '0');
    final sm = minute.toString().padLeft(2, '0');
    final total = hour * 60 + minute + durationMinutes;
    final eh = (total ~/ 60).toString().padLeft(2, '0');
    final em = (total % 60).toString().padLeft(2, '0');
    return '$sh:$sm – $eh:$em';
  }

  Map<String, dynamic> toMap() => {
        'dayOfWeek': dayOfWeek,
        'hour': hour,
        'minute': minute,
        'durationMinutes': durationMinutes,
      };

  factory CourseScheduleEntry.fromMap(Map<String, dynamic> m) =>
      CourseScheduleEntry(
        dayOfWeek:       m['dayOfWeek'] as int,
        hour:            m['hour']      as int,
        minute:          m['minute']    as int,
        durationMinutes: m['durationMinutes'] as int? ?? 90,
      );
}
