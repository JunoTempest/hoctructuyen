import '../../../../core/constants/app_enums.dart';
import 'course_schedule_entity.dart';

class CourseEntity {
  const CourseEntity({
    required this.courseId,
    required this.teacherId,
    required this.title,
    required this.description,
    required this.subject,
    required this.totalSessions,
    required this.pricePerCourse,
    required this.scheduleEntries,
    required this.startDate,
    required this.maxStudents,
    required this.enrolledCount,
    required this.status,
    required this.createdAt,
    this.teacherName,
    this.teacherPhotoUrl,
    this.teacherRating,
    this.thumbnailUrl,
    this.level,
  });

  final String courseId;
  final String teacherId;
  final String title;
  final String description;
  final String subject;
  final int totalSessions;
  final double pricePerCourse;
  final List<CourseScheduleEntry> scheduleEntries;
  final DateTime startDate;
  final int maxStudents;
  final int enrolledCount;
  final CourseStatus status;
  final DateTime createdAt;
  final String? teacherName;
  final String? teacherPhotoUrl;
  final double? teacherRating;
  final String? thumbnailUrl;
  final String? level;

  int get remainingSlots => maxStudents - enrolledCount;
  bool get isFull  => enrolledCount >= maxStudents;
  bool get isOpen  => status == CourseStatus.open && !isFull;
  double get pricePerSession =>
      totalSessions > 0 ? pricePerCourse / totalSessions : 0;

  String get formattedPrice {
    final n = pricePerCourse.toInt();
    return '${n.toString().replaceAllMapped(
          RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.')}đ';
  }

  String get formattedPricePerSession {
    final n = pricePerSession.toInt();
    return '${n.toString().replaceAllMapped(
          RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.')}đ/buổi';
  }

  String get scheduleLabel {
    if (scheduleEntries.isEmpty) return 'Chưa có lịch';
    final days = scheduleEntries.map((e) => e.dayLabel).join(', ');
    final time = scheduleEntries.first.timeLabel;
    return '$days • $time';
  }
}
