import '../../../../core/constants/app_enums.dart';

class EnrollmentEntity {
  const EnrollmentEntity({
    required this.enrollmentId,
    required this.courseId,
    required this.studentId,
    required this.status,
    required this.createdAt,
    this.courseTitle,
    this.teacherName,
    this.teacherId,
    this.studentName,
    this.totalSessions,
    this.completedSessions,
    this.startDate,
    this.pricePerCourse,
  });

  final String enrollmentId;
  final String courseId;
  final String studentId;
  final EnrollmentStatus status;
  final DateTime createdAt;
  final String? courseTitle;
  final String? teacherName;
  final String? teacherId;
  final String? studentName;
  final int?    totalSessions;
  final int?    completedSessions;
  final DateTime? startDate;
  final double?   pricePerCourse;

  bool get isPending   => status == EnrollmentStatus.pending;
  bool get isConfirmed => status == EnrollmentStatus.confirmed;
  bool get isCancelled => status == EnrollmentStatus.cancelled;
  bool get isCompleted => status == EnrollmentStatus.completed;

  String get progressLabel =>
      totalSessions != null ? '${completedSessions ?? 0}/$totalSessions buổi' : '';

  double get progressPercent {
    if (totalSessions == null || totalSessions == 0) return 0;
    return ((completedSessions ?? 0) / totalSessions!).clamp(0.0, 1.0);
  }
}
