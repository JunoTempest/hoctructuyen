import '../entities/course_entity.dart';
import '../entities/course_schedule_entity.dart';
import '../entities/enrollment_entity.dart';
import '../repositories/course_repository.dart';

class GetOpenCoursesUseCase {
  const GetOpenCoursesUseCase(this._repo);
  final CourseRepository _repo;
  Future<List<CourseEntity>> call({String? subject, String? teacherId}) =>
      _repo.getOpenCourses(subject: subject, teacherId: teacherId);
}

class GetCourseUseCase {
  const GetCourseUseCase(this._repo);
  final CourseRepository _repo;
  Future<CourseEntity> call(String courseId) => _repo.getCourse(courseId);
}

class CreateCourseUseCase {
  const CreateCourseUseCase(this._repo);
  final CourseRepository _repo;

  Future<CourseEntity> call({
    required String teacherId,
    required String title,
    required String description,
    required String subject,
    required int totalSessions,
    required double pricePerCourse,
    required List<CourseScheduleEntry> scheduleEntries,
    required DateTime startDate,
    required int maxStudents,
    String? level,
  }) {
    if (title.trim().isEmpty)     throw ArgumentError('Tên khóa học không được trống');
    if (totalSessions < 1)        throw ArgumentError('Phải có ít nhất 1 buổi');
    if (scheduleEntries.isEmpty)  throw ArgumentError('Phải chọn ít nhất 1 ngày học');
    if (startDate.isBefore(DateTime.now())) throw ArgumentError('Ngày bắt đầu phải trong tương lai');

    return _repo.createCourse(
      teacherId: teacherId, title: title.trim(),
      description: description.trim(), subject: subject,
      totalSessions: totalSessions, pricePerCourse: pricePerCourse,
      scheduleEntries: scheduleEntries, startDate: startDate,
      maxStudents: maxStudents, level: level,
    );
  }
}

class EnrollCourseUseCase {
  const EnrollCourseUseCase(this._repo);
  final CourseRepository _repo;

  Future<EnrollmentEntity> call({
    required String studentId,
    required String courseId,
  }) async {
    final existing = await _repo.getMyEnrollment(
        studentId: studentId, courseId: courseId);
    if (existing != null && !existing.isCancelled) {
      throw Exception('Bạn đã đăng ký khóa học này rồi');
    }
    return _repo.enrollCourse(studentId: studentId, courseId: courseId);
  }
}

class ConfirmEnrollmentUseCase {
  const ConfirmEnrollmentUseCase(this._repo);
  final CourseRepository _repo;
  Future<EnrollmentEntity> call(String enrollmentId) =>
      _repo.confirmEnrollment(enrollmentId);
}

class CancelEnrollmentUseCase {
  const CancelEnrollmentUseCase(this._repo);
  final CourseRepository _repo;
  Future<EnrollmentEntity> call(String enrollmentId) =>
      _repo.cancelEnrollment(enrollmentId);
}

class WatchStudentEnrollmentsUseCase {
  const WatchStudentEnrollmentsUseCase(this._repo);
  final CourseRepository _repo;
  Stream<List<EnrollmentEntity>> call(String studentId) =>
      _repo.watchStudentEnrollments(studentId);
}
