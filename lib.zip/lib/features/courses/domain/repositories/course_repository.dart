import '../entities/course_entity.dart';
import '../entities/course_schedule_entity.dart';
import '../entities/enrollment_entity.dart';
import '../../../../core/constants/app_enums.dart';

abstract interface class CourseRepository {
  Future<List<CourseEntity>> getOpenCourses({String? subject, String? teacherId});
  Future<CourseEntity> getCourse(String courseId);
  Future<CourseEntity> createCourse({
    required String teacherId,
    required String title,
    required String description,
    required String subject,
    required int totalSessions,
    required double pricePerCourse,
    required List<CourseScheduleEntry> scheduleEntries,
    required DateTime startDate,
    required int maxStudents,
    String? level,
    String? thumbnailUrl,
  });
  Future<void> updateCourseStatus(String courseId, CourseStatus status);
  Stream<List<CourseEntity>> watchTeacherCourses(String teacherId);

  Future<EnrollmentEntity> enrollCourse({
    required String studentId,
    required String courseId,
  });
  Future<EnrollmentEntity> confirmEnrollment(String enrollmentId);
  Future<EnrollmentEntity> cancelEnrollment(String enrollmentId);
  Stream<List<EnrollmentEntity>> watchStudentEnrollments(String studentId);
  Stream<List<EnrollmentEntity>> watchCourseEnrollments(String courseId);
  Future<EnrollmentEntity?> getMyEnrollment({
    required String studentId,
    required String courseId,
  });
}
