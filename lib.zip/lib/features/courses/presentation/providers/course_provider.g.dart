// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'course_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(openCourses)
const openCoursesProvider = OpenCoursesFamily._();

final class OpenCoursesProvider extends $FunctionalProvider<
        AsyncValue<List<CourseEntity>>,
        List<CourseEntity>,
        FutureOr<List<CourseEntity>>>
    with
        $FutureModifier<List<CourseEntity>>,
        $FutureProvider<List<CourseEntity>> {
  const OpenCoursesProvider._(
      {required OpenCoursesFamily super.from, required String? super.argument})
      : super(
          retry: null,
          name: r'openCoursesProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$openCoursesHash();

  @override
  String toString() {
    return r'openCoursesProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $FutureProviderElement<List<CourseEntity>> $createElement(
          $ProviderPointer pointer) =>
      $FutureProviderElement(pointer);

  @override
  FutureOr<List<CourseEntity>> create(Ref ref) {
    final argument = this.argument as String?;
    return openCourses(
      ref,
      subject: argument,
    );
  }

  @override
  bool operator ==(Object other) {
    return other is OpenCoursesProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$openCoursesHash() => r'053a0124879951536c3086ad4268a63021c08260';

final class OpenCoursesFamily extends $Family
    with $FunctionalFamilyOverride<FutureOr<List<CourseEntity>>, String?> {
  const OpenCoursesFamily._()
      : super(
          retry: null,
          name: r'openCoursesProvider',
          dependencies: null,
          $allTransitiveDependencies: null,
          isAutoDispose: true,
        );

  OpenCoursesProvider call({
    String? subject,
  }) =>
      OpenCoursesProvider._(argument: subject, from: this);

  @override
  String toString() => r'openCoursesProvider';
}

@ProviderFor(courseDetail)
const courseDetailProvider = CourseDetailFamily._();

final class CourseDetailProvider extends $FunctionalProvider<
        AsyncValue<CourseEntity>, CourseEntity, FutureOr<CourseEntity>>
    with $FutureModifier<CourseEntity>, $FutureProvider<CourseEntity> {
  const CourseDetailProvider._(
      {required CourseDetailFamily super.from, required String super.argument})
      : super(
          retry: null,
          name: r'courseDetailProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$courseDetailHash();

  @override
  String toString() {
    return r'courseDetailProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $FutureProviderElement<CourseEntity> $createElement(
          $ProviderPointer pointer) =>
      $FutureProviderElement(pointer);

  @override
  FutureOr<CourseEntity> create(Ref ref) {
    final argument = this.argument as String;
    return courseDetail(
      ref,
      argument,
    );
  }

  @override
  bool operator ==(Object other) {
    return other is CourseDetailProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$courseDetailHash() => r'1bbfbdf2d28eb1a3b54ce6fa3b6699aa187d3241';

final class CourseDetailFamily extends $Family
    with $FunctionalFamilyOverride<FutureOr<CourseEntity>, String> {
  const CourseDetailFamily._()
      : super(
          retry: null,
          name: r'courseDetailProvider',
          dependencies: null,
          $allTransitiveDependencies: null,
          isAutoDispose: true,
        );

  CourseDetailProvider call(
    String courseId,
  ) =>
      CourseDetailProvider._(argument: courseId, from: this);

  @override
  String toString() => r'courseDetailProvider';
}

@ProviderFor(myEnrollment)
const myEnrollmentProvider = MyEnrollmentFamily._();

final class MyEnrollmentProvider extends $FunctionalProvider<
        AsyncValue<EnrollmentEntity?>,
        EnrollmentEntity?,
        FutureOr<EnrollmentEntity?>>
    with
        $FutureModifier<EnrollmentEntity?>,
        $FutureProvider<EnrollmentEntity?> {
  const MyEnrollmentProvider._(
      {required MyEnrollmentFamily super.from, required String super.argument})
      : super(
          retry: null,
          name: r'myEnrollmentProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$myEnrollmentHash();

  @override
  String toString() {
    return r'myEnrollmentProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $FutureProviderElement<EnrollmentEntity?> $createElement(
          $ProviderPointer pointer) =>
      $FutureProviderElement(pointer);

  @override
  FutureOr<EnrollmentEntity?> create(Ref ref) {
    final argument = this.argument as String;
    return myEnrollment(
      ref,
      argument,
    );
  }

  @override
  bool operator ==(Object other) {
    return other is MyEnrollmentProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$myEnrollmentHash() => r'6e1cd671ba1d56162df39d82f216b99531d73b5f';

final class MyEnrollmentFamily extends $Family
    with $FunctionalFamilyOverride<FutureOr<EnrollmentEntity?>, String> {
  const MyEnrollmentFamily._()
      : super(
          retry: null,
          name: r'myEnrollmentProvider',
          dependencies: null,
          $allTransitiveDependencies: null,
          isAutoDispose: true,
        );

  MyEnrollmentProvider call(
    String courseId,
  ) =>
      MyEnrollmentProvider._(argument: courseId, from: this);

  @override
  String toString() => r'myEnrollmentProvider';
}

@ProviderFor(myEnrollments)
const myEnrollmentsProvider = MyEnrollmentsProvider._();

final class MyEnrollmentsProvider extends $FunctionalProvider<
        AsyncValue<List<EnrollmentEntity>>,
        List<EnrollmentEntity>,
        Stream<List<EnrollmentEntity>>>
    with
        $FutureModifier<List<EnrollmentEntity>>,
        $StreamProvider<List<EnrollmentEntity>> {
  const MyEnrollmentsProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'myEnrollmentsProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$myEnrollmentsHash();

  @$internal
  @override
  $StreamProviderElement<List<EnrollmentEntity>> $createElement(
          $ProviderPointer pointer) =>
      $StreamProviderElement(pointer);

  @override
  Stream<List<EnrollmentEntity>> create(Ref ref) {
    return myEnrollments(ref);
  }
}

String _$myEnrollmentsHash() => r'6e5a8231b07cfde9e6992b4ddd207bcfcf090c01';

@ProviderFor(teacherCourses)
const teacherCoursesProvider = TeacherCoursesProvider._();

final class TeacherCoursesProvider extends $FunctionalProvider<
        AsyncValue<List<CourseEntity>>,
        List<CourseEntity>,
        Stream<List<CourseEntity>>>
    with
        $FutureModifier<List<CourseEntity>>,
        $StreamProvider<List<CourseEntity>> {
  const TeacherCoursesProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'teacherCoursesProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$teacherCoursesHash();

  @$internal
  @override
  $StreamProviderElement<List<CourseEntity>> $createElement(
          $ProviderPointer pointer) =>
      $StreamProviderElement(pointer);

  @override
  Stream<List<CourseEntity>> create(Ref ref) {
    return teacherCourses(ref);
  }
}

String _$teacherCoursesHash() => r'3ef14685697da6887401be63b3eb043f5f113f35';

@ProviderFor(courseEnrollments)
const courseEnrollmentsProvider = CourseEnrollmentsFamily._();

final class CourseEnrollmentsProvider extends $FunctionalProvider<
        AsyncValue<List<EnrollmentEntity>>,
        List<EnrollmentEntity>,
        Stream<List<EnrollmentEntity>>>
    with
        $FutureModifier<List<EnrollmentEntity>>,
        $StreamProvider<List<EnrollmentEntity>> {
  const CourseEnrollmentsProvider._(
      {required CourseEnrollmentsFamily super.from,
      required String super.argument})
      : super(
          retry: null,
          name: r'courseEnrollmentsProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$courseEnrollmentsHash();

  @override
  String toString() {
    return r'courseEnrollmentsProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $StreamProviderElement<List<EnrollmentEntity>> $createElement(
          $ProviderPointer pointer) =>
      $StreamProviderElement(pointer);

  @override
  Stream<List<EnrollmentEntity>> create(Ref ref) {
    final argument = this.argument as String;
    return courseEnrollments(
      ref,
      argument,
    );
  }

  @override
  bool operator ==(Object other) {
    return other is CourseEnrollmentsProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$courseEnrollmentsHash() => r'4ebb8c04a5af3915d2638e0cf67ddc20adb3e77b';

final class CourseEnrollmentsFamily extends $Family
    with $FunctionalFamilyOverride<Stream<List<EnrollmentEntity>>, String> {
  const CourseEnrollmentsFamily._()
      : super(
          retry: null,
          name: r'courseEnrollmentsProvider',
          dependencies: null,
          $allTransitiveDependencies: null,
          isAutoDispose: true,
        );

  CourseEnrollmentsProvider call(
    String courseId,
  ) =>
      CourseEnrollmentsProvider._(argument: courseId, from: this);

  @override
  String toString() => r'courseEnrollmentsProvider';
}

@ProviderFor(CourseViewModel)
const courseViewModelProvider = CourseViewModelProvider._();

final class CourseViewModelProvider
    extends $NotifierProvider<CourseViewModel, CourseActionState> {
  const CourseViewModelProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'courseViewModelProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$courseViewModelHash();

  @$internal
  @override
  CourseViewModel create() => CourseViewModel();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(CourseActionState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<CourseActionState>(value),
    );
  }
}

String _$courseViewModelHash() => r'789de0d518c9925038442648dcadd69d44831f96';

abstract class _$CourseViewModel extends $Notifier<CourseActionState> {
  CourseActionState build();
  @$mustCallSuper
  @override
  void runBuild() {
    final created = build();
    final ref = this.ref as $Ref<CourseActionState, CourseActionState>;
    final element = ref.element as $ClassProviderElement<
        AnyNotifier<CourseActionState, CourseActionState>,
        CourseActionState,
        Object?,
        Object?>;
    element.handleValue(ref, created);
  }
}

@ProviderFor(TeacherCourseViewModel)
const teacherCourseViewModelProvider = TeacherCourseViewModelProvider._();

final class TeacherCourseViewModelProvider
    extends $NotifierProvider<TeacherCourseViewModel, CourseActionState> {
  const TeacherCourseViewModelProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'teacherCourseViewModelProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$teacherCourseViewModelHash();

  @$internal
  @override
  TeacherCourseViewModel create() => TeacherCourseViewModel();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(CourseActionState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<CourseActionState>(value),
    );
  }
}

String _$teacherCourseViewModelHash() =>
    r'989423ef97c44c7f279e7ff53ed23652a1ae0dd4';

abstract class _$TeacherCourseViewModel extends $Notifier<CourseActionState> {
  CourseActionState build();
  @$mustCallSuper
  @override
  void runBuild() {
    final created = build();
    final ref = this.ref as $Ref<CourseActionState, CourseActionState>;
    final element = ref.element as $ClassProviderElement<
        AnyNotifier<CourseActionState, CourseActionState>,
        CourseActionState,
        Object?,
        Object?>;
    element.handleValue(ref, created);
  }
}
