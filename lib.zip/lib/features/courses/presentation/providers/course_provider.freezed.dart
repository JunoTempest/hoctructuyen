// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'course_provider.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$CourseActionState {
  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is CourseActionState);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  String toString() {
    return 'CourseActionState()';
  }
}

/// @nodoc
class $CourseActionStateCopyWith<$Res> {
  $CourseActionStateCopyWith(
      CourseActionState _, $Res Function(CourseActionState) __);
}

/// Adds pattern-matching-related methods to [CourseActionState].
extension CourseActionStatePatterns on CourseActionState {
  /// A variant of `map` that fallback to returning `orElse`.
  ///
  /// It is equivalent to doing:
  /// ```dart
  /// switch (sealedClass) {
  ///   case final Subclass value:
  ///     return ...;
  ///   case _:
  ///     return orElse();
  /// }
  /// ```

  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(CourseIdle value)? idle,
    TResult Function(CourseLoading value)? loading,
    TResult Function(CourseEnrollSuccess value)? enrollSuccess,
    TResult Function(CourseCreateSuccess value)? createSuccess,
    TResult Function(CourseActionError value)? error,
    required TResult orElse(),
  }) {
    final _that = this;
    switch (_that) {
      case CourseIdle() when idle != null:
        return idle(_that);
      case CourseLoading() when loading != null:
        return loading(_that);
      case CourseEnrollSuccess() when enrollSuccess != null:
        return enrollSuccess(_that);
      case CourseCreateSuccess() when createSuccess != null:
        return createSuccess(_that);
      case CourseActionError() when error != null:
        return error(_that);
      case _:
        return orElse();
    }
  }

  /// A `switch`-like method, using callbacks.
  ///
  /// Callbacks receives the raw object, upcasted.
  /// It is equivalent to doing:
  /// ```dart
  /// switch (sealedClass) {
  ///   case final Subclass value:
  ///     return ...;
  ///   case final Subclass2 value:
  ///     return ...;
  /// }
  /// ```

  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(CourseIdle value) idle,
    required TResult Function(CourseLoading value) loading,
    required TResult Function(CourseEnrollSuccess value) enrollSuccess,
    required TResult Function(CourseCreateSuccess value) createSuccess,
    required TResult Function(CourseActionError value) error,
  }) {
    final _that = this;
    switch (_that) {
      case CourseIdle():
        return idle(_that);
      case CourseLoading():
        return loading(_that);
      case CourseEnrollSuccess():
        return enrollSuccess(_that);
      case CourseCreateSuccess():
        return createSuccess(_that);
      case CourseActionError():
        return error(_that);
    }
  }

  /// A variant of `map` that fallback to returning `null`.
  ///
  /// It is equivalent to doing:
  /// ```dart
  /// switch (sealedClass) {
  ///   case final Subclass value:
  ///     return ...;
  ///   case _:
  ///     return null;
  /// }
  /// ```

  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(CourseIdle value)? idle,
    TResult? Function(CourseLoading value)? loading,
    TResult? Function(CourseEnrollSuccess value)? enrollSuccess,
    TResult? Function(CourseCreateSuccess value)? createSuccess,
    TResult? Function(CourseActionError value)? error,
  }) {
    final _that = this;
    switch (_that) {
      case CourseIdle() when idle != null:
        return idle(_that);
      case CourseLoading() when loading != null:
        return loading(_that);
      case CourseEnrollSuccess() when enrollSuccess != null:
        return enrollSuccess(_that);
      case CourseCreateSuccess() when createSuccess != null:
        return createSuccess(_that);
      case CourseActionError() when error != null:
        return error(_that);
      case _:
        return null;
    }
  }

  /// A variant of `when` that fallback to an `orElse` callback.
  ///
  /// It is equivalent to doing:
  /// ```dart
  /// switch (sealedClass) {
  ///   case Subclass(:final field):
  ///     return ...;
  ///   case _:
  ///     return orElse();
  /// }
  /// ```

  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? idle,
    TResult Function()? loading,
    TResult Function(EnrollmentEntity e)? enrollSuccess,
    TResult Function(CourseEntity c)? createSuccess,
    TResult Function(String message)? error,
    required TResult orElse(),
  }) {
    final _that = this;
    switch (_that) {
      case CourseIdle() when idle != null:
        return idle();
      case CourseLoading() when loading != null:
        return loading();
      case CourseEnrollSuccess() when enrollSuccess != null:
        return enrollSuccess(_that.e);
      case CourseCreateSuccess() when createSuccess != null:
        return createSuccess(_that.c);
      case CourseActionError() when error != null:
        return error(_that.message);
      case _:
        return orElse();
    }
  }

  /// A `switch`-like method, using callbacks.
  ///
  /// As opposed to `map`, this offers destructuring.
  /// It is equivalent to doing:
  /// ```dart
  /// switch (sealedClass) {
  ///   case Subclass(:final field):
  ///     return ...;
  ///   case Subclass2(:final field2):
  ///     return ...;
  /// }
  /// ```

  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() idle,
    required TResult Function() loading,
    required TResult Function(EnrollmentEntity e) enrollSuccess,
    required TResult Function(CourseEntity c) createSuccess,
    required TResult Function(String message) error,
  }) {
    final _that = this;
    switch (_that) {
      case CourseIdle():
        return idle();
      case CourseLoading():
        return loading();
      case CourseEnrollSuccess():
        return enrollSuccess(_that.e);
      case CourseCreateSuccess():
        return createSuccess(_that.c);
      case CourseActionError():
        return error(_that.message);
    }
  }

  /// A variant of `when` that fallback to returning `null`
  ///
  /// It is equivalent to doing:
  /// ```dart
  /// switch (sealedClass) {
  ///   case Subclass(:final field):
  ///     return ...;
  ///   case _:
  ///     return null;
  /// }
  /// ```

  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? idle,
    TResult? Function()? loading,
    TResult? Function(EnrollmentEntity e)? enrollSuccess,
    TResult? Function(CourseEntity c)? createSuccess,
    TResult? Function(String message)? error,
  }) {
    final _that = this;
    switch (_that) {
      case CourseIdle() when idle != null:
        return idle();
      case CourseLoading() when loading != null:
        return loading();
      case CourseEnrollSuccess() when enrollSuccess != null:
        return enrollSuccess(_that.e);
      case CourseCreateSuccess() when createSuccess != null:
        return createSuccess(_that.c);
      case CourseActionError() when error != null:
        return error(_that.message);
      case _:
        return null;
    }
  }
}

/// @nodoc

class CourseIdle implements CourseActionState {
  const CourseIdle();

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is CourseIdle);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  String toString() {
    return 'CourseActionState.idle()';
  }
}

/// @nodoc

class CourseLoading implements CourseActionState {
  const CourseLoading();

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is CourseLoading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  String toString() {
    return 'CourseActionState.loading()';
  }
}

/// @nodoc

class CourseEnrollSuccess implements CourseActionState {
  const CourseEnrollSuccess(this.e);

  final EnrollmentEntity e;

  /// Create a copy of CourseActionState
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @pragma('vm:prefer-inline')
  $CourseEnrollSuccessCopyWith<CourseEnrollSuccess> get copyWith =>
      _$CourseEnrollSuccessCopyWithImpl<CourseEnrollSuccess>(this, _$identity);

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is CourseEnrollSuccess &&
            (identical(other.e, e) || other.e == e));
  }

  @override
  int get hashCode => Object.hash(runtimeType, e);

  @override
  String toString() {
    return 'CourseActionState.enrollSuccess(e: $e)';
  }
}

/// @nodoc
abstract mixin class $CourseEnrollSuccessCopyWith<$Res>
    implements $CourseActionStateCopyWith<$Res> {
  factory $CourseEnrollSuccessCopyWith(
          CourseEnrollSuccess value, $Res Function(CourseEnrollSuccess) _then) =
      _$CourseEnrollSuccessCopyWithImpl;
  @useResult
  $Res call({EnrollmentEntity e});
}

/// @nodoc
class _$CourseEnrollSuccessCopyWithImpl<$Res>
    implements $CourseEnrollSuccessCopyWith<$Res> {
  _$CourseEnrollSuccessCopyWithImpl(this._self, this._then);

  final CourseEnrollSuccess _self;
  final $Res Function(CourseEnrollSuccess) _then;

  /// Create a copy of CourseActionState
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  $Res call({
    Object? e = null,
  }) {
    return _then(CourseEnrollSuccess(
      null == e
          ? _self.e
          : e // ignore: cast_nullable_to_non_nullable
              as EnrollmentEntity,
    ));
  }
}

/// @nodoc

class CourseCreateSuccess implements CourseActionState {
  const CourseCreateSuccess(this.c);

  final CourseEntity c;

  /// Create a copy of CourseActionState
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @pragma('vm:prefer-inline')
  $CourseCreateSuccessCopyWith<CourseCreateSuccess> get copyWith =>
      _$CourseCreateSuccessCopyWithImpl<CourseCreateSuccess>(this, _$identity);

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is CourseCreateSuccess &&
            (identical(other.c, c) || other.c == c));
  }

  @override
  int get hashCode => Object.hash(runtimeType, c);

  @override
  String toString() {
    return 'CourseActionState.createSuccess(c: $c)';
  }
}

/// @nodoc
abstract mixin class $CourseCreateSuccessCopyWith<$Res>
    implements $CourseActionStateCopyWith<$Res> {
  factory $CourseCreateSuccessCopyWith(
          CourseCreateSuccess value, $Res Function(CourseCreateSuccess) _then) =
      _$CourseCreateSuccessCopyWithImpl;
  @useResult
  $Res call({CourseEntity c});
}

/// @nodoc
class _$CourseCreateSuccessCopyWithImpl<$Res>
    implements $CourseCreateSuccessCopyWith<$Res> {
  _$CourseCreateSuccessCopyWithImpl(this._self, this._then);

  final CourseCreateSuccess _self;
  final $Res Function(CourseCreateSuccess) _then;

  /// Create a copy of CourseActionState
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  $Res call({
    Object? c = null,
  }) {
    return _then(CourseCreateSuccess(
      null == c
          ? _self.c
          : c // ignore: cast_nullable_to_non_nullable
              as CourseEntity,
    ));
  }
}

/// @nodoc

class CourseActionError implements CourseActionState {
  const CourseActionError(this.message);

  final String message;

  /// Create a copy of CourseActionState
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @pragma('vm:prefer-inline')
  $CourseActionErrorCopyWith<CourseActionError> get copyWith =>
      _$CourseActionErrorCopyWithImpl<CourseActionError>(this, _$identity);

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is CourseActionError &&
            (identical(other.message, message) || other.message == message));
  }

  @override
  int get hashCode => Object.hash(runtimeType, message);

  @override
  String toString() {
    return 'CourseActionState.error(message: $message)';
  }
}

/// @nodoc
abstract mixin class $CourseActionErrorCopyWith<$Res>
    implements $CourseActionStateCopyWith<$Res> {
  factory $CourseActionErrorCopyWith(
          CourseActionError value, $Res Function(CourseActionError) _then) =
      _$CourseActionErrorCopyWithImpl;
  @useResult
  $Res call({String message});
}

/// @nodoc
class _$CourseActionErrorCopyWithImpl<$Res>
    implements $CourseActionErrorCopyWith<$Res> {
  _$CourseActionErrorCopyWithImpl(this._self, this._then);

  final CourseActionError _self;
  final $Res Function(CourseActionError) _then;

  /// Create a copy of CourseActionState
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  $Res call({
    Object? message = null,
  }) {
    return _then(CourseActionError(
      null == message
          ? _self.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

// dart format on
