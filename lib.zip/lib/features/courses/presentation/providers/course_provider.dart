import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

import '../../../../core/di/repository_providers.dart';
import '../../../../core/di/usecase_providers.dart';
import '../../../auth/presentation/providers/auth_provider.dart';
import '../../domain/entities/course_entity.dart';
import '../../domain/entities/course_schedule_entity.dart';
import '../../domain/entities/enrollment_entity.dart';

part 'course_provider.freezed.dart';
part 'course_provider.g.dart';

// Queries
@riverpod
Future<List<CourseEntity>> openCourses(Ref ref, {String? subject}) =>
    ref.read(getOpenCoursesUseCaseProvider).call(subject: subject);

@riverpod
Future<CourseEntity> courseDetail(Ref ref, String courseId) =>
    ref.read(getCourseUseCaseProvider).call(courseId);

@riverpod
Future<EnrollmentEntity?> myEnrollment(Ref ref, String courseId) {
  final user = ref.watch(authStateStreamProvider).value;
  if (user == null) return Future.value(null);
  return ref.read(courseRepositoryProvider).getMyEnrollment(
        studentId: user.id,
        courseId: courseId,
      );
}

@riverpod
Stream<List<EnrollmentEntity>> myEnrollments(Ref ref) {
  final user = ref.watch(authStateStreamProvider).value;
  if (user == null) return const Stream.empty();
  return ref.read(watchStudentEnrollmentsUseCaseProvider).call(user.id);
}

@riverpod
Stream<List<CourseEntity>> teacherCourses(Ref ref) {
  final user = ref.watch(authStateStreamProvider).value;
  if (user == null) return const Stream.empty();
  return ref.read(courseRepositoryProvider).watchTeacherCourses(user.id);
}

@riverpod
Stream<List<EnrollmentEntity>> courseEnrollments(Ref ref, String courseId) =>
    ref.read(courseRepositoryProvider).watchCourseEnrollments(courseId);

// State
@freezed
sealed class CourseActionState with _$CourseActionState {
  const factory CourseActionState.idle()                             = CourseIdle;
  const factory CourseActionState.loading()                         = CourseLoading;
  const factory CourseActionState.enrollSuccess(EnrollmentEntity e) = CourseEnrollSuccess;
  const factory CourseActionState.createSuccess(CourseEntity c)     = CourseCreateSuccess;
  const factory CourseActionState.error(String message)             = CourseActionError;
}

// Student ViewModel
@riverpod
class CourseViewModel extends _$CourseViewModel {
  @override
  CourseActionState build() => const CourseActionState.idle();

  Future<void> enroll(String courseId) async {
    final user = ref.read(authStateStreamProvider).value;
    if (user == null) {
      state = const CourseActionState.error('Vui lòng đăng nhập');
      return;
    }
    state = const CourseActionState.loading();
    try {
      final enrollment = await ref.read(enrollCourseUseCaseProvider).call(
            studentId: user.id,
            courseId: courseId,
          );
      ref.invalidate(myEnrollmentProvider(courseId));
      ref.invalidate(myEnrollmentsProvider);
      state = CourseActionState.enrollSuccess(enrollment);
    } catch (e) {
      state = CourseActionState.error(e.toString().replaceAll('Exception: ', ''));
    }
  }

  Future<void> cancelEnrollment(String enrollmentId, String courseId) async {
    state = const CourseActionState.loading();
    try {
      await ref.read(cancelEnrollmentUseCaseProvider).call(enrollmentId);
      ref.invalidate(myEnrollmentProvider(courseId));
      ref.invalidate(myEnrollmentsProvider);
      state = const CourseActionState.idle();
    } catch (e) {
      state = CourseActionState.error(e.toString().replaceAll('Exception: ', ''));
    }
  }

  void reset() => state = const CourseActionState.idle();
}

// Teacher ViewModel
@riverpod
class TeacherCourseViewModel extends _$TeacherCourseViewModel {
  @override
  CourseActionState build() => const CourseActionState.idle();

  Future<void> createCourse({
    required String title,
    required String description,
    required String subject,
    required int totalSessions,
    required double pricePerCourse,
    required List<CourseScheduleEntry> scheduleEntries,
    required DateTime startDate,
    required int maxStudents,
    String? level,
  }) async {
    final user = ref.read(authStateStreamProvider).value;
    if (user == null) return;
    state = const CourseActionState.loading();
    try {
      final course = await ref.read(createCourseUseCaseProvider).call(
            teacherId:      user.id,
            title:          title,
            description:    description,
            subject:        subject,
            totalSessions:  totalSessions,
            pricePerCourse: pricePerCourse,
            scheduleEntries: scheduleEntries,
            startDate:      startDate,
            maxStudents:    maxStudents,
            level:          level,
          );
      ref.invalidate(teacherCoursesProvider);
      state = CourseActionState.createSuccess(course);
    } catch (e) {
      state = CourseActionState.error(e.toString().replaceAll('Exception: ', ''));
    }
  }

  Future<void> confirmEnrollment(String enrollmentId, String courseId) async {
    state = const CourseActionState.loading();
    try {
      await ref.read(confirmEnrollmentUseCaseProvider).call(enrollmentId);
      ref.invalidate(courseEnrollmentsProvider(courseId));
      state = const CourseActionState.idle();
    } catch (e) {
      state = CourseActionState.error(e.toString().replaceAll('Exception: ', ''));
    }
  }

  void reset() => state = const CourseActionState.idle();
}
