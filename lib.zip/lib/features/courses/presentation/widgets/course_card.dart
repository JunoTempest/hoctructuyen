import '../../../../app/theme/app_theme.dart';
import 'package:flutter/material.dart';

import '../../../../core/constants/app_enums.dart';
import '../../domain/entities/course_entity.dart';

class CourseCard extends StatelessWidget {
  const CourseCard({super.key, required this.course, required this.onTap});
  final CourseEntity course;
  final VoidCallback onTap;

  List<Color> _gradient(String subject) => switch (subject) {
        'Toán' => [const Color(0xFF2563EB), const Color(0xFF0EA5E9)],
        'Lý'   => [const Color(0xFF7C3AED), const Color(0xFF2563EB)],
        'Hóa'  => [const Color(0xFF059669), const Color(0xFF0EA5E9)],
        'Văn'  => [const Color(0xFFD97706), const Color(0xFFDC2626)],
        'Anh'  => [const Color(0xFF0EA5E9), const Color(0xFF06B6D4)],
        _      => [const Color(0xFF2563EB), const Color(0xFF7C3AED)],
      };

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          margin: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            color: Colors.white, borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.border),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04),
                blurRadius: 8, offset: const Offset(0, 2))],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header
              Container(
                height: 80,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: _gradient(course.subject),
                      begin: Alignment.topLeft, end: Alignment.bottomRight),
                  borderRadius:
                      const BorderRadius.vertical(top: Radius.circular(16)),
                ),
                padding: const EdgeInsets.all(14),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _Tag(course.subject),
                          if (course.level != null) ...[
                            const SizedBox(height: 4),
                            Text(course.level!,
                                style: const TextStyle(
                                    color: Colors.white70, fontSize: 11)),
                          ],
                        ],
                      ),
                    ),
                    _StatusChip(course.status),
                  ],
                ),
              ),
              // Body
              Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(course.title,
                        style: const TextStyle(
                            fontSize: 15, fontWeight: FontWeight.w700),
                        maxLines: 2, overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 6),
                    Row(children: [
                      const Icon(Icons.person_outline,
                          size: 13, color: AppColors.textSub),
                      const SizedBox(width: 4),
                      Text(course.teacherName ?? 'Giáo viên',
                          style: const TextStyle(
                              fontSize: 12, color: AppColors.textSub)),
                      if (course.teacherRating != null) ...[
                        const SizedBox(width: 8),
                        const Icon(Icons.star_rounded,
                            color: Colors.amber, size: 13),
                        Text(course.teacherRating!.toStringAsFixed(1),
                            style: const TextStyle(
                                fontSize: 12, fontWeight: FontWeight.w600)),
                      ],
                    ]),
                    const SizedBox(height: 4),
                    Row(children: [
                      const Icon(Icons.calendar_today_outlined,
                          size: 13, color: AppColors.textSub),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Text(course.scheduleLabel,
                            style: const TextStyle(
                                fontSize: 12, color: AppColors.textSub),
                            overflow: TextOverflow.ellipsis),
                      ),
                    ]),
                    const SizedBox(height: 10),
                    const Divider(height: 1),
                    const SizedBox(height: 10),
                    Row(children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(course.formattedPrice,
                                style: const TextStyle(
                                    fontSize: 16, fontWeight: FontWeight.w800,
                                    color: AppColors.primary)),
                            Text(course.formattedPricePerSession,
                                style: const TextStyle(
                                    fontSize: 11, color: AppColors.textSub)),
                          ],
                        ),
                      ),
                      _InfoChip(Icons.video_call_outlined,
                          '${course.totalSessions} buổi'),
                      const SizedBox(width: 6),
                      _InfoChip(Icons.people_outline,
                          '${course.remainingSlots} chỗ',
                          color: course.isFull ? AppColors.error : null),
                    ]),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
}

class _Tag extends StatelessWidget {
  const _Tag(this.label);
  final String label;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.25),
          borderRadius: BorderRadius.circular(6),
        ),
        child: Text(label,
            style: const TextStyle(
                color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700)),
      );
}

class _StatusChip extends StatelessWidget {
  const _StatusChip(this.status);
  final CourseStatus status;
  @override
  Widget build(BuildContext context) {
    final (label, color) = switch (status) {
      CourseStatus.open   => ('Đang mở', Colors.white),
      CourseStatus.full   => ('Đã đầy', Colors.red[200]!),
      CourseStatus.closed => ('Đã đóng', Colors.grey[300]!),
      CourseStatus.draft  => ('Nháp', Colors.yellow[200]!),
      CourseStatus.pending  => ('Chờ duyệt', Colors.orange[200]!),
      CourseStatus.rejected => ('Từ chối',   Colors.grey[300]!),
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.3),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(label,
          style: TextStyle(color: color,
              fontSize: 10, fontWeight: FontWeight.w700)),
    );
  }
}

class _InfoChip extends StatelessWidget {
  const _InfoChip(this.icon, this.label, {this.color});
  final IconData icon;
  final String label;
  final Color? color;
  @override
  Widget build(BuildContext context) {
    final c = color ?? AppColors.textSub;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: c.withOpacity(0.08), borderRadius: BorderRadius.circular(8)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 12, color: c),
        const SizedBox(width: 3),
        Text(label, style: TextStyle(
            fontSize: 11, color: c, fontWeight: FontWeight.w600)),
      ]),
    );
  }
}
