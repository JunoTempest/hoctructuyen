import '../../../../app/theme/app_theme.dart';
import 'package:flutter/material.dart';


class SubjectFilterBar extends StatelessWidget {
  const SubjectFilterBar({super.key, required this.selected, required this.onChanged});
  final String? selected;
  final ValueChanged<String?> onChanged;
  static const _subjects = ['Toán','Lý','Hóa','Văn','Anh','Sinh','Sử','Địa'];

  @override
  Widget build(BuildContext context) => SizedBox(
        height: 48,
        child: ListView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          children: [
            _Chip(label: 'Tất cả', isSelected: selected == null,
                onTap: () => onChanged(null)),
            ..._subjects.map((s) => _Chip(
                  label: s,
                  isSelected: selected == s,
                  onTap: () => onChanged(selected == s ? null : s),
                )),
          ],
        ),
      );
}

class _Chip extends StatelessWidget {
  const _Chip({required this.label, required this.isSelected, required this.onTap});
  final String label;
  final bool isSelected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          margin: const EdgeInsets.only(right: 8),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
          decoration: BoxDecoration(
            color: isSelected ? AppColors.primary : const Color(0xFFF1F5F9),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
                color: isSelected ? AppColors.primary : AppColors.border),
          ),
          child: Text(label,
              style: TextStyle(
                  fontSize: 13, fontWeight: FontWeight.w600,
                  color: isSelected ? Colors.white : AppColors.textSub)),
        ),
      );
}
