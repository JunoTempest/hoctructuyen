import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../app/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../../core/constants/app_enums.dart';
import '../../domain/entities/enrollment_entity.dart';
import '../providers/course_provider.dart';

class MyEnrollmentsScreen extends ConsumerWidget {
  const MyEnrollmentsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(myEnrollmentsProvider);

    ref.listen<CourseActionState>(courseViewModelProvider, (_, next) {
      if (next is CourseActionError) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(next.message), backgroundColor: AppColors.error,
            behavior: SnackBarBehavior.floating));
        ref.read(courseViewModelProvider.notifier).reset();
      }
    });

    return Scaffold(
      appBar: AppBar(title: const Text('Khóa học của tôi')),
      body: async.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Lỗi: $e')),
        data: (list) {
          if (list.isEmpty) return Center(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.school_outlined, size: 64, color: Colors.grey[300]),
              const SizedBox(height: 12),
              const Text('Chưa đăng ký khóa nào',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                icon: const Icon(Icons.explore_outlined),
                label: const Text('Khám phá khóa học'),
                onPressed: () => context.go('/courses'),
              ),
            ]),
          );

          final active    = list.where((e) => e.isPending || e.isConfirmed).toList();
          final completed = list.where((e) => e.isCompleted).toList();
          final cancelled = list.where((e) => e.isCancelled).toList();

          return RefreshIndicator(
            onRefresh: () async => ref.invalidate(myEnrollmentsProvider),
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                if (active.isNotEmpty) ...[
                  _SectionHeader('Đang học (${active.length})'),
                  ...active.map((e) => _EnrollCard(enrollment: e,
                      onCancel: e.isPending
                          ? () => _confirmCancel(context, ref, e) : null,
                      onTap: () => context.push('/courses/${e.courseId}'))),
                  const SizedBox(height: 16),
                ],
                if (completed.isNotEmpty) ...[
                  _SectionHeader('Hoàn thành'),
                  ...completed.map((e) => _EnrollCard(enrollment: e,
                      onTap: () => context.push('/courses/${e.courseId}'))),
                  const SizedBox(height: 16),
                ],
                if (cancelled.isNotEmpty) ...[
                  _SectionHeader('Đã huỷ'),
                  ...cancelled.map((e) => _EnrollCard(enrollment: e,
                      onTap: () => context.push('/courses/${e.courseId}'))),
                ],
              ],
            ),
          );
        },
      ),
    );
  }

  Future<void> _confirmCancel(BuildContext ctx, WidgetRef ref, EnrollmentEntity e) async {
    final ok = await showDialog<bool>(context: ctx, builder: (_) => AlertDialog(
      title: const Text('Huỷ đăng ký?'),
      content: Text('Huỷ khóa "${e.courseTitle}"?'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Không')),
        ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
            onPressed: () => Navigator.pop(ctx, true), child: const Text('Huỷ đăng ký')),
      ],
    ));
    if (ok == true) {
      ref.read(courseViewModelProvider.notifier).cancelEnrollment(e.enrollmentId, e.courseId);
    }
  }
}

class _EnrollCard extends StatelessWidget {
  const _EnrollCard({required this.enrollment, required this.onTap, this.onCancel});
  final EnrollmentEntity enrollment;
  final VoidCallback onTap;
  final VoidCallback? onCancel;

  @override
  Widget build(BuildContext context) {
    final df = DateFormat('dd/MM/yyyy');
    final c = switch (enrollment.status) {
      EnrollmentStatus.pending   => AppColors.warning,
      EnrollmentStatus.confirmed => AppColors.primary,
      EnrollmentStatus.completed => AppColors.success,
      EnrollmentStatus.cancelled => AppColors.textSub,
    };
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.border)),
        child: Column(children: [
          Container(height: 4,
              decoration: BoxDecoration(color: c,
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(16)))),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text(enrollment.courseTitle ?? 'Khóa học',
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                    maxLines: 2, overflow: TextOverflow.ellipsis)),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(color: c.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20)),
                  child: Text(enrollment.status.label,
                      style: TextStyle(color: c, fontSize: 11, fontWeight: FontWeight.w700)),
                ),
              ]),
              const SizedBox(height: 8),
              Row(children: [
                const Icon(Icons.person_outline, size: 13, color: AppColors.textSub),
                const SizedBox(width: 4),
                Text(enrollment.teacherName ?? 'Giáo viên',
                    style: const TextStyle(fontSize: 12, color: AppColors.textSub)),
                if (enrollment.startDate != null) ...[
                  const SizedBox(width: 16),
                  const Icon(Icons.calendar_today_outlined, size: 13, color: AppColors.textSub),
                  const SizedBox(width: 4),
                  Text('Từ ${df.format(enrollment.startDate!)}',
                      style: const TextStyle(fontSize: 12, color: AppColors.textSub)),
                ],
              ]),
              if (enrollment.isConfirmed && enrollment.totalSessions != null) ...[
                const SizedBox(height: 12),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  const Text('Tiến độ',
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                  Text(enrollment.progressLabel,
                      style: const TextStyle(fontSize: 12, color: AppColors.primary,
                          fontWeight: FontWeight.w700)),
                ]),
                const SizedBox(height: 6),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(value: enrollment.progressPercent,
                      backgroundColor: Colors.grey[200],
                      valueColor: const AlwaysStoppedAnimation(AppColors.primary),
                      minHeight: 6),
                ),
              ],
              if (onCancel != null) ...[
                const SizedBox(height: 12),
                Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                  OutlinedButton.icon(
                    icon: const Icon(Icons.close, size: 14),
                    label: const Text('Huỷ đăng ký'),
                    style: OutlinedButton.styleFrom(
                        foregroundColor: AppColors.error,
                        side: const BorderSide(color: AppColors.error),
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        minimumSize: Size.zero,
                        textStyle: const TextStyle(fontSize: 12)),
                    onPressed: onCancel,
                  ),
                ]),
              ],
            ]),
          ),
        ]),
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader(this.title);
  final String title;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Text(title, style: const TextStyle(
            fontSize: 13, fontWeight: FontWeight.w700,
            color: AppColors.textSub, letterSpacing: .3)),
      );
}
