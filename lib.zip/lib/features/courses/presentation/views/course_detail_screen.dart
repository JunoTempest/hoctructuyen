import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../app/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../../core/constants/app_enums.dart';
import '../../../auth/presentation/providers/auth_provider.dart';
import '../../domain/entities/course_entity.dart';
import '../../domain/entities/enrollment_entity.dart';
import '../providers/course_provider.dart';

class CourseDetailScreen extends ConsumerWidget {
  const CourseDetailScreen({super.key, required this.courseId});
  final String courseId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final courseAsync     = ref.watch(courseDetailProvider(courseId));
    final enrollmentAsync = ref.watch(myEnrollmentProvider(courseId));
    final actionState     = ref.watch(courseViewModelProvider);
    final user            = ref.watch(authStateStreamProvider).value;

    ref.listen<CourseActionState>(courseViewModelProvider, (_, next) {
      switch (next) {
        case CourseEnrollSuccess():
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('🎉 Đăng ký thành công! Chờ giáo viên xác nhận.'),
            backgroundColor: AppColors.success, behavior: SnackBarBehavior.floating));
          ref.read(courseViewModelProvider.notifier).reset();
        case CourseActionError(:final message):
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(message), backgroundColor: AppColors.error,
            behavior: SnackBarBehavior.floating));
          ref.read(courseViewModelProvider.notifier).reset();
        default: break;
      }
    });

    return Scaffold(
      body: courseAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Lỗi: $e')),
        data: (course) => Stack(children: [
          _Body(course: course),
          Positioned(
            bottom: 0, left: 0, right: 0,
            child: _BottomBar(
              course:     course,
              enrollment: enrollmentAsync.value,
              isLoading:  actionState is CourseLoading,
              isStudent:  user?.isStudent ?? false,
              onEnroll:   () => ref.read(courseViewModelProvider.notifier).enroll(courseId),
              onCancel:   (id) => ref.read(courseViewModelProvider.notifier)
                  .cancelEnrollment(id, courseId),
            ),
          ),
        ]),
      ),
    );
  }
}

class _Body extends StatelessWidget {
  const _Body({required this.course});
  final CourseEntity course;

  @override
  Widget build(BuildContext context) => CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 200, pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [AppColors.primary, AppColors.secondary],
                    begin: Alignment.topLeft, end: Alignment.bottomRight),
                ),
                child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const SizedBox(height: 40),
                  Container(
                    width: 72, height: 72,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(20)),
                    child: const Icon(Icons.school_rounded, color: Colors.white, size: 40),
                  ),
                  if (course.level != null) ...[
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(20)),
                      child: Text(course.level!, style: const TextStyle(
                          color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)),
                    ),
                  ],
                ])),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 120),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  _Badge(course.subject, AppColors.primary),
                  const SizedBox(width: 8),
                  _StatusBadge(course.status),
                ]),
                const SizedBox(height: 10),
                Text(course.title,
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                Row(children: [
                  CircleAvatar(radius: 16,
                      backgroundColor: AppColors.primary.withOpacity(0.1),
                      child: const Icon(Icons.person_outline, size: 18, color: AppColors.primary)),
                  const SizedBox(width: 8),
                  Text(course.teacherName ?? 'Giáo viên',
                      style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                  if (course.teacherRating != null) ...[
                    const SizedBox(width: 8),
                    const Icon(Icons.star_rounded, color: Colors.amber, size: 16),
                    Text(course.teacherRating!.toStringAsFixed(1),
                        style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                  ],
                ]),
                const SizedBox(height: 20),
                _InfoGrid(course: course),
                const SizedBox(height: 20),
                const Text('Lịch học',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                ...course.scheduleEntries.map((e) => Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Row(children: [
                    Container(
                      width: 56, padding: const EdgeInsets.symmetric(vertical: 4),
                      decoration: BoxDecoration(
                        color: AppColors.primary.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(8)),
                      child: Text(e.dayLabel, textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 12,
                              fontWeight: FontWeight.w700, color: AppColors.primary)),
                    ),
                    const SizedBox(width: 12),
                    Text(e.timeLabel, style: const TextStyle(fontSize: 14)),
                    const SizedBox(width: 8),
                    Text('(${e.durationMinutes} phút)',
                        style: const TextStyle(fontSize: 12, color: AppColors.textSub)),
                  ]),
                )),
                const SizedBox(height: 20),
                const Text('Giới thiệu',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                Text(course.description.isEmpty ? 'Chưa có mô tả' : course.description,
                    style: const TextStyle(fontSize: 14, color: AppColors.textSub, height: 1.6)),
                const SizedBox(height: 20),
                _SlotBar(course: course),
              ]),
            ),
          ),
        ],
      );
}

class _BottomBar extends StatelessWidget {
  const _BottomBar({required this.course, required this.enrollment,
      required this.isLoading, required this.isStudent,
      required this.onEnroll, required this.onCancel});
  final CourseEntity course;
  final EnrollmentEntity? enrollment;
  final bool isLoading, isStudent;
  final VoidCallback onEnroll;
  final void Function(String) onCancel;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
        decoration: BoxDecoration(color: Colors.white,
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08),
                blurRadius: 12, offset: const Offset(0, -4))]),
        child: Row(children: [
          Column(crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min, children: [
            Text(course.formattedPrice, style: const TextStyle(
                fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.primary)),
            Text(course.formattedPricePerSession,
                style: const TextStyle(fontSize: 12, color: AppColors.textSub)),
          ]),
          const SizedBox(width: 16),
          Expanded(child: _EnrollBtn(course: course, enrollment: enrollment,
              isLoading: isLoading, isStudent: isStudent,
              onEnroll: onEnroll, onCancel: onCancel)),
        ]),
      );
}

class _EnrollBtn extends StatelessWidget {
  const _EnrollBtn({required this.course, required this.enrollment,
      required this.isLoading, required this.isStudent,
      required this.onEnroll, required this.onCancel});
  final CourseEntity course;
  final EnrollmentEntity? enrollment;
  final bool isLoading, isStudent;
  final VoidCallback onEnroll;
  final void Function(String) onCancel;

  @override
  Widget build(BuildContext context) {
    if (isLoading) return const SizedBox(height: 50,
        child: Center(child: CircularProgressIndicator()));
    if (enrollment != null && enrollment!.isPending) {
      return OutlinedButton.icon(
        icon: const Icon(Icons.hourglass_empty, size: 16),
        label: const Text('Chờ xác nhận'),
        style: OutlinedButton.styleFrom(minimumSize: const Size(0, 50),
            foregroundColor: AppColors.warning,
            side: const BorderSide(color: AppColors.warning)),
        onPressed: () => _confirmCancel(context),
      );
    }
    if (enrollment != null && enrollment!.isConfirmed) {
      return ElevatedButton.icon(
        icon: const Icon(Icons.check_circle_outline, size: 16),
        label: const Text('Đã đăng ký'),
        style: ElevatedButton.styleFrom(minimumSize: const Size(0, 50),
            backgroundColor: AppColors.success),
        onPressed: null,
      );
    }
    if (!course.isOpen && enrollment == null) {
      return ElevatedButton(onPressed: null,
        style: ElevatedButton.styleFrom(minimumSize: const Size(0, 50),
            backgroundColor: Colors.grey[200], foregroundColor: AppColors.textSub),
        child: Text(course.isFull ? 'Đã đầy chỗ' : 'Đã đóng'));
    }
    if (isStudent) {
      return ElevatedButton.icon(
        icon: const Icon(Icons.school_outlined, size: 16),
        label: const Text('Đăng ký khóa học'),
        style: ElevatedButton.styleFrom(minimumSize: const Size(0, 50)),
        onPressed: onEnroll,
      );
    }
    return const SizedBox.shrink();
  }

  Future<void> _confirmCancel(BuildContext context) async {
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('Huỷ đăng ký?'),
      content: const Text('Bạn muốn huỷ đăng ký khóa học này?'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Không')),
        ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
            onPressed: () => Navigator.pop(context, true), child: const Text('Huỷ')),
      ],
    ));
    if (ok == true && enrollment != null) onCancel(enrollment!.enrollmentId);
  }
}

// ── Helpers ───────────────────────────────────────────────────
class _InfoGrid extends StatelessWidget {
  const _InfoGrid({required this.course});
  final CourseEntity course;
  @override
  Widget build(BuildContext context) {
    final df = DateFormat('dd/MM/yyyy');
    final items = [
      (Icons.video_call_outlined, '${course.totalSessions} buổi', 'Tổng buổi'),
      (Icons.calendar_today_outlined, df.format(course.startDate), 'Bắt đầu'),
      (Icons.people_outline, '${course.enrolledCount}/${course.maxStudents}', 'Học sinh'),
      (Icons.access_time_outlined,
          '${course.scheduleEntries.firstOrNull?.durationMinutes ?? 90} phút', 'Mỗi buổi'),
    ];
    return GridView.count(crossAxisCount: 2, shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 8, crossAxisSpacing: 8, childAspectRatio: 2.8,
      children: items.map((i) {
        final (icon, val, label) = i;
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(color: const Color(0xFFF8FAFF),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.border)),
          child: Row(children: [
            Icon(icon, size: 18, color: AppColors.primary),
            const SizedBox(width: 8),
            Column(crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(val, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
              Text(label, style: const TextStyle(fontSize: 10, color: AppColors.textSub)),
            ]),
          ]),
        );
      }).toList(),
    );
  }
}

class _SlotBar extends StatelessWidget {
  const _SlotBar({required this.course});
  final CourseEntity course;
  @override
  Widget build(BuildContext context) {
    final pct = course.maxStudents > 0
        ? course.enrolledCount / course.maxStudents : 0.0;
    final c = pct >= 1 ? AppColors.error
        : pct >= 0.8 ? AppColors.warning : AppColors.success;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        const Text('Số chỗ', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
        Text(course.isFull ? 'Đã đầy' : 'Còn ${course.remainingSlots} chỗ',
            style: TextStyle(color: c, fontWeight: FontWeight.w700, fontSize: 13)),
      ]),
      const SizedBox(height: 8),
      ClipRRect(borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(value: pct.clamp(0.0, 1.0),
              backgroundColor: Colors.grey[200],
              valueColor: AlwaysStoppedAnimation(c), minHeight: 8)),
      const SizedBox(height: 4),
      Text('${course.enrolledCount}/${course.maxStudents} học sinh',
          style: const TextStyle(fontSize: 12, color: AppColors.textSub)),
    ]);
  }
}

class _Badge extends StatelessWidget {
  const _Badge(this.label, this.color);
  final String label;
  final Color color;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8)),
        child: Text(label, style: TextStyle(
            color: color, fontSize: 12, fontWeight: FontWeight.w600)));
}

class _StatusBadge extends StatelessWidget {
  const _StatusBadge(this.status);
  final CourseStatus status;
  @override
  Widget build(BuildContext context) {
    final (c, bg) = switch (status) {
      CourseStatus.open   => (AppColors.success, const Color(0xFFDCFCE7)),
      CourseStatus.full   => (AppColors.error,   const Color(0xFFFEE2E2)),
      CourseStatus.closed => (AppColors.textSub, const Color(0xFFF1F5F9)),
      CourseStatus.draft  => (AppColors.warning, const Color(0xFFFEF3C7)),
      CourseStatus.pending  => (AppColors.warning, const Color(0xFFFEF3C7)),
      CourseStatus.rejected => (AppColors.textSub, const Color(0xFFF1F5F9)),
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(8)),
      child: Text(status.label, style: TextStyle(
          color: c, fontSize: 12, fontWeight: FontWeight.w600)));
  }
}
