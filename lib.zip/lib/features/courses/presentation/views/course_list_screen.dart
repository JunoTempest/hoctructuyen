import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../app/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../providers/course_provider.dart';
import '../widgets/course_card.dart';
import '../widgets/subject_filter_bar.dart';

class CourseListScreen extends ConsumerStatefulWidget {
  const CourseListScreen({super.key});
  @override
  ConsumerState<CourseListScreen> createState() => _CourseListScreenState();
}

class _CourseListScreenState extends ConsumerState<CourseListScreen> {
  String? _subject;
  final _searchCtrl = TextEditingController();
  String _search = '';

  @override
  void dispose() { _searchCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final async = ref.watch(openCoursesProvider(subject: _subject));
    return Scaffold(
      appBar: AppBar(title: const Text('Khóa học')),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
          child: SearchBar(
            controller: _searchCtrl,
            hintText: 'Tìm khóa học, giáo viên...',
            leading: const Icon(Icons.search, size: 20),
            padding: const WidgetStatePropertyAll(EdgeInsets.symmetric(horizontal: 16)),
            elevation: const WidgetStatePropertyAll(0),
            backgroundColor: const WidgetStatePropertyAll(Color(0xFFF1F5F9)),
            side: const WidgetStatePropertyAll(BorderSide(color: AppColors.border)),
            shape: WidgetStatePropertyAll(RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            onChanged: (v) => setState(() => _search = v.toLowerCase()),
          ),
        ),
        SubjectFilterBar(selected: _subject,
            onChanged: (s) => setState(() => _subject = s)),
        Expanded(
          child: async.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (e, _) => Center(child: Text('Lỗi: $e')),
            data: (courses) {
              final filtered = _search.isEmpty ? courses
                  : courses.where((c) =>
                      c.title.toLowerCase().contains(_search) ||
                      (c.teacherName?.toLowerCase().contains(_search) ?? false)).toList();
              if (filtered.isEmpty) return Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.school_outlined, size: 64, color: Colors.grey[300]),
                  const SizedBox(height: 12),
                  const Text('Không có khóa học nào',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                ]),
              );
              return RefreshIndicator(
                onRefresh: () => ref.refresh(openCoursesProvider(subject: _subject).future),
                child: ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                  itemCount: filtered.length,
                  itemBuilder: (_, i) => CourseCard(
                    course: filtered[i],
                    onTap: () => context.push('/courses/${filtered[i].courseId}'),
                  ),
                ),
              );
            },
          ),
        ),
      ]),
    );
  }
}
