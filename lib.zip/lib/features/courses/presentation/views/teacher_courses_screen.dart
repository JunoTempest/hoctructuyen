import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../app/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../../core/constants/app_enums.dart';
import '../../domain/entities/course_entity.dart';
import '../../domain/entities/course_schedule_entity.dart';
import '../../domain/entities/enrollment_entity.dart';
import '../providers/course_provider.dart';

class TeacherCoursesScreen extends ConsumerStatefulWidget {
  const TeacherCoursesScreen({super.key});
  @override
  ConsumerState<TeacherCoursesScreen> createState() => _State();
}

class _State extends ConsumerState<TeacherCoursesScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 2, vsync: this);
  }
  @override
  void dispose() { _tabs.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    ref.listen<CourseActionState>(teacherCourseViewModelProvider, (_, next) {
      switch (next) {
        case CourseCreateSuccess(:final c):
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('✅ Đã tạo khóa "${c.title}"'),
            backgroundColor: AppColors.success, behavior: SnackBarBehavior.floating));
          ref.read(teacherCourseViewModelProvider.notifier).reset();
        case CourseActionError(:final message):
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(message), backgroundColor: AppColors.error,
            behavior: SnackBarBehavior.floating));
          ref.read(teacherCourseViewModelProvider.notifier).reset();
        default: break;
      }
    });

    return Scaffold(
      appBar: AppBar(
        title: const Text('Khóa học của tôi'),
        actions: [IconButton(
          icon: const Icon(Icons.add_circle_outline),
          onPressed: () => _showCreate(context),
        )],
        bottom: TabBar(controller: _tabs, tabs: const [
          Tab(text: 'Khóa học'), Tab(text: 'Đăng ký chờ'),
        ]),
      ),
      body: TabBarView(controller: _tabs, children: [
        _CoursesList(onCreateTap: () => _showCreate(context)),
        const _PendingTab(),
      ]),
    );
  }

  void _showCreate(BuildContext ctx) => showModalBottomSheet(
    context: ctx, isScrollControlled: true,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
    builder: (_) => const _CreateSheet(),
  );
}

class _CoursesList extends ConsumerWidget {
  const _CoursesList({required this.onCreateTap});
  final VoidCallback onCreateTap;
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(teacherCoursesProvider);
    return async.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => Center(child: Text('Lỗi: $e')),
      data: (courses) {
        if (courses.isEmpty) return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.add_box_outlined, size: 64, color: Colors.grey[300]),
          const SizedBox(height: 12),
          const Text('Chưa có khóa học nào',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
          const SizedBox(height: 20),
          ElevatedButton.icon(icon: const Icon(Icons.add),
              label: const Text('Tạo khóa học'), onPressed: onCreateTap),
        ]));
        return ListView.builder(
          padding: const EdgeInsets.all(16), itemCount: courses.length,
          itemBuilder: (_, i) => _TeacherCard(
            course: courses[i],
            onTap: () => context.push('/courses/${courses[i].courseId}'),
          ),
        );
      },
    );
  }
}

class _TeacherCard extends StatelessWidget {
  const _TeacherCard({required this.course, required this.onTap});
  final CourseEntity course;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) {
    final c = switch (course.status) {
      CourseStatus.open   => AppColors.success,
      CourseStatus.full   => AppColors.error,
      CourseStatus.closed => AppColors.textSub,
      CourseStatus.draft  => AppColors.warning,
      CourseStatus.pending => const Color(0xFFf59e0b),
      CourseStatus.rejected => const Color(0xFF94a3b8),
    };
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppColors.border)),
        child: Row(children: [
          Container(width: 4, height: 60,
              decoration: BoxDecoration(color: c, borderRadius: BorderRadius.circular(2))),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(course.title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
                maxLines: 1, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 4),
            Text(course.scheduleLabel,
                style: const TextStyle(fontSize: 12, color: AppColors.textSub)),
            const SizedBox(height: 6),
            Row(children: [
              _S(Icons.people_outline, '${course.enrolledCount}/${course.maxStudents}', AppColors.primary),
              const SizedBox(width: 12),
              _S(Icons.video_call_outlined, '${course.totalSessions} buổi', AppColors.secondary),
              const SizedBox(width: 12),
              _S(Icons.attach_money, course.formattedPrice, AppColors.success),
            ]),
          ])),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(color: c.withOpacity(0.1), borderRadius: BorderRadius.circular(20)),
            child: Text(course.status.label,
                style: TextStyle(color: c, fontSize: 11, fontWeight: FontWeight.w700)),
          ),
        ]),
      ),
    );
  }
}

class _S extends StatelessWidget {
  const _S(this.icon, this.val, this.color);
  final IconData icon; final String val; final Color color;
  @override
  Widget build(BuildContext context) => Row(children: [
    Icon(icon, size: 12, color: color), const SizedBox(width: 3),
    Text(val, style: TextStyle(fontSize: 11, color: color, fontWeight: FontWeight.w600)),
  ]);
}

class _PendingTab extends ConsumerWidget {
  const _PendingTab();
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(teacherCoursesProvider);
    return async.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => Center(child: Text('Lỗi: $e')),
      data: (courses) {
        if (courses.isEmpty) return const Center(
            child: Text('Chưa có khóa học', style: TextStyle(color: AppColors.textSub)));
        return ListView(padding: const EdgeInsets.all(16), children: courses.map((course) {
          final enrollAsync = ref.watch(courseEnrollmentsProvider(course.courseId));
          return enrollAsync.when(
            loading: () => const SizedBox.shrink(),
            error: (_, __) => const SizedBox.shrink(),
            data: (list) {
              final pending = list.where((e) => e.isPending).toList();
              if (pending.isEmpty) return const SizedBox.shrink();
              return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Padding(padding: const EdgeInsets.only(bottom: 8),
                  child: Row(children: [
                    Container(width: 4, height: 20,
                        decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(2))),
                    const SizedBox(width: 8),
                    Expanded(child: Text(course.title,
                        style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14))),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(color: AppColors.warning.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(20)),
                      child: Text('${pending.length} chờ',
                          style: const TextStyle(color: AppColors.warning, fontSize: 11, fontWeight: FontWeight.w700)),
                    ),
                  ]),
                ),
                ...pending.map((e) => _PendingCard(enrollment: e, courseId: course.courseId)),
                const SizedBox(height: 16),
              ]);
            },
          );
        }).toList());
      },
    );
  }
}

class _PendingCard extends ConsumerWidget {
  const _PendingCard({required this.enrollment, required this.courseId});
  final EnrollmentEntity enrollment;
  final String courseId;
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final df = DateFormat('dd/MM HH:mm');
    final loading = ref.watch(teacherCourseViewModelProvider.select((s) => s is CourseLoading));
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.white,
          borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
      child: Row(children: [
        CircleAvatar(radius: 18, backgroundColor: AppColors.primary.withOpacity(0.1),
            child: const Icon(Icons.person_outline, size: 18, color: AppColors.primary)),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(enrollment.studentName ?? 'Học sinh',
              style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
          Text('Đăng ký: ${df.format(enrollment.createdAt)}',
              style: const TextStyle(fontSize: 11, color: AppColors.textSub)),
        ])),
        const SizedBox(width: 8),
        Row(children: [
          ElevatedButton(
            onPressed: loading ? null : () => ref
                .read(teacherCourseViewModelProvider.notifier)
                .confirmEnrollment(enrollment.enrollmentId, courseId),
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.success,
                minimumSize: const Size(70, 34), padding: const EdgeInsets.symmetric(horizontal: 10),
                textStyle: const TextStyle(fontSize: 12)),
            child: const Text('Xác nhận'),
          ),
          const SizedBox(width: 6),
          OutlinedButton(
            onPressed: loading ? null : () => ref
                .read(courseViewModelProvider.notifier)
                .cancelEnrollment(enrollment.enrollmentId, courseId),
            style: OutlinedButton.styleFrom(foregroundColor: AppColors.error,
                side: const BorderSide(color: AppColors.error),
                minimumSize: const Size(60, 34), padding: const EdgeInsets.symmetric(horizontal: 10),
                textStyle: const TextStyle(fontSize: 12)),
            child: const Text('Từ chối'),
          ),
        ]),
      ]),
    );
  }
}

// ── Create Course Bottom Sheet ────────────────────────────────
class _CreateSheet extends ConsumerStatefulWidget {
  const _CreateSheet();
  @override
  ConsumerState<_CreateSheet> createState() => _CreateSheetState();
}

class _CreateSheetState extends ConsumerState<_CreateSheet> {
  final _formKey   = GlobalKey<FormState>();
  final _titleCtrl = TextEditingController();
  final _descCtrl  = TextEditingController();
  final _priceCtrl = TextEditingController();
  String _subject = 'Toán', _level = 'Cơ bản';
  int _totalSessions = 8, _maxStudents = 5;
  DateTime _startDate = DateTime.now().add(const Duration(days: 7));
  final List<Map<String, int>> _schedule = [];

  static const _subjects = ['Toán','Lý','Hóa','Văn','Anh','Sinh','Sử','Địa'];
  static const _levels   = ['Cơ bản','Nâng cao','Luyện thi'];
  static const _days     = ['T2','T3','T4','T5','T6','T7','CN'];

  @override
  void dispose() { _titleCtrl.dispose(); _descCtrl.dispose(); _priceCtrl.dispose(); super.dispose(); }

  Future<void> _addDay(int i) async {
    final dow = i + 1;
    if (_schedule.any((s) => s['dayOfWeek'] == dow)) {
      setState(() => _schedule.removeWhere((s) => s['dayOfWeek'] == dow)); return;
    }
    final t = await showTimePicker(context: context,
        initialTime: const TimeOfDay(hour: 14, minute: 0));
    if (t == null) return;
    setState(() => _schedule.add(
        {'dayOfWeek': dow, 'hour': t.hour, 'minute': t.minute, 'durationMinutes': 90}));
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_schedule.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Chọn ít nhất 1 ngày học'), backgroundColor: AppColors.error));
      return;
    }
    final entries = _schedule.map((s) => CourseScheduleEntry(
        dayOfWeek: s['dayOfWeek']!, hour: s['hour']!,
        minute: s['minute']!, durationMinutes: s['durationMinutes']!)).toList();
    await ref.read(teacherCourseViewModelProvider.notifier).createCourse(
      title: _titleCtrl.text, description: _descCtrl.text,
      subject: _subject, totalSessions: _totalSessions,
      pricePerCourse: double.tryParse(_priceCtrl.text.replaceAll('.', '')) ?? 0,
      scheduleEntries: entries, startDate: _startDate,
      maxStudents: _maxStudents, level: _level,
    );
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final loading = ref.watch(teacherCourseViewModelProvider.select((s) => s is CourseLoading));
    final df = DateFormat('dd/MM/yyyy');
    return DraggableScrollableSheet(
      initialChildSize: 0.92, maxChildSize: 0.96, minChildSize: 0.5, expand: false,
      builder: (_, ctrl) => Column(children: [
        Container(margin: const EdgeInsets.only(top: 12, bottom: 4),
            width: 40, height: 4,
            decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2))),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          child: Row(children: [
            const Text('Tạo khóa học mới',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const Spacer(),
            IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(context)),
          ])),
        const Divider(height: 1),
        Expanded(child: Form(key: _formKey, child: ListView(controller: ctrl, padding: const EdgeInsets.all(20), children: [
          _L('Tên khóa học *'),
          TextFormField(controller: _titleCtrl,
              decoration: const InputDecoration(hintText: 'VD: Toán 10 - Ôn thi'),
              validator: (v) => (v?.trim().isEmpty ?? true) ? 'Nhập tên khóa' : null),
          const SizedBox(height: 16),
          _L('Mô tả'),
          TextFormField(controller: _descCtrl, maxLines: 3,
              decoration: const InputDecoration(hintText: 'Mô tả nội dung, mục tiêu...')),
          const SizedBox(height: 16),
          Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _L('Môn học'),
              DropdownButtonFormField<String>(value: _subject,
                  decoration: const InputDecoration(),
                  items: _subjects.map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
                  onChanged: (v) => setState(() => _subject = v!)),
            ])),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _L('Cấp độ'),
              DropdownButtonFormField<String>(value: _level,
                  decoration: const InputDecoration(),
                  items: _levels.map((l) => DropdownMenuItem(value: l, child: Text(l))).toList(),
                  onChanged: (v) => setState(() => _level = v!)),
            ])),
          ]),
          const SizedBox(height: 16),
          Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _L('Số buổi'),
              _Stepper(value: _totalSessions, min: 1, max: 48,
                  onChanged: (v) => setState(() => _totalSessions = v)),
            ])),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _L('Học sinh tối đa'),
              _Stepper(value: _maxStudents, min: 1, max: 30,
                  onChanged: (v) => setState(() => _maxStudents = v)),
            ])),
          ]),
          const SizedBox(height: 16),
          _L('Học phí (VNĐ) *'),
          TextFormField(controller: _priceCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(hintText: '800000', suffixText: 'đ'),
              validator: (v) => (v?.trim().isEmpty ?? true) ? 'Nhập học phí' : null),
          const SizedBox(height: 16),
          _L('Ngày bắt đầu'),
          GestureDetector(
            onTap: () async {
              final d = await showDatePicker(context: context, initialDate: _startDate,
                  firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 180)));
              if (d != null) setState(() => _startDate = d);
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
              decoration: BoxDecoration(color: const Color(0xFFF1F5F9),
                  borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
              child: Row(children: [
                const Icon(Icons.calendar_today_outlined, size: 18, color: AppColors.primary),
                const SizedBox(width: 10),
                Text(df.format(_startDate), style: const TextStyle(fontWeight: FontWeight.w600)),
                const Spacer(),
                const Icon(Icons.chevron_right, color: AppColors.textSub),
              ]),
            ),
          ),
          const SizedBox(height: 16),
          _L('Lịch học hàng tuần'),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: List.generate(7, (i) {
            final dow = i + 1;
            final sel = _schedule.any((s) => s['dayOfWeek'] == dow);
            return GestureDetector(
              onTap: () => _addDay(i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                width: 44, height: 44,
                decoration: BoxDecoration(
                  color: sel ? AppColors.primary : const Color(0xFFF1F5F9),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: sel ? AppColors.primary : AppColors.border)),
                child: Center(child: Text(_days[i],
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700,
                        color: sel ? Colors.white : AppColors.textSub))),
              ),
            );
          })),
          if (_schedule.isNotEmpty) ...[
            const SizedBox(height: 12),
            ..._schedule.map((s) {
              final dow = s['dayOfWeek']!;
              final h = s['hour']!.toString().padLeft(2, '0');
              final m = s['minute']!.toString().padLeft(2, '0');
              return Container(
                margin: const EdgeInsets.only(bottom: 6),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: AppColors.primary.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppColors.primary.withOpacity(0.2))),
                child: Row(children: [
                  Text(_days[dow - 1], style: const TextStyle(
                      fontWeight: FontWeight.w700, color: AppColors.primary)),
                  const SizedBox(width: 12),
                  Text('$h:$m – 90 phút', style: const TextStyle(fontSize: 13)),
                  const Spacer(),
                  GestureDetector(
                    onTap: () => setState(() => _schedule.removeWhere((e) => e['dayOfWeek'] == dow)),
                    child: const Icon(Icons.close, size: 16, color: AppColors.error)),
                ]),
              );
            }),
          ],
          const SizedBox(height: 28),
          ElevatedButton(
            onPressed: loading ? null : _submit,
            child: loading
                ? const SizedBox(height: 20, width: 20,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Text('Tạo khóa học'),
          ),
          const SizedBox(height: 16),
        ]))),
      ]),
    );
  }
}

class _L extends StatelessWidget {
  const _L(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Text(text, style: const TextStyle(
            fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textSub)));
}

class _Stepper extends StatelessWidget {
  const _Stepper({required this.value, required this.min,
      required this.max, required this.onChanged});
  final int value, min, max;
  final ValueChanged<int> onChanged;
  @override
  Widget build(BuildContext context) => Container(
        height: 48,
        decoration: BoxDecoration(color: const Color(0xFFF1F5F9),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border)),
        child: Row(children: [
          IconButton(icon: const Icon(Icons.remove, size: 18),
              onPressed: value > min ? () => onChanged(value - 1) : null),
          Expanded(child: Text('$value', textAlign: TextAlign.center,
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15))),
          IconButton(icon: const Icon(Icons.add, size: 18),
              onPressed: value < max ? () => onChanged(value + 1) : null),
        ]),
      );
}
