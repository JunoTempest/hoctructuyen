import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../../core/constants/app_enums.dart';
import '../../domain/entities/course_entity.dart';
import '../../domain/entities/course_schedule_entity.dart';

class CourseModel {
  const CourseModel({
    required this.courseId, required this.teacherId,
    required this.title, required this.description,
    required this.subject, required this.totalSessions,
    required this.pricePerCourse, required this.scheduleEntries,
    required this.startDate, required this.maxStudents,
    required this.enrolledCount, required this.status,
    required this.createdAt,
    this.teacherName, this.teacherPhotoUrl, this.teacherRating,
    this.thumbnailUrl, this.level,
  });

  final String courseId, teacherId, title, description, subject, status;
  final int totalSessions, maxStudents, enrolledCount;
  final double pricePerCourse;
  final List<Map<String, dynamic>> scheduleEntries;
  final DateTime startDate, createdAt;
  final String? teacherName, teacherPhotoUrl, thumbnailUrl, level;
  final double? teacherRating;

  factory CourseModel.fromFirestore(DocumentSnapshot doc) {
    final d = doc.data() as Map<String, dynamic>;
    return CourseModel(
      courseId:       doc.id,
      teacherId:      d['teacherId']   as String,
      title:          d['title']       as String,
      description:    d['description'] as String? ?? '',
      subject:        d['subject']     as String? ?? '',
      totalSessions:  d['totalSessions']  as int? ?? 1,
      pricePerCourse: (d['pricePerCourse'] as num?)?.toDouble() ?? 0,
      scheduleEntries: (d['scheduleEntries'] as List<dynamic>?)
              ?.map((e) => Map<String, dynamic>.from(e as Map)).toList() ?? [],
      startDate:      d['startDate'] is Timestamp
          ? (d['startDate'] as Timestamp).toDate() : DateTime.now(),
      maxStudents:    d['maxStudents']   as int? ?? 1,
      enrolledCount:  d['enrolledCount'] as int? ?? 0,
      status:         d['status']        as String? ?? 'draft',
      createdAt:      d['createdAt'] is Timestamp
          ? (d['createdAt'] as Timestamp).toDate() : DateTime.now(),
      teacherName:     d['teacherName']     as String?,
      teacherPhotoUrl: d['teacherPhotoUrl'] as String?,
      teacherRating:   (d['teacherRating']  as num?)?.toDouble(),
      thumbnailUrl:    d['thumbnailUrl']    as String?,
      level:           d['level']           as String?,
    );
  }

  Map<String, dynamic> toFirestore() => {
        'teacherId': teacherId, 'title': title, 'description': description,
        'subject': subject, 'totalSessions': totalSessions,
        'pricePerCourse': pricePerCourse, 'scheduleEntries': scheduleEntries,
        'startDate': Timestamp.fromDate(startDate),
        'maxStudents': maxStudents, 'enrolledCount': enrolledCount,
        'status': status, 'teacherName': teacherName,
        'teacherPhotoUrl': teacherPhotoUrl, 'teacherRating': teacherRating,
        'thumbnailUrl': thumbnailUrl, 'level': level,
        'createdAt': FieldValue.serverTimestamp(),
      };

  CourseEntity toEntity() => CourseEntity(
        courseId: courseId, teacherId: teacherId, title: title,
        description: description, subject: subject,
        totalSessions: totalSessions, pricePerCourse: pricePerCourse,
        scheduleEntries: scheduleEntries.map(CourseScheduleEntry.fromMap).toList(),
        startDate: startDate, maxStudents: maxStudents,
        enrolledCount: enrolledCount, status: CourseStatusX.fromString(status),
        createdAt: createdAt, teacherName: teacherName,
        teacherPhotoUrl: teacherPhotoUrl, teacherRating: teacherRating,
        thumbnailUrl: thumbnailUrl, level: level,
      );
}
