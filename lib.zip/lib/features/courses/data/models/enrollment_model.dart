import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../../core/constants/app_enums.dart';
import '../../domain/entities/enrollment_entity.dart';

class EnrollmentModel {
  const EnrollmentModel({
    required this.enrollmentId, required this.courseId,
    required this.studentId, required this.status, required this.createdAt,
    this.courseTitle, this.teacherName, this.teacherId, this.studentName,
    this.totalSessions, this.completedSessions, this.startDate, this.pricePerCourse,
  });

  final String enrollmentId, courseId, studentId, status;
  final DateTime createdAt;
  final String? courseTitle, teacherName, teacherId, studentName;
  final int? totalSessions, completedSessions;
  final DateTime? startDate;
  final double? pricePerCourse;

  factory EnrollmentModel.fromFirestore(DocumentSnapshot doc) {
    final d = doc.data() as Map<String, dynamic>;
    return EnrollmentModel(
      enrollmentId:      doc.id,
      courseId:          d['courseId']  as String,
      studentId:         d['studentId'] as String,
      status:            d['status']    as String? ?? 'pending',
      createdAt:         d['createdAt'] is Timestamp
          ? (d['createdAt'] as Timestamp).toDate() : DateTime.now(),
      courseTitle:       d['courseTitle']  as String?,
      teacherName:       d['teacherName']  as String?,
      teacherId:         d['teacherId']    as String?,
      studentName:       d['studentName']  as String?,
      totalSessions:     d['totalSessions']     as int?,
      completedSessions: d['completedSessions'] as int? ?? 0,
      startDate:         d['startDate'] is Timestamp
          ? (d['startDate'] as Timestamp).toDate() : null,
      pricePerCourse:    (d['pricePerCourse'] as num?)?.toDouble(),
    );
  }

  Map<String, dynamic> toFirestore() => {
        'courseId': courseId, 'studentId': studentId, 'status': status,
        'courseTitle': courseTitle, 'teacherName': teacherName,
        'teacherId': teacherId, 'studentName': studentName,
        'totalSessions': totalSessions, 'completedSessions': completedSessions ?? 0,
        'startDate': startDate != null ? Timestamp.fromDate(startDate!) : null,
        'pricePerCourse': pricePerCourse,
        'createdAt': FieldValue.serverTimestamp(),
      };

  EnrollmentEntity toEntity() => EnrollmentEntity(
        enrollmentId: enrollmentId, courseId: courseId, studentId: studentId,
        status: EnrollmentStatusX.fromString(status), createdAt: createdAt,
        courseTitle: courseTitle, teacherName: teacherName, teacherId: teacherId,
        studentName: studentName, totalSessions: totalSessions,
        completedSessions: completedSessions, startDate: startDate,
        pricePerCourse: pricePerCourse,
      );
}
