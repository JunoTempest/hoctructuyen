import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../../core/constants/app_enums.dart';
import '../../../../core/constants/firestore_paths.dart';
import '../../domain/entities/course_entity.dart';
import '../../domain/entities/course_schedule_entity.dart';
import '../../domain/entities/enrollment_entity.dart';
import '../../domain/repositories/course_repository.dart';
import '../models/course_model.dart';
import '../models/enrollment_model.dart';

class CourseRepositoryImpl implements CourseRepository {
  CourseRepositoryImpl(this._db);
  final FirebaseFirestore _db;

  @override
  Future<List<CourseEntity>> getOpenCourses({String? subject, String? teacherId}) async {
    // Chỉ filter theo 1 field để tránh cần composite index
    Query<Map<String, dynamic>> q = _db.collection(FirestorePaths.courses)
        .where('status', isEqualTo: 'open');
    if (teacherId != null) q = q.where('teacherId', isEqualTo: teacherId);
    final snap = await q.get();
    var list = snap.docs.map((d) => CourseModel.fromFirestore(d).toEntity()).toList();
    // Filter subject + sort phía client
    if (subject != null) list = list.where((c) => c.subject == subject).toList();
    list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return list;
  }

  @override
  Future<CourseEntity> getCourse(String courseId) async {
    final doc = await _db.collection(FirestorePaths.courses).doc(courseId).get();
    if (!doc.exists) throw Exception('Không tìm thấy khóa học');
    return CourseModel.fromFirestore(doc).toEntity();
  }

  @override
  Future<CourseEntity> createCourse({
    required String teacherId, required String title,
    required String description, required String subject,
    required int totalSessions, required double pricePerCourse,
    required List<CourseScheduleEntry> scheduleEntries,
    required DateTime startDate, required int maxStudents,
    String? level, String? thumbnailUrl,
  }) async {
    final ref = _db.collection(FirestorePaths.courses).doc();
    // Khoá học cá nhân cần admin duyệt → status = pending
    final model = CourseModel(
      courseId: ref.id, teacherId: teacherId, title: title,
      description: description, subject: subject,
      totalSessions: totalSessions, pricePerCourse: pricePerCourse,
      scheduleEntries: scheduleEntries.map((e) => e.toMap()).toList(),
      startDate: startDate, maxStudents: maxStudents,
      enrolledCount: 0, status: 'pending', createdAt: DateTime.now(),
      level: level, thumbnailUrl: thumbnailUrl,
    );
    await ref.set(model.toFirestore());
    return model.toEntity();
  }

  @override
  Future<void> updateCourseStatus(String courseId, CourseStatus status) =>
      _db.collection(FirestorePaths.courses).doc(courseId)
          .update({'status': status.name});

  @override
  Stream<List<CourseEntity>> watchTeacherCourses(String teacherId) =>
      _db.collection(FirestorePaths.courses)
          .where('teacherId', isEqualTo: teacherId)
          .snapshots()
          .map((s) {
            final list = s.docs.map((d) => CourseModel.fromFirestore(d).toEntity()).toList();
            list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
            return list;
          });

  @override
  Future<EnrollmentEntity> enrollCourse({
    required String studentId, required String courseId,
  }) async {
    return _db.runTransaction((tx) async {
      final courseRef = _db.collection(FirestorePaths.courses).doc(courseId);
      final courseSnap = await tx.get(courseRef);
      if (!courseSnap.exists) throw Exception('Khóa học không tồn tại');
      final course = CourseModel.fromFirestore(courseSnap);
      if (course.enrolledCount >= course.maxStudents) throw Exception('Khóa học đã đầy');
      if (course.status != 'open') throw Exception('Khóa học không còn nhận đăng ký');

      final enrollRef = _db.collection(FirestorePaths.enrollments).doc();
      final model = EnrollmentModel(
        enrollmentId: enrollRef.id, courseId: courseId, studentId: studentId,
        status: 'pending', createdAt: DateTime.now(),
        courseTitle: course.title, teacherId: course.teacherId,
        teacherName: course.teacherName, totalSessions: course.totalSessions,
        startDate: course.startDate, pricePerCourse: course.pricePerCourse,
      );
      tx.set(enrollRef, model.toFirestore());
      tx.update(courseRef, {
        'enrolledCount': FieldValue.increment(1),
        if (course.enrolledCount + 1 >= course.maxStudents) 'status': 'full',
      });
      return model.toEntity();
    });
  }

  @override
  Future<EnrollmentEntity> confirmEnrollment(String enrollmentId) async {
    return _db.runTransaction((tx) async {
      final enrollRef = _db.collection(FirestorePaths.enrollments).doc(enrollmentId);
      final enrollSnap = await tx.get(enrollRef);
      if (!enrollSnap.exists) throw Exception('Enrollment không tồn tại');
      final enrollment = EnrollmentModel.fromFirestore(enrollSnap);

      final courseRef = _db.collection(FirestorePaths.courses).doc(enrollment.courseId);
      final courseSnap = await tx.get(courseRef);
      final course = CourseModel.fromFirestore(courseSnap);
      final entries = course.scheduleEntries.map(CourseScheduleEntry.fromMap).toList();

      tx.update(enrollRef, {'status': 'confirmed'});

      final sessions = _generateSessions(
        courseId: course.courseId, enrollmentId: enrollmentId,
        teacherId: course.teacherId, studentId: enrollment.studentId,
        teacherName: course.teacherName, studentName: enrollment.studentName,
        courseTitle: course.title, startDate: course.startDate,
        totalSessions: course.totalSessions, scheduleEntries: entries,
      );

      for (final s in sessions) {
        final sRef = _db.collection(FirestorePaths.sessions).doc();
        tx.set(sRef, {...s, 'sessionId': sRef.id});
      }

      return enrollment.toEntity().copyWithStatus(EnrollmentStatus.confirmed);
    });
  }

  @override
  Future<EnrollmentEntity> cancelEnrollment(String enrollmentId) async {
    return _db.runTransaction((tx) async {
      final enrollRef = _db.collection(FirestorePaths.enrollments).doc(enrollmentId);
      final snap = await tx.get(enrollRef);
      if (!snap.exists) throw Exception('Enrollment không tồn tại');
      final enrollment = EnrollmentModel.fromFirestore(snap);
      tx.update(enrollRef, {'status': 'cancelled'});
      tx.update(
        _db.collection(FirestorePaths.courses).doc(enrollment.courseId),
        {'enrolledCount': FieldValue.increment(-1), 'status': 'open'},
      );
      return enrollment.toEntity().copyWithStatus(EnrollmentStatus.cancelled);
    });
  }

  @override
  Stream<List<EnrollmentEntity>> watchStudentEnrollments(String studentId) =>
      _db.collection(FirestorePaths.enrollments)
          .where('studentId', isEqualTo: studentId)
          .snapshots()
          .map((s) {
            final list = s.docs.map((d) => EnrollmentModel.fromFirestore(d).toEntity()).toList();
            list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
            return list;
          });

  @override
  Stream<List<EnrollmentEntity>> watchCourseEnrollments(String courseId) =>
      _db.collection(FirestorePaths.enrollments)
          .where('courseId', isEqualTo: courseId)
          .snapshots()
          .map((s) => s.docs.map((d) => EnrollmentModel.fromFirestore(d).toEntity()).toList());

  @override
  Future<EnrollmentEntity?> getMyEnrollment({
    required String studentId, required String courseId,
  }) async {
    final snap = await _db.collection(FirestorePaths.enrollments)
        .where('studentId', isEqualTo: studentId)
        .where('courseId',  isEqualTo: courseId)
        .limit(1).get();
    if (snap.docs.isEmpty) return null;
    return EnrollmentModel.fromFirestore(snap.docs.first).toEntity();
  }

  List<Map<String, dynamic>> _generateSessions({
    required String courseId, required String enrollmentId,
    required String teacherId, required String studentId,
    required String? teacherName, required String? studentName,
    required String? courseTitle, required DateTime startDate,
    required int totalSessions, required List<CourseScheduleEntry> scheduleEntries,
  }) {
    final sessions = <Map<String, dynamic>>[];
    if (scheduleEntries.isEmpty) return sessions;
    final sorted = List<CourseScheduleEntry>.from(scheduleEntries)
      ..sort((a, b) => a.dayOfWeek.compareTo(b.dayOfWeek));
    var currentDate = startDate;
    var count = 0;
    while (count < totalSessions) {
      for (final entry in sorted) {
        if (count >= totalSessions) break;
        var date = currentDate;
        while (date.weekday != entry.dayOfWeek) {
          date = date.add(const Duration(days: 1));
        }
        final start = DateTime(date.year, date.month, date.day, entry.hour, entry.minute);
        final end   = start.add(Duration(minutes: entry.durationMinutes));
        sessions.add({
          'bookingId':     enrollmentId,
          'courseId':      courseId,
          'teacherId':     teacherId,
          'studentId':     studentId,
          'agoraChannel':  'course_${courseId.substring(0, 6)}_${count + 1}',
          'startTime':     Timestamp.fromDate(start),
          'endTime':       Timestamp.fromDate(end),
          'status':        'scheduled',
          'teacherName':   teacherName,
          'studentName':   studentName,
          'subjectName':   courseTitle,
          'sessionNumber': count + 1,
          'totalSessions': totalSessions,
          'type':          'course',
          'createdAt':     FieldValue.serverTimestamp(),
        });
        count++;
      }
      currentDate = currentDate.add(const Duration(days: 7));
    }
    return sessions;
  }
}

extension EnrollmentEntityX on EnrollmentEntity {
  EnrollmentEntity copyWithStatus(EnrollmentStatus s) => EnrollmentEntity(
        enrollmentId: enrollmentId, courseId: courseId, studentId: studentId,
        status: s, createdAt: createdAt, courseTitle: courseTitle,
        teacherName: teacherName, teacherId: teacherId, studentName: studentName,
        totalSessions: totalSessions, completedSessions: completedSessions,
        startDate: startDate, pricePerCourse: pricePerCourse,
      );
}
