import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../../app/router/app_router.dart';
import '../../../../app/theme/app_theme.dart';
import '../../../../core/constants/app_enums.dart';
import '../../../auth/domain/entities/user_entity.dart';
import '../../../auth/presentation/providers/auth_provider.dart';
import '../../../scheduling/presentation/providers/scheduling_provider.dart';

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userAsync = ref.watch(authStateStreamProvider);

    return userAsync.when(
      loading: () =>
          const Scaffold(body: Center(child: CircularProgressIndicator())),
      error: (e, _) =>
          Scaffold(body: Center(child: Text('Lỗi: $e'))),
      data: (user) {
        if (user == null) return const Scaffold(body: SizedBox());
        return Scaffold(
          backgroundColor: AppColors.bg,
          body: RefreshIndicator(
            onRefresh: () async {
              ref.invalidate(userBookingsProvider);
              ref.invalidate(userSessionsProvider);
            },
            child: CustomScrollView(
              slivers: [
                _AppBar(user: user),
                SliverPadding(
                  padding: const EdgeInsets.all(16),
                  sliver: SliverList(
                    delegate: SliverChildListDelegate([
                      _GreetingCard(user: user),
                      const SizedBox(height: 20),
                      _QuickStats(user: user),
                      const SizedBox(height: 20),
                      const Text('Truy cập nhanh',
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w700)),
                      const SizedBox(height: 12),
                      _QuickActions(role: user.role),
                      const SizedBox(height: 20),
                      const Text('Buổi học sắp tới',
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w700)),
                      const SizedBox(height: 12),
                      const _UpcomingSessions(),
                    ]),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _AppBar extends StatelessWidget {
  const _AppBar({required this.user});
  final UserEntity user;

  @override
  Widget build(BuildContext context) => SliverAppBar(
        floating: true,
        snap: true,
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
        title: Row(
          children: [
            const Text('EduApp',
                style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 20,
                    color: AppColors.primary)),
            const Spacer(),
            CircleAvatar(
              radius: 18,
              backgroundColor: user.role.color.withOpacity(0.12),
              child: Text(user.initials,
                  style: TextStyle(
                      color: user.role.color,
                      fontWeight: FontWeight.w700,
                      fontSize: 13)),
            ),
          ],
        ),
      );
}

class _GreetingCard extends StatelessWidget {
  const _GreetingCard({required this.user});
  final UserEntity user;

  String get _greeting {
    final h = DateTime.now().hour;
    if (h < 12) return 'Chào buổi sáng';
    if (h < 18) return 'Chào buổi chiều';
    return 'Chào buổi tối';
  }

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [AppColors.primary, AppColors.secondary],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('$_greeting! 👋',
                      style: const TextStyle(
                          color: Colors.white70, fontSize: 13)),
                  const SizedBox(height: 4),
                  Text(user.displayName,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 3),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(user.role.label,
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 11,
                            fontWeight: FontWeight.w600)),
                  ),
                ],
              ),
            ),
            const Text('📚', style: TextStyle(fontSize: 52)),
          ],
        ),
      );
}

class _QuickStats extends ConsumerWidget {
  const _QuickStats({required this.user});
  final UserEntity user;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sessionCount = ref
            .watch(userSessionsProvider)
            .value
            ?.where((s) => s.isUpcoming)
            .length ??
        0;
    final bookingCount =
        ref.watch(userBookingsProvider).value?.length ?? 0;

    final stats = user.isTeacher
        ? [
            (Icons.pending_outlined, '$bookingCount', 'Booking chờ'),
            (Icons.video_call_outlined, '$sessionCount', 'Sắp dạy'),
          ]
        : [
            (Icons.pending_outlined, '$bookingCount', 'Đặt lịch'),
            (Icons.video_call_outlined, '$sessionCount', 'Sắp học'),
          ];

    return Row(
      children: stats.asMap().entries.map((entry) {
        final (icon, value, label) = entry.value;
        return Expanded(
          child: Container(
            margin: entry.key == 0
                ? const EdgeInsets.only(right: 6)
                : const EdgeInsets.only(left: 6),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.border),
            ),
            child: Row(children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppColors.primary.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, size: 18, color: AppColors.primary),
              ),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(value,
                      style: const TextStyle(
                          fontSize: 20, fontWeight: FontWeight.w800)),
                  Text(label,
                      style: const TextStyle(
                          fontSize: 11, color: AppColors.textSub)),
                ],
              ),
            ]),
          ),
        );
      }).toList(),
    );
  }
}

class _QuickActions extends StatelessWidget {
  const _QuickActions({required this.role});
  final UserRole role;

  @override
  Widget build(BuildContext context) {
    final actions = role == UserRole.teacher
        ? [
            (Icons.add_circle_outline, 'Tạo slot\nlịch dạy', AppRoutes.schedule),
            (Icons.menu_book_outlined, 'Tạo khóa\nhọc', AppRoutes.teacherCourses),
          ]
        : role == UserRole.admin
            ? [
                (Icons.admin_panel_settings_outlined, 'Quản lý\nnguười dùng', AppRoutes.admin),
                (Icons.bar_chart_outlined, 'Thống kê', AppRoutes.admin),
              ]
            : [
                (Icons.search_outlined, 'Tìm giáo\nviên', AppRoutes.schedule),
                (Icons.explore_outlined, 'Khóa học', AppRoutes.courses),
                (Icons.school_outlined, 'Của tôi', AppRoutes.myEnrollments),
                (Icons.person_outline, 'Tài khoản', AppRoutes.profile),
              ];

    return GridView.count(
      crossAxisCount: 4,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 8,
      crossAxisSpacing: 8,
      children: actions.map((a) {
        final (icon, label, route) = a;
        return GestureDetector(
          onTap: () => context.go(route),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.border),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppColors.primary.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(icon, size: 20, color: AppColors.primary),
                ),
                const SizedBox(height: 6),
                Text(label,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textSub)),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }
}

class _UpcomingSessions extends ConsumerWidget {
  const _UpcomingSessions();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sessionsAsync = ref.watch(userSessionsProvider);
    final df = DateFormat('HH:mm, dd/MM');

    return sessionsAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (_, __) => const SizedBox.shrink(),
      data: (sessions) {
        final upcoming = sessions
            .where((s) => s.isUpcoming && s.isScheduled)
            .take(3)
            .toList();

        if (upcoming.isEmpty) {
          return Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.border),
            ),
            child: const Center(
              child: Text('Không có buổi học sắp tới',
                  style: TextStyle(
                      color: AppColors.textSub, fontSize: 13)),
            ),
          );
        }

        return Column(
          children: upcoming.map((s) => Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: AppColors.border),
                ),
                child: Row(children: [
                  Container(
                    width: 4,
                    height: 40,
                    decoration: BoxDecoration(
                      color: AppColors.primary,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(s.subjectName ?? 'Buổi học',
                            style: const TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 14)),
                        Text(df.format(s.startTime),
                            style: const TextStyle(
                                fontSize: 12,
                                color: AppColors.textSub)),
                      ],
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () => context.push(
                      AppRoutes.classroomPath(s.sessionId),
                      extra: {
                        'channelName': s.agoraChannel,
                        'title': s.subjectName ?? 'Buổi học',
                        'startTime': s.startTime,
                      },
                    ),
                    style: ElevatedButton.styleFrom(
                        minimumSize: const Size(72, 34),
                        padding:
                            const EdgeInsets.symmetric(horizontal: 12),
                        textStyle: const TextStyle(fontSize: 12)),
                    child: const Text('Vào học'),
                  ),
                ]),
              )).toList(),
        );
      },
    );
  }
}
