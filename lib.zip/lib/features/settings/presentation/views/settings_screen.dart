import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../app/router/app_router.dart';
import '../../../../app/theme/app_theme.dart';
import '../../../../app/theme/theme_provider.dart';
import '../../../../core/constants/app_enums.dart';
import '../../../../core/constants/firestore_paths.dart';
import '../../../../core/di/firebase_providers.dart';
import '../../../auth/domain/entities/user_entity.dart';
import '../../../auth/presentation/providers/auth_provider.dart';

// Inline helper – không dùng extension trên dynamic
Color _roleColor(UserRole role) {
  switch (role) {
    case UserRole.teacher: return const Color(0xFF0891B2);
    case UserRole.admin:   return const Color(0xFF7C3AED);
    case UserRole.student: return const Color(0xFF16A34A);
  }
}
String _roleLabel(UserRole role) {
  switch (role) {
    case UserRole.teacher: return 'Giáo viên';
    case UserRole.admin:   return 'Quản trị viên';
    case UserRole.student: return 'Học sinh';
  }
}

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authStateStreamProvider).value;
    if (user == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));

    final themeMode = ref.watch(appThemeModeProvider);
    final isDark = themeMode == ThemeMode.dark;
    final color  = _roleColor(user.role);

    return Scaffold(
      appBar: AppBar(title: const Text('Cài đặt')),
      body: ListView(
        children: [
          // Profile header
          InkWell(
            onTap: () => context.go(AppRoutes.profile),
            child: Container(
              margin: const EdgeInsets.all(16),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.primary.withValues(alpha: 0.06),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.primary.withValues(alpha: 0.15)),
              ),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 28,
                    backgroundColor: color.withValues(alpha: 0.15),
                    backgroundImage: user.photoUrl != null ? NetworkImage(user.photoUrl!) : null,
                    child: user.photoUrl == null
                        ? Text(user.initials,
                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: color))
                        : null,
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(user.displayName,
                            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                        const SizedBox(height: 2),
                        Text(user.email,
                            style: const TextStyle(color: AppColors.textSub, fontSize: 13)),
                        const SizedBox(height: 4),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: color.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(_roleLabel(user.role),
                              style: TextStyle(fontSize: 11, color: color, fontWeight: FontWeight.w600)),
                        ),
                      ],
                    ),
                  ),
                  const Icon(Icons.chevron_right, color: AppColors.textSub),
                ],
              ),
            ),
          ),

          _SectionHeader('Giao diện'),
          _SettingsTile(
            icon: isDark ? Icons.dark_mode : Icons.light_mode,
            title: isDark ? 'Dark Mode' : 'Light Mode',
            subtitle: 'Thay đổi giao diện sáng/tối',
            trailing: Switch(
              value: isDark,
              onChanged: (_) => ref.read(appThemeModeProvider.notifier).toggle(),
            ),
          ),

          _SectionHeader('Tài khoản'),
          _SettingsTile(
            icon: Icons.person_outline,
            title: 'Hồ sơ cá nhân',
            subtitle: 'Chỉnh sửa thông tin cá nhân',
            onTap: () => context.go(AppRoutes.profile),
          ),

          _SectionHeader('Ứng dụng'),
          const _SettingsTile(
            icon: Icons.info_outline,
            title: 'Phiên bản',
            subtitle: 'v1.0.0 (build 1)',
          ),
          _SettingsTile(
            icon: Icons.bug_report_outlined,
            title: 'Báo cáo lỗi',
            subtitle: 'Gửi phản hồi cho đội ngũ phát triển',
            onTap: () => _showBugReport(context, ref, user),
          ),

          const Divider(height: 32),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: OutlinedButton.icon(
              icon: const Icon(Icons.logout, color: AppColors.error),
              label: const Text('Đăng xuất',
                  style: TextStyle(color: AppColors.error, fontWeight: FontWeight.w600, fontSize: 15)),
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: AppColors.error),
                minimumSize: const Size(double.infinity, 50),
              ),
              onPressed: () => _confirmLogout(context, ref),
            ),
          ),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  void _showBugReport(BuildContext context, WidgetRef ref, UserEntity user) {
    final titleCtrl = TextEditingController();
    final descCtrl  = TextEditingController();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
          left: 20, right: 20, top: 20,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Báo cáo lỗi',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 16),
            TextField(controller: titleCtrl,
                decoration: const InputDecoration(
                    labelText: 'Tiêu đề', hintText: 'Mô tả ngắn về lỗi...')),
            const SizedBox(height: 12),
            TextField(controller: descCtrl, maxLines: 4,
                decoration: const InputDecoration(
                    labelText: 'Mô tả chi tiết',
                    hintText: 'Lỗi xảy ra khi nào, ở đâu...',
                    alignLabelWithHint: true)),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.send),
                label: const Text('Gửi báo cáo'),
                onPressed: () async {
                  if (titleCtrl.text.isEmpty) return;
                  final db = ref.read(firebaseFirestoreProvider);
                  await db.collection(FirestorePaths.bugReports).add({
                    'title':       titleCtrl.text.trim(),
                    'description': descCtrl.text.trim(),
                    'userId':      user.id,
                    'userEmail':   user.email,
                    'resolved':    false,
                    'createdAt':   DateTime.now().toIso8601String(),
                  });
                  if (ctx.mounted) {
                    Navigator.pop(ctx);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('✅ Đã gửi báo cáo!'),
                          backgroundColor: AppColors.success),
                    );
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _confirmLogout(BuildContext context, WidgetRef ref) {
    showDialog(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Đăng xuất'),
        content: const Text('Bạn có chắc muốn đăng xuất không?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('Huỷ')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.error, minimumSize: const Size(80, 40)),
            onPressed: () async {
              Navigator.pop(c);
              await ref.read(authViewModelProvider.notifier).logout();
              if (context.mounted) context.go(AppRoutes.login);
            },
            child: const Text('Đăng xuất'),
          ),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader(this.title);
  final String title;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(16, 20, 16, 6),
    child: Text(title,
        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700,
            color: AppColors.textSub, letterSpacing: 0.5)),
  );
}

class _SettingsTile extends StatelessWidget {
  const _SettingsTile({required this.icon, required this.title,
      this.subtitle, this.trailing, this.onTap});
  final IconData icon;
  final String title;
  final String? subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) => ListTile(
    onTap: onTap,
    leading: Container(
      width: 38, height: 38,
      decoration: BoxDecoration(
        color: AppColors.surfaceVariant, borderRadius: BorderRadius.circular(10)),
      child: Icon(icon, size: 20, color: AppColors.textSecondary),
    ),
    title: Text(title, style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 14)),
    subtitle: subtitle != null
        ? Text(subtitle!, style: const TextStyle(fontSize: 12, color: AppColors.textSub)) : null,
    trailing: trailing ?? (onTap != null
        ? const Icon(Icons.chevron_right, size: 18, color: AppColors.textSub) : null),
  );
}
