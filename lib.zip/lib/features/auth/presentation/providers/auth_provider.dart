import 'package:firebase_auth/firebase_auth.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

import '../../../../core/constants/app_enums.dart';
import '../../../../core/di/repository_providers.dart';
import '../../../../core/di/usecase_providers.dart';
import '../../domain/entities/user_entity.dart';
import 'auth_state.dart';

part 'auth_provider.g.dart';

// ── Stream cho GoRouter redirect ──────────────────────────────
@Riverpod(keepAlive: true)
Stream<UserEntity?> authStateStream(Ref ref) =>
    ref.read(authRepositoryProvider).watchAuthState();

// ── ViewModel ─────────────────────────────────────────────────
@riverpod
class AuthViewModel extends _$AuthViewModel {
  @override
  AuthState build() => const AuthState.initial();

  Future<void> login(String email, String password) async {
    state = const AuthState.loading();
    try {
      final user = await ref.read(loginUseCaseProvider).call(
            email: email.trim(),
            password: password,
          );
      state = AuthState.authenticated(user);
    } on FirebaseAuthException catch (e) {
      state = AuthState.error(_mapFirebaseError(e.code));
    } catch (e) {
      state = AuthState.error(e.toString());
    }
  }

  Future<void> register({
    required String email,
    required String password,
    required String displayName,
    required UserRole role,
  }) async {
    state = const AuthState.loading();
    try {
      final user = await ref.read(registerUseCaseProvider).call(
            email: email.trim(),
            password: password,
            displayName: displayName,
            role: role,
          );
      state = AuthState.authenticated(user);
    } on FirebaseAuthException catch (e) {
      state = AuthState.error(_mapFirebaseError(e.code));
    } catch (e) {
      state = AuthState.error(e.toString());
    }
  }

  Future<void> logout() async {
    await ref.read(logoutUseCaseProvider).call();
    state = const AuthState.unauthenticated();
  }

  void resetError() {
    if (state is AuthError) state = const AuthState.initial();
  }

  String _mapFirebaseError(String code) => switch (code) {
        'user-not-found'         => 'Email không tồn tại',
        'wrong-password'         => 'Mật khẩu không đúng',
        'invalid-credential'     => 'Email hoặc mật khẩu không đúng',
        'email-already-in-use'   => 'Email đã được sử dụng',
        'weak-password'          => 'Mật khẩu quá yếu (tối thiểu 6 ký tự)',
        'invalid-email'          => 'Email không hợp lệ',
        'network-request-failed' => 'Lỗi kết nối mạng',
        _                        => 'Lỗi: $code',
      };
}
