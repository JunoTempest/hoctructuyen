import 'package:flutter/material.dart';
import '../../../../app/theme/app_theme.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: AppColors.primary,
        body: const Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.school_rounded, size: 80, color: Colors.white),
              SizedBox(height: 16),
              Text('EduApp',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 32,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1)),
              SizedBox(height: 32),
              CircularProgressIndicator(color: Colors.white54),
            ],
          ),
        ),
      );
}
