import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../../core/constants/app_enums.dart';
import '../../domain/entities/user_entity.dart';

class UserModel {
  const UserModel({
    required this.id,
    required this.email,
    required this.displayName,
    required this.role,
    required this.createdAt,
    this.photoUrl,
    this.bio,
    this.subjects,
    this.rating,
    this.totalSessions,
    this.isActive = true,
  });

  final String id;
  final String email;
  final String displayName;
  final String role;
  final DateTime createdAt;
  final String? photoUrl;
  final String? bio;
  final List<String>? subjects;
  final double? rating;
  final int? totalSessions;
  final bool isActive;

  factory UserModel.fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data()!;
    return UserModel(
      id:            doc.id,
      email:         d['email'] as String,
      displayName:   d['displayName'] as String,
      role:          d['role'] as String? ?? 'student',
      createdAt:     (d['createdAt'] as Timestamp).toDate(),
      photoUrl:      d['photoUrl'] as String?,
      bio:           d['bio'] as String?,
      subjects:      (d['subjects'] as List<dynamic>?)?.cast<String>(),
      rating:        (d['rating'] as num?)?.toDouble(),
      totalSessions: d['totalSessions'] as int?,
      isActive:      d['isActive'] as bool? ?? true,
    );
  }

  Map<String, dynamic> toFirestore() => {
        'email':         email,
        'displayName':   displayName,
        'role':          role,
        'createdAt':     Timestamp.fromDate(createdAt),
        'photoUrl':      photoUrl,
        'bio':           bio,
        'subjects':      subjects,
        'rating':        rating,
        'totalSessions': totalSessions,
        'isActive':      isActive,
      };

  UserEntity toEntity() => UserEntity(
        id:            id,
        email:         email,
        displayName:   displayName,
        role:          UserRoleX.fromString(role),
        createdAt:     createdAt,
        photoUrl:      photoUrl,
        bio:           bio,
        subjects:      subjects,
        rating:        rating,
        totalSessions: totalSessions,
        isActive:      isActive,
      );
}
