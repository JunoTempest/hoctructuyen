import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../../../../core/constants/app_enums.dart';
import '../../../../core/constants/firestore_paths.dart';
import '../../domain/entities/user_entity.dart';
import '../../domain/repositories/auth_repository.dart';
import '../models/user_model.dart';

class AuthRepositoryImpl implements AuthRepository {
  AuthRepositoryImpl({
    required FirebaseAuth firebaseAuth,
    required FirebaseFirestore firestore,
  })  : _auth = firebaseAuth,
        _db = firestore;

  final FirebaseAuth _auth;
  final FirebaseFirestore _db;

  @override
  Stream<UserEntity?> watchAuthState() {
    return _auth.authStateChanges().asyncMap((firebaseUser) async {
      if (firebaseUser == null) return null;
      return _fetchUser(firebaseUser.uid);
    });
  }

  @override
  Future<UserEntity> login({
    required String email,
    required String password,
  }) async {
    final cred = await _auth.signInWithEmailAndPassword(
        email: email, password: password);
    return _fetchUser(cred.user!.uid);
  }

  @override
  Future<UserEntity> register({
    required String email,
    required String password,
    required String displayName,
    required UserRole role,
  }) async {
    final cred = await _auth.createUserWithEmailAndPassword(
        email: email, password: password);
    final uid = cred.user!.uid;

    final model = UserModel(
      id:          uid,
      email:       email,
      displayName: displayName,
      role:        role.name,
      createdAt:   DateTime.now(),
      isActive:    true,
    );
    await _db.collection(FirestorePaths.users).doc(uid).set(model.toFirestore());
    return model.toEntity();
  }

  @override
  Future<void> logout() => _auth.signOut();

  @override
  Future<UserEntity?> getCurrentUser() async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return null;
    return _fetchUser(uid);
  }

  Future<UserEntity> _fetchUser(String uid) async {
    final doc = await _db.collection(FirestorePaths.users).doc(uid).get();
    if (!doc.exists) throw Exception('Không tìm thấy thông tin người dùng');
    return UserModel.fromFirestore(doc).toEntity();
  }
}
