import '../../../../core/constants/app_enums.dart';

class UserEntity {
  const UserEntity({
    required this.id,
    required this.email,
    required this.displayName,
    required this.role,
    required this.createdAt,
    this.photoUrl,
    this.bio,
    this.subjects,
    this.rating,
    this.totalSessions,
    this.isActive = true,
  });

  final String id;
  final String email;
  final String displayName;
  final UserRole role;
  final DateTime createdAt;
  final String? photoUrl;
  final String? bio;
  final List<String>? subjects; // Giáo viên: môn dạy
  final double? rating;
  final int? totalSessions;
  final bool isActive;

  bool get isTeacher => role == UserRole.teacher;
  bool get isStudent  => role == UserRole.student;
  bool get isAdmin    => role == UserRole.admin;

  String get initials {
    final parts = displayName.trim().split(' ');
    if (parts.length >= 2) {
      return '${parts.first[0]}${parts.last[0]}'.toUpperCase();
    }
    return displayName.isNotEmpty ? displayName[0].toUpperCase() : '?';
  }
}
