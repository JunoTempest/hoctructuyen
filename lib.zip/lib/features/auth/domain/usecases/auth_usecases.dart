import '../../../../core/constants/app_enums.dart';
import '../entities/user_entity.dart';
import '../repositories/auth_repository.dart';

class LoginUseCase {
  const LoginUseCase(this._repo);
  final AuthRepository _repo;

  Future<UserEntity> call({
    required String email,
    required String password,
  }) {
    if (email.trim().isEmpty) throw ArgumentError('Vui lòng nhập email');
    if (password.isEmpty)     throw ArgumentError('Vui lòng nhập mật khẩu');
    return _repo.login(email: email.trim(), password: password);
  }
}

class RegisterUseCase {
  const RegisterUseCase(this._repo);
  final AuthRepository _repo;

  Future<UserEntity> call({
    required String email,
    required String password,
    required String displayName,
    required UserRole role,
  }) {
    if (email.trim().isEmpty)       throw ArgumentError('Vui lòng nhập email');
    if (password.length < 6)        throw ArgumentError('Mật khẩu tối thiểu 6 ký tự');
    if (displayName.trim().isEmpty) throw ArgumentError('Vui lòng nhập họ tên');
    // Admin không được tự đăng ký
    if (role == UserRole.admin)     throw ArgumentError('Không thể tự đăng ký tài khoản Admin');
    return _repo.register(
      email: email.trim(),
      password: password,
      displayName: displayName.trim(),
      role: role,
    );
  }
}

class LogoutUseCase {
  const LogoutUseCase(this._repo);
  final AuthRepository _repo;
  Future<void> call() => _repo.logout();
}
