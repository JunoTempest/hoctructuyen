import '../../../../core/constants/app_enums.dart';
import '../entities/user_entity.dart';

abstract interface class AuthRepository {
  Stream<UserEntity?> watchAuthState();
  Future<UserEntity> login({required String email, required String password});
  Future<UserEntity> register({
    required String email,
    required String password,
    required String displayName,
    required UserRole role,
  });
  Future<void> logout();
  Future<UserEntity?> getCurrentUser();
}
