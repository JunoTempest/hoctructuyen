import '../../../../core/constants/app_enums.dart';

class ProfileEntity {
  const ProfileEntity({
    required this.userId,
    required this.displayName,
    required this.email,
    required this.role,
    this.photoUrl,
    this.bio,
    this.subjects,
    this.rating,
    this.totalSessions,
  });

  final String userId;
  final String displayName;
  final String email;
  final UserRole role;
  final String? photoUrl;
  final String? bio;
  final List<String>? subjects;
  final double? rating;
  final int? totalSessions;
}
