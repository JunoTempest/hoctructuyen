import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

import '../../../../core/constants/firestore_paths.dart';
import '../../../../core/di/firebase_providers.dart';
import '../../../auth/presentation/providers/auth_provider.dart';

part 'profile_provider.freezed.dart';
part 'profile_provider.g.dart';

// ── State ──────────────────────────────────────────────────────
@freezed
sealed class ProfileState with _$ProfileState {
  const factory ProfileState.idle()                   = ProfileIdle;
  const factory ProfileState.loading()                = ProfileLoading;
  const factory ProfileState.success(String message)  = ProfileSuccess;
  const factory ProfileState.error(String message)    = ProfileError;
}

// ── ViewModel ─────────────────────────────────────────────────
@riverpod
class ProfileViewModel extends _$ProfileViewModel {
  @override
  ProfileState build() => const ProfileState.idle();

  Future<void> updateProfile({
    required String displayName,
    String? bio,
    List<String>? subjects,
  }) async {
    // Riverpod 3.x: .value thay vì .valueOrNull
    final user = ref.read(authStateStreamProvider).value;
    if (user == null) return;
    state = const ProfileState.loading();
    try {
      final db = ref.read(firebaseFirestoreProvider);
      await db.collection(FirestorePaths.users).doc(user.id).update({
        'displayName': displayName.trim(),
        if (bio != null) 'bio': bio.trim(),
        if (subjects != null) 'subjects': subjects,
      });
      ref.invalidate(authStateStreamProvider);
      state = const ProfileState.success('Cập nhật thành công');
    } catch (e) {
      state = ProfileState.error(e.toString());
    }
  }

  void reset() => state = const ProfileState.idle();
}
