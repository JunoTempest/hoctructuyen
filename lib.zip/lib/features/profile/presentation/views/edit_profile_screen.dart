import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../app/theme/app_theme.dart';
import '../../../../core/constants/app_enums.dart';
import '../../../../core/utils/responsive.dart';
import '../../../auth/presentation/providers/auth_provider.dart';
import '../providers/profile_provider.dart';

class EditProfileScreen extends ConsumerStatefulWidget {
  const EditProfileScreen({super.key});

  @override
  ConsumerState<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends ConsumerState<EditProfileScreen> {
  final _nameCtrl    = TextEditingController();
  final _bioCtrl     = TextEditingController();
  final _phoneCtrl   = TextEditingController();
  final _subjectCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    final user = ref.read(authStateStreamProvider).value;
    if (user != null) {
      _nameCtrl.text    = user.displayName;
      _bioCtrl.text     = user.bio ?? '';
      _subjectCtrl.text = user.subjects?.join(', ') ?? '';
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _bioCtrl.dispose();
    _phoneCtrl.dispose();
    _subjectCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final user  = ref.watch(authStateStreamProvider).value;
    final state = ref.watch(profileViewModelProvider);

    ref.listen(profileViewModelProvider, (_, next) {
      switch (next) {
        case ProfileSuccess(:final message):
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(message), backgroundColor: AppColors.success));
          Navigator.pop(context);
        case ProfileError(:final message):
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(message), backgroundColor: AppColors.error));
        default: break;
      }
    });

    if (user == null) return const Scaffold(body: SizedBox());
    final isTeacher = user.isTeacher;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Chỉnh sửa hồ sơ'),
        actions: [
          TextButton(
            onPressed: _loading ? null : _save,
            child: _loading
                ? const SizedBox(width: 20, height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('Lưu', style: TextStyle(fontWeight: FontWeight.w700)),
          ),
        ],
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 600),
          child: SingleChildScrollView(
            padding: Responsive.pagePadding(context),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Avatar
                  Center(
                    child: Stack(
                      children: [
                        CircleAvatar(
                          radius: 52,
                          backgroundColor: user.role.color.withValues(alpha: 0.15),
                          backgroundImage: user.photoUrl != null
                              ? NetworkImage(user.photoUrl!) : null,
                          child: user.photoUrl == null
                              ? Text(user.initials,
                                  style: TextStyle(
                                    fontSize: 36, fontWeight: FontWeight.w800,
                                    color: user.role.color))
                              : null,
                        ),
                        Positioned(
                          right: 0, bottom: 0,
                          child: Container(
                            width: 34, height: 34,
                            decoration: BoxDecoration(
                              color: AppColors.primary,
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white, width: 2),
                            ),
                            child: const Icon(Icons.camera_alt,
                                color: Colors.white, size: 18),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 28),

                  // Basic info
                  _FieldLabel('Họ và tên *'),
                  TextFormField(
                    controller: _nameCtrl,
                    decoration: const InputDecoration(
                      prefixIcon: Icon(Icons.person_outline),
                      hintText: 'Nhập họ và tên',
                    ),
                    validator: (v) => v == null || v.isEmpty ? 'Vui lòng nhập tên' : null,
                  ),
                  const SizedBox(height: 16),

                  _FieldLabel('Email'),
                  TextFormField(
                    initialValue: user.email,
                    enabled: false,
                    decoration: const InputDecoration(
                      prefixIcon: Icon(Icons.email_outlined),
                    ),
                  ),
                  const SizedBox(height: 16),

                  _FieldLabel('Số điện thoại'),
                  TextFormField(
                    controller: _phoneCtrl,
                    keyboardType: TextInputType.phone,
                    decoration: const InputDecoration(
                      prefixIcon: Icon(Icons.phone_outlined),
                      hintText: 'Nhập số điện thoại (tuỳ chọn)',
                    ),
                  ),
                  const SizedBox(height: 16),

                  _FieldLabel(isTeacher ? 'Giới thiệu về phương pháp dạy học' : 'Giới thiệu bản thân'),
                  TextFormField(
                    controller: _bioCtrl,
                    maxLines: 4,
                    decoration: InputDecoration(
                      hintText: isTeacher
                          ? 'Mô tả phong cách dạy, kinh nghiệm...'
                          : 'Mục tiêu học tập, sở thích...',
                      alignLabelWithHint: true,
                    ),
                  ),

                  if (isTeacher) ...[
                    const SizedBox(height: 16),
                    _FieldLabel('Môn học giảng dạy'),
                    TextFormField(
                      controller: _subjectCtrl,
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.subject),
                        hintText: 'Ví dụ: Toán, Lý, Anh văn (cách nhau bởi dấu phẩy)',
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Nhập các môn học cách nhau bởi dấu phẩy',
                      style: TextStyle(color: AppColors.textSub, fontSize: 12),
                    ),
                  ],

                  const SizedBox(height: 32),
                  ElevatedButton(
                    onPressed: _loading ? null : _save,
                    child: _loading
                        ? const SizedBox(width: 20, height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                        : const Text('Lưu thay đổi'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      final subjects = _subjectCtrl.text.trim().isEmpty
          ? null
          : _subjectCtrl.text.split(',').map((s) => s.trim()).where((s) => s.isNotEmpty).toList();

      await ref.read(profileViewModelProvider.notifier).updateProfile(
        displayName: _nameCtrl.text.trim(),
        bio: _bioCtrl.text.trim().isEmpty ? null : _bioCtrl.text.trim(),
        subjects: subjects,
      );
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }
}

class _FieldLabel extends StatelessWidget {
  const _FieldLabel(this.text);
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Text(text,
        style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: AppColors.textSecondary)),
  );
}
