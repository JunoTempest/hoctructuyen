import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../app/router/app_router.dart';
import '../../../../app/theme/app_theme.dart';
import '../../../../app/theme/theme_provider.dart';
import '../../../../core/constants/app_enums.dart';
import '../../../../core/utils/responsive.dart';
import '../../../auth/domain/entities/user_entity.dart';
import '../../../auth/presentation/providers/auth_provider.dart';
import '../providers/profile_provider.dart';
import 'edit_profile_screen.dart';

// Helper tránh dùng extension trên dynamic
Color _roleColor(UserRole role) {
  switch (role) {
    case UserRole.teacher: return const Color(0xFF0891B2);
    case UserRole.admin:   return const Color(0xFF7C3AED);
    case UserRole.student: return const Color(0xFF16A34A);
  }
}
String _roleLabel(UserRole role) {
  switch (role) {
    case UserRole.teacher: return 'Giáo viên';
    case UserRole.admin:   return 'Quản trị viên';
    case UserRole.student: return 'Học sinh';
  }
}

class ProfileScreen extends ConsumerStatefulWidget {
  const ProfileScreen({super.key});

  @override
  ConsumerState<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends ConsumerState<ProfileScreen> {
  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authStateStreamProvider).value;
    if (user == null) return const Scaffold(body: SizedBox());

    return Scaffold(
      appBar: AppBar(title: const Text('Cài đặt & Hồ sơ')),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 700),
          child: ListView(
            padding: Responsive.pagePadding(context),
            children: [
              _ProfileCard(user: user),
              const SizedBox(height: 24),

              _SectionHeader(title: 'Giao diện'),
              _ThemeTile(),
              const Divider(height: 1),

              const SizedBox(height: 16),
              _SectionHeader(title: 'Tài khoản'),
              _SettingsTile(
                icon: Icons.person_outline,
                title: 'Chỉnh sửa hồ sơ',
                onTap: () => _showEditProfile(context),
              ),
              const Divider(height: 1),
              _SettingsTile(
                icon: Icons.lock_outline,
                title: 'Đổi mật khẩu',
                onTap: () => _showChangePassword(context),
              ),
              const Divider(height: 1),
              _SettingsTile(
                icon: Icons.notifications_outlined,
                title: 'Thông báo',
                onTap: () {},
              ),

              const SizedBox(height: 16),
              _SectionHeader(title: 'Hỗ trợ'),
              _SettingsTile(
                icon: Icons.bug_report_outlined,
                title: 'Báo cáo lỗi',
                subtitle: 'Gửi phản hồi tới quản trị viên',
                onTap: () => _showBugReport(context, ref),
              ),
              const Divider(height: 1),
              _SettingsTile(
                icon: Icons.info_outline,
                title: 'Phiên bản ứng dụng',
                trailing: const Text('1.0.0', style: TextStyle(color: AppColors.textSub)),
              ),

              const SizedBox(height: 32),
              OutlinedButton.icon(
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.error,
                  side: const BorderSide(color: AppColors.error),
                  minimumSize: const Size(double.infinity, 50),
                ),
                onPressed: () => _confirmLogout(context, ref),
                icon: const Icon(Icons.logout),
                label: const Text('Đăng xuất'),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  void _showEditProfile(BuildContext ctx) {
    Navigator.push(ctx, MaterialPageRoute(builder: (_) => const EditProfileScreen()));
  }

  void _showChangePassword(BuildContext ctx) {
    showDialog(context: ctx, builder: (_) => const _ChangePasswordDialog());
  }

  void _showBugReport(BuildContext ctx, WidgetRef ref) {
    showDialog(context: ctx, builder: (_) => _BugReportDialog(ref: ref));
  }

  void _confirmLogout(BuildContext ctx, WidgetRef ref) {
    showDialog(
      context: ctx,
      builder: (dCtx) => AlertDialog(
        title: const Text('Đăng xuất'),
        content: const Text('Bạn có chắc muốn đăng xuất?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dCtx), child: const Text('Huỷ')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                minimumSize: const Size(80, 40), backgroundColor: AppColors.error),
            onPressed: () async {
              Navigator.pop(dCtx);
              await ref.read(authViewModelProvider.notifier).logout();
              if (ctx.mounted) ctx.go(AppRoutes.login);
            },
            child: const Text('Đăng xuất'),
          ),
        ],
      ),
    );
  }
}

// ── Profile Card – dùng UserEntity thay vì dynamic ────────────
class _ProfileCard extends StatelessWidget {
  const _ProfileCard({required this.user});
  final UserEntity user; // ← TYPED, không phải dynamic

  @override
  Widget build(BuildContext context) {
    final color = _roleColor(user.role);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Row(
          children: [
            Stack(
              children: [
                CircleAvatar(
                  radius: 40,
                  backgroundColor: color.withValues(alpha: 0.15),
                  backgroundImage: user.photoUrl != null
                      ? NetworkImage(user.photoUrl!) : null,
                  child: user.photoUrl == null
                      ? Text(user.initials,
                          style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: color))
                      : null,
                ),
                Positioned(
                  right: 0, bottom: 0,
                  child: Container(
                    width: 28, height: 28,
                    decoration: BoxDecoration(
                      color: AppColors.primary, shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 2),
                    ),
                    child: const Icon(Icons.camera_alt, color: Colors.white, size: 14),
                  ),
                ),
              ],
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(user.displayName, style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 4),
                  Text(user.email,
                      style: const TextStyle(color: AppColors.textSub, fontSize: 13)),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: color.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(_roleLabel(user.role),
                        style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600)),
                  ),
                  if (user.bio != null && user.bio!.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(user.bio!,
                        style: const TextStyle(color: AppColors.textSecondary, fontSize: 13),
                        maxLines: 2, overflow: TextOverflow.ellipsis),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Theme tile ────────────────────────────────────────────────
class _ThemeTile extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final mode = ref.watch(appThemeModeProvider);
    return ListTile(
      leading: Icon(mode == ThemeMode.dark ? Icons.dark_mode : Icons.light_mode),
      title: const Text('Chế độ giao diện'),
      trailing: SegmentedButton<ThemeMode>(
        style: const ButtonStyle(visualDensity: VisualDensity(horizontal: -3, vertical: -2)),
        segments: const [
          ButtonSegment(value: ThemeMode.light,  icon: Icon(Icons.light_mode, size: 16)),
          ButtonSegment(value: ThemeMode.system, icon: Icon(Icons.brightness_auto, size: 16)),
          ButtonSegment(value: ThemeMode.dark,   icon: Icon(Icons.dark_mode, size: 16)),
        ],
        selected: {mode},
        onSelectionChanged: (val) => ref.read(appThemeModeProvider.notifier).set(val.first),
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader({required this.title});
  final String title;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 8, top: 4),
    child: Text(title,
        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700,
            color: AppColors.textSub, letterSpacing: 0.8)),
  );
}

class _SettingsTile extends StatelessWidget {
  const _SettingsTile({required this.icon, required this.title,
      this.subtitle, this.trailing, this.onTap});
  final IconData icon;
  final String title;
  final String? subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) => ListTile(
    leading: Icon(icon, color: AppColors.textSecondary),
    title: Text(title),
    subtitle: subtitle != null ? Text(subtitle!, style: const TextStyle(fontSize: 12)) : null,
    trailing: trailing ?? (onTap != null
        ? const Icon(Icons.chevron_right, color: AppColors.textSub) : null),
    onTap: onTap,
    contentPadding: const EdgeInsets.symmetric(horizontal: 4),
  );
}

class _ChangePasswordDialog extends StatefulWidget {
  const _ChangePasswordDialog();
  @override
  State<_ChangePasswordDialog> createState() => _ChangePasswordDialogState();
}
class _ChangePasswordDialogState extends State<_ChangePasswordDialog> {
  final _ctrl = TextEditingController();
  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('Đổi mật khẩu'),
    content: TextField(controller: _ctrl, obscureText: true,
        decoration: const InputDecoration(labelText: 'Mật khẩu mới (tối thiểu 6 ký tự)')),
    actions: [
      TextButton(onPressed: () => Navigator.pop(context), child: const Text('Huỷ')),
      ElevatedButton(
        style: ElevatedButton.styleFrom(minimumSize: const Size(80, 40)),
        onPressed: () => Navigator.pop(context),
        child: const Text('Lưu'),
      ),
    ],
  );
}

class _BugReportDialog extends StatefulWidget {
  const _BugReportDialog({required this.ref});
  final WidgetRef ref;
  @override
  State<_BugReportDialog> createState() => _BugReportDialogState();
}
class _BugReportDialogState extends State<_BugReportDialog> {
  final _ctrl = TextEditingController();
  bool _sent = false;
  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Row(children: [
      Icon(Icons.bug_report, color: AppColors.error), SizedBox(width: 8), Text('Báo cáo lỗi'),
    ]),
    content: _sent
        ? const Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.check_circle, color: AppColors.success, size: 48),
            SizedBox(height: 12),
            Text('Báo cáo đã được gửi!\nCảm ơn bạn.', textAlign: TextAlign.center),
          ])
        : TextField(controller: _ctrl, maxLines: 5,
            decoration: const InputDecoration(labelText: 'Mô tả vấn đề...', alignLabelWithHint: true)),
    actions: _sent
        ? [ElevatedButton(
            style: ElevatedButton.styleFrom(minimumSize: const Size(80, 40)),
            onPressed: () => Navigator.pop(context), child: const Text('Đóng'))]
        : [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Huỷ')),
            ElevatedButton(
              style: ElevatedButton.styleFrom(minimumSize: const Size(80, 40)),
              onPressed: () { if (_ctrl.text.trim().isNotEmpty) setState(() => _sent = true); },
              child: const Text('Gửi'),
            ),
          ],
  );
}
