import '../entities/message_entity.dart';

abstract interface class ChatRepository {
  Stream<List<ChatEntity>> watchMyChats(String userId);
  Stream<List<MessageEntity>> watchMessages(String chatId);
  Future<ChatEntity> getOrCreateChat({
    required String teacherId,
    required String studentId,
    String? teacherName,
    String? studentName,
    String? sessionId,
  });
  Future<MessageEntity> sendMessage({
    required String chatId,
    required String senderId,
    required String content,
    String? senderName,
  });
  Future<void> markAsRead(String chatId, String userId);
}
