import '../../../../core/constants/app_enums.dart';

class MessageEntity {
  const MessageEntity({
    required this.messageId,
    required this.chatId,
    required this.senderId,
    required this.content,
    required this.type,
    required this.createdAt,
    this.senderName,
    this.isRead = false,
  });

  final String messageId;
  final String chatId;
  final String senderId;
  final String content;
  final MessageType type;
  final DateTime createdAt;
  final String? senderName;
  final bool isRead;

  bool get isText   => type == MessageType.text;
  bool get isSystem => type == MessageType.system;
}

class ChatEntity {
  const ChatEntity({
    required this.chatId,
    required this.teacherId,
    required this.studentId,
    required this.createdAt,
    this.teacherName,
    this.studentName,
    this.lastMessage,
    this.lastMessageAt,
    this.unreadCount = 0,
    this.sessionId,
  });

  final String chatId;
  final String teacherId;
  final String studentId;
  final DateTime createdAt;
  final String? teacherName;
  final String? studentName;
  final String? lastMessage;
  final DateTime? lastMessageAt;
  final int unreadCount;
  final String? sessionId;

  String otherName(String myId) =>
      myId == teacherId ? (studentName ?? 'Học sinh') : (teacherName ?? 'Giáo viên');
}
