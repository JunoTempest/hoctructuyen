import '../entities/message_entity.dart';
import '../repositories/chat_repository.dart';

class WatchMyChatsUseCase {
  const WatchMyChatsUseCase(this._repo);
  final ChatRepository _repo;
  Stream<List<ChatEntity>> call(String userId) => _repo.watchMyChats(userId);
}

class WatchMessagesUseCase {
  const WatchMessagesUseCase(this._repo);
  final ChatRepository _repo;
  Stream<List<MessageEntity>> call(String chatId) =>
      _repo.watchMessages(chatId);
}

class SendMessageUseCase {
  const SendMessageUseCase(this._repo);
  final ChatRepository _repo;

  Future<MessageEntity> call({
    required String chatId,
    required String senderId,
    required String content,
    String? senderName,
  }) {
    if (content.trim().isEmpty) throw ArgumentError('Tin nhắn không được trống');
    return _repo.sendMessage(
      chatId: chatId,
      senderId: senderId,
      content: content.trim(),
      senderName: senderName,
    );
  }
}

class GetOrCreateChatUseCase {
  const GetOrCreateChatUseCase(this._repo);
  final ChatRepository _repo;

  Future<ChatEntity> call({
    required String teacherId,
    required String studentId,
    String? teacherName,
    String? studentName,
    String? sessionId,
  }) =>
      _repo.getOrCreateChat(
        teacherId: teacherId,
        studentId: studentId,
        teacherName: teacherName,
        studentName: studentName,
        sessionId: sessionId,
      );
}
