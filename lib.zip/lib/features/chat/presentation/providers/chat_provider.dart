import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

import '../../../../core/di/firebase_providers.dart';
import '../../../auth/presentation/providers/auth_provider.dart';
import '../../data/repositories/chat_repository_impl.dart';
import '../../domain/entities/message_entity.dart';
import '../../domain/repositories/chat_repository.dart';
import '../../domain/usecases/chat_usecases.dart';

part 'chat_provider.freezed.dart';
part 'chat_provider.g.dart';

@Riverpod(keepAlive: true)
ChatRepository chatRepository(Ref ref) =>
    ChatRepositoryImpl(ref.read(firebaseFirestoreProvider));

@riverpod
WatchMyChatsUseCase watchMyChatsUseCase(Ref ref) =>
    WatchMyChatsUseCase(ref.read(chatRepositoryProvider));

@riverpod
WatchMessagesUseCase watchMessagesUseCase(Ref ref) =>
    WatchMessagesUseCase(ref.read(chatRepositoryProvider));

@riverpod
SendMessageUseCase sendMessageUseCase(Ref ref) =>
    SendMessageUseCase(ref.read(chatRepositoryProvider));

@riverpod
GetOrCreateChatUseCase getOrCreateChatUseCase(Ref ref) =>
    GetOrCreateChatUseCase(ref.read(chatRepositoryProvider));

// ── Streams ───────────────────────────────────────────────────
@riverpod
Stream<List<ChatEntity>> myChats(Ref ref) {
  final user = ref.watch(authStateStreamProvider).value;
  if (user == null) return const Stream.empty();
  return ref.watch(chatRepositoryProvider).watchMyChats(user.id);
}

@riverpod
Stream<List<MessageEntity>> chatMessages(Ref ref, String chatId) =>
    ref.watch(chatRepositoryProvider).watchMessages(chatId);

// ── State ──────────────────────────────────────────────────────
@freezed
sealed class ChatActionState with _$ChatActionState {
  const factory ChatActionState.idle()                 = ChatIdle;
  const factory ChatActionState.loading()              = ChatLoading;
  const factory ChatActionState.success()              = ChatSuccess;
  const factory ChatActionState.error(String message)  = ChatError;
}

// ── ViewModel ─────────────────────────────────────────────────
@riverpod
class ChatViewModel extends _$ChatViewModel {
  @override
  ChatActionState build() => const ChatActionState.idle();

  Future<void> sendMessage({
    required String chatId,
    required String content,
  }) async {
    final user = ref.read(authStateStreamProvider).value;
    if (user == null) return;
    state = const ChatActionState.loading();
    try {
      await ref.read(sendMessageUseCaseProvider).call(
            chatId: chatId,
            senderId: user.id,
            content: content,
            senderName: user.displayName,
          );
      state = const ChatActionState.success();
    } catch (e) {
      state = ChatActionState.error(e.toString());
    }
  }

  Future<String?> getOrCreateChat({
    required String teacherId,
    required String studentId,
    String? teacherName,
    String? studentName,
  }) async {
    try {
      final chat = await ref.read(getOrCreateChatUseCaseProvider).call(
            teacherId: teacherId,
            studentId: studentId,
            teacherName: teacherName,
            studentName: studentName,
          );
      return chat.chatId;
    } catch (e) {
      state = ChatActionState.error(e.toString());
      return null;
    }
  }

  void reset() => state = const ChatActionState.idle();
}
