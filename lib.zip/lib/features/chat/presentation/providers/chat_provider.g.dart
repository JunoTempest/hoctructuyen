// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'chat_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(chatRepository)
const chatRepositoryProvider = ChatRepositoryProvider._();

final class ChatRepositoryProvider
    extends $FunctionalProvider<ChatRepository, ChatRepository, ChatRepository>
    with $Provider<ChatRepository> {
  const ChatRepositoryProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'chatRepositoryProvider',
          isAutoDispose: false,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$chatRepositoryHash();

  @$internal
  @override
  $ProviderElement<ChatRepository> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  ChatRepository create(Ref ref) {
    return chatRepository(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ChatRepository value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ChatRepository>(value),
    );
  }
}

String _$chatRepositoryHash() => r'64677c7ad9bb3a8b42d6fe4588fe040df909488f';

@ProviderFor(watchMyChatsUseCase)
const watchMyChatsUseCaseProvider = WatchMyChatsUseCaseProvider._();

final class WatchMyChatsUseCaseProvider extends $FunctionalProvider<
    WatchMyChatsUseCase,
    WatchMyChatsUseCase,
    WatchMyChatsUseCase> with $Provider<WatchMyChatsUseCase> {
  const WatchMyChatsUseCaseProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'watchMyChatsUseCaseProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$watchMyChatsUseCaseHash();

  @$internal
  @override
  $ProviderElement<WatchMyChatsUseCase> $createElement(
          $ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  WatchMyChatsUseCase create(Ref ref) {
    return watchMyChatsUseCase(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(WatchMyChatsUseCase value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<WatchMyChatsUseCase>(value),
    );
  }
}

String _$watchMyChatsUseCaseHash() =>
    r'0bab9b68e22368a071698bf401e038e3e08b8dc8';

@ProviderFor(watchMessagesUseCase)
const watchMessagesUseCaseProvider = WatchMessagesUseCaseProvider._();

final class WatchMessagesUseCaseProvider extends $FunctionalProvider<
    WatchMessagesUseCase,
    WatchMessagesUseCase,
    WatchMessagesUseCase> with $Provider<WatchMessagesUseCase> {
  const WatchMessagesUseCaseProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'watchMessagesUseCaseProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$watchMessagesUseCaseHash();

  @$internal
  @override
  $ProviderElement<WatchMessagesUseCase> $createElement(
          $ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  WatchMessagesUseCase create(Ref ref) {
    return watchMessagesUseCase(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(WatchMessagesUseCase value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<WatchMessagesUseCase>(value),
    );
  }
}

String _$watchMessagesUseCaseHash() =>
    r'2fd91a488531a73a2c9ff7056225699da647f7e4';

@ProviderFor(sendMessageUseCase)
const sendMessageUseCaseProvider = SendMessageUseCaseProvider._();

final class SendMessageUseCaseProvider extends $FunctionalProvider<
    SendMessageUseCase,
    SendMessageUseCase,
    SendMessageUseCase> with $Provider<SendMessageUseCase> {
  const SendMessageUseCaseProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'sendMessageUseCaseProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$sendMessageUseCaseHash();

  @$internal
  @override
  $ProviderElement<SendMessageUseCase> $createElement(
          $ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  SendMessageUseCase create(Ref ref) {
    return sendMessageUseCase(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(SendMessageUseCase value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<SendMessageUseCase>(value),
    );
  }
}

String _$sendMessageUseCaseHash() =>
    r'86edc2abfe6a30b3511d4de204fc4707e26f61e2';

@ProviderFor(getOrCreateChatUseCase)
const getOrCreateChatUseCaseProvider = GetOrCreateChatUseCaseProvider._();

final class GetOrCreateChatUseCaseProvider extends $FunctionalProvider<
    GetOrCreateChatUseCase,
    GetOrCreateChatUseCase,
    GetOrCreateChatUseCase> with $Provider<GetOrCreateChatUseCase> {
  const GetOrCreateChatUseCaseProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'getOrCreateChatUseCaseProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$getOrCreateChatUseCaseHash();

  @$internal
  @override
  $ProviderElement<GetOrCreateChatUseCase> $createElement(
          $ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  GetOrCreateChatUseCase create(Ref ref) {
    return getOrCreateChatUseCase(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(GetOrCreateChatUseCase value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<GetOrCreateChatUseCase>(value),
    );
  }
}

String _$getOrCreateChatUseCaseHash() =>
    r'406ef2c356b4c94fe1565afd0cd7f7a0a2e44546';

@ProviderFor(myChats)
const myChatsProvider = MyChatsProvider._();

final class MyChatsProvider extends $FunctionalProvider<
        AsyncValue<List<ChatEntity>>,
        List<ChatEntity>,
        Stream<List<ChatEntity>>>
    with $FutureModifier<List<ChatEntity>>, $StreamProvider<List<ChatEntity>> {
  const MyChatsProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'myChatsProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$myChatsHash();

  @$internal
  @override
  $StreamProviderElement<List<ChatEntity>> $createElement(
          $ProviderPointer pointer) =>
      $StreamProviderElement(pointer);

  @override
  Stream<List<ChatEntity>> create(Ref ref) {
    return myChats(ref);
  }
}

String _$myChatsHash() => r'03b02f79562fabee85eb17540189c6f24089e667';

@ProviderFor(chatMessages)
const chatMessagesProvider = ChatMessagesFamily._();

final class ChatMessagesProvider extends $FunctionalProvider<
        AsyncValue<List<MessageEntity>>,
        List<MessageEntity>,
        Stream<List<MessageEntity>>>
    with
        $FutureModifier<List<MessageEntity>>,
        $StreamProvider<List<MessageEntity>> {
  const ChatMessagesProvider._(
      {required ChatMessagesFamily super.from, required String super.argument})
      : super(
          retry: null,
          name: r'chatMessagesProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$chatMessagesHash();

  @override
  String toString() {
    return r'chatMessagesProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $StreamProviderElement<List<MessageEntity>> $createElement(
          $ProviderPointer pointer) =>
      $StreamProviderElement(pointer);

  @override
  Stream<List<MessageEntity>> create(Ref ref) {
    final argument = this.argument as String;
    return chatMessages(
      ref,
      argument,
    );
  }

  @override
  bool operator ==(Object other) {
    return other is ChatMessagesProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$chatMessagesHash() => r'6c786a67eec5852d4a074abe181921e6381ce87c';

final class ChatMessagesFamily extends $Family
    with $FunctionalFamilyOverride<Stream<List<MessageEntity>>, String> {
  const ChatMessagesFamily._()
      : super(
          retry: null,
          name: r'chatMessagesProvider',
          dependencies: null,
          $allTransitiveDependencies: null,
          isAutoDispose: true,
        );

  ChatMessagesProvider call(
    String chatId,
  ) =>
      ChatMessagesProvider._(argument: chatId, from: this);

  @override
  String toString() => r'chatMessagesProvider';
}

@ProviderFor(ChatViewModel)
const chatViewModelProvider = ChatViewModelProvider._();

final class ChatViewModelProvider
    extends $NotifierProvider<ChatViewModel, ChatActionState> {
  const ChatViewModelProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'chatViewModelProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$chatViewModelHash();

  @$internal
  @override
  ChatViewModel create() => ChatViewModel();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ChatActionState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ChatActionState>(value),
    );
  }
}

String _$chatViewModelHash() => r'36a8a115186ef91884f259da9c2889af4a0060a1';

abstract class _$ChatViewModel extends $Notifier<ChatActionState> {
  ChatActionState build();
  @$mustCallSuper
  @override
  void runBuild() {
    final created = build();
    final ref = this.ref as $Ref<ChatActionState, ChatActionState>;
    final element = ref.element as $ClassProviderElement<
        AnyNotifier<ChatActionState, ChatActionState>,
        ChatActionState,
        Object?,
        Object?>;
    element.handleValue(ref, created);
  }
}
