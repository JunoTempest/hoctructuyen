// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'chat_provider.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$ChatActionState {
  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is ChatActionState);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  String toString() {
    return 'ChatActionState()';
  }
}

/// @nodoc
class $ChatActionStateCopyWith<$Res> {
  $ChatActionStateCopyWith(
      ChatActionState _, $Res Function(ChatActionState) __);
}

/// Adds pattern-matching-related methods to [ChatActionState].
extension ChatActionStatePatterns on ChatActionState {
  /// A variant of `map` that fallback to returning `orElse`.
  ///
  /// It is equivalent to doing:
  /// ```dart
  /// switch (sealedClass) {
  ///   case final Subclass value:
  ///     return ...;
  ///   case _:
  ///     return orElse();
  /// }
  /// ```

  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(ChatIdle value)? idle,
    TResult Function(ChatLoading value)? loading,
    TResult Function(ChatSuccess value)? success,
    TResult Function(ChatError value)? error,
    required TResult orElse(),
  }) {
    final _that = this;
    switch (_that) {
      case ChatIdle() when idle != null:
        return idle(_that);
      case ChatLoading() when loading != null:
        return loading(_that);
      case ChatSuccess() when success != null:
        return success(_that);
      case ChatError() when error != null:
        return error(_that);
      case _:
        return orElse();
    }
  }

  /// A `switch`-like method, using callbacks.
  ///
  /// Callbacks receives the raw object, upcasted.
  /// It is equivalent to doing:
  /// ```dart
  /// switch (sealedClass) {
  ///   case final Subclass value:
  ///     return ...;
  ///   case final Subclass2 value:
  ///     return ...;
  /// }
  /// ```

  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(ChatIdle value) idle,
    required TResult Function(ChatLoading value) loading,
    required TResult Function(ChatSuccess value) success,
    required TResult Function(ChatError value) error,
  }) {
    final _that = this;
    switch (_that) {
      case ChatIdle():
        return idle(_that);
      case ChatLoading():
        return loading(_that);
      case ChatSuccess():
        return success(_that);
      case ChatError():
        return error(_that);
    }
  }

  /// A variant of `map` that fallback to returning `null`.
  ///
  /// It is equivalent to doing:
  /// ```dart
  /// switch (sealedClass) {
  ///   case final Subclass value:
  ///     return ...;
  ///   case _:
  ///     return null;
  /// }
  /// ```

  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(ChatIdle value)? idle,
    TResult? Function(ChatLoading value)? loading,
    TResult? Function(ChatSuccess value)? success,
    TResult? Function(ChatError value)? error,
  }) {
    final _that = this;
    switch (_that) {
      case ChatIdle() when idle != null:
        return idle(_that);
      case ChatLoading() when loading != null:
        return loading(_that);
      case ChatSuccess() when success != null:
        return success(_that);
      case ChatError() when error != null:
        return error(_that);
      case _:
        return null;
    }
  }

  /// A variant of `when` that fallback to an `orElse` callback.
  ///
  /// It is equivalent to doing:
  /// ```dart
  /// switch (sealedClass) {
  ///   case Subclass(:final field):
  ///     return ...;
  ///   case _:
  ///     return orElse();
  /// }
  /// ```

  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? idle,
    TResult Function()? loading,
    TResult Function()? success,
    TResult Function(String message)? error,
    required TResult orElse(),
  }) {
    final _that = this;
    switch (_that) {
      case ChatIdle() when idle != null:
        return idle();
      case ChatLoading() when loading != null:
        return loading();
      case ChatSuccess() when success != null:
        return success();
      case ChatError() when error != null:
        return error(_that.message);
      case _:
        return orElse();
    }
  }

  /// A `switch`-like method, using callbacks.
  ///
  /// As opposed to `map`, this offers destructuring.
  /// It is equivalent to doing:
  /// ```dart
  /// switch (sealedClass) {
  ///   case Subclass(:final field):
  ///     return ...;
  ///   case Subclass2(:final field2):
  ///     return ...;
  /// }
  /// ```

  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() idle,
    required TResult Function() loading,
    required TResult Function() success,
    required TResult Function(String message) error,
  }) {
    final _that = this;
    switch (_that) {
      case ChatIdle():
        return idle();
      case ChatLoading():
        return loading();
      case ChatSuccess():
        return success();
      case ChatError():
        return error(_that.message);
    }
  }

  /// A variant of `when` that fallback to returning `null`
  ///
  /// It is equivalent to doing:
  /// ```dart
  /// switch (sealedClass) {
  ///   case Subclass(:final field):
  ///     return ...;
  ///   case _:
  ///     return null;
  /// }
  /// ```

  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? idle,
    TResult? Function()? loading,
    TResult? Function()? success,
    TResult? Function(String message)? error,
  }) {
    final _that = this;
    switch (_that) {
      case ChatIdle() when idle != null:
        return idle();
      case ChatLoading() when loading != null:
        return loading();
      case ChatSuccess() when success != null:
        return success();
      case ChatError() when error != null:
        return error(_that.message);
      case _:
        return null;
    }
  }
}

/// @nodoc

class ChatIdle implements ChatActionState {
  const ChatIdle();

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is ChatIdle);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  String toString() {
    return 'ChatActionState.idle()';
  }
}

/// @nodoc

class ChatLoading implements ChatActionState {
  const ChatLoading();

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is ChatLoading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  String toString() {
    return 'ChatActionState.loading()';
  }
}

/// @nodoc

class ChatSuccess implements ChatActionState {
  const ChatSuccess();

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is ChatSuccess);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  String toString() {
    return 'ChatActionState.success()';
  }
}

/// @nodoc

class ChatError implements ChatActionState {
  const ChatError(this.message);

  final String message;

  /// Create a copy of ChatActionState
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @pragma('vm:prefer-inline')
  $ChatErrorCopyWith<ChatError> get copyWith =>
      _$ChatErrorCopyWithImpl<ChatError>(this, _$identity);

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is ChatError &&
            (identical(other.message, message) || other.message == message));
  }

  @override
  int get hashCode => Object.hash(runtimeType, message);

  @override
  String toString() {
    return 'ChatActionState.error(message: $message)';
  }
}

/// @nodoc
abstract mixin class $ChatErrorCopyWith<$Res>
    implements $ChatActionStateCopyWith<$Res> {
  factory $ChatErrorCopyWith(ChatError value, $Res Function(ChatError) _then) =
      _$ChatErrorCopyWithImpl;
  @useResult
  $Res call({String message});
}

/// @nodoc
class _$ChatErrorCopyWithImpl<$Res> implements $ChatErrorCopyWith<$Res> {
  _$ChatErrorCopyWithImpl(this._self, this._then);

  final ChatError _self;
  final $Res Function(ChatError) _then;

  /// Create a copy of ChatActionState
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  $Res call({
    Object? message = null,
  }) {
    return _then(ChatError(
      null == message
          ? _self.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

// dart format on
