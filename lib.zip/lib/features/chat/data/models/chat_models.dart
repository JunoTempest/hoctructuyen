import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../../core/constants/app_enums.dart';
import '../../domain/entities/message_entity.dart';

class MessageModel {
  const MessageModel({
    required this.messageId,
    required this.chatId,
    required this.senderId,
    required this.content,
    required this.type,
    required this.createdAt,
    this.senderName,
    this.isRead = false,
  });

  final String messageId;
  final String chatId;
  final String senderId;
  final String content;
  final String type;
  final DateTime createdAt;
  final String? senderName;
  final bool isRead;

  factory MessageModel.fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data()!;
    return MessageModel(
      messageId:  doc.id,
      chatId:     d['chatId'] as String,
      senderId:   d['senderId'] as String,
      content:    d['content'] as String,
      type:       d['type'] as String? ?? 'text',
      createdAt:  (d['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      senderName: d['senderName'] as String?,
      isRead:     d['isRead'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toFirestore() => {
        'chatId':     chatId,
        'senderId':   senderId,
        'content':    content,
        'type':       type,
        'createdAt':  FieldValue.serverTimestamp(),
        'senderName': senderName,
        'isRead':     isRead,
      };

  MessageEntity toEntity() => MessageEntity(
        messageId:  messageId,
        chatId:     chatId,
        senderId:   senderId,
        content:    content,
        type:       MessageTypeX.fromString(type),
        createdAt:  createdAt,
        senderName: senderName,
        isRead:     isRead,
      );
}

class ChatModel {
  const ChatModel({
    required this.chatId,
    required this.teacherId,
    required this.studentId,
    required this.createdAt,
    this.teacherName,
    this.studentName,
    this.lastMessage,
    this.lastMessageAt,
    this.unreadCount = 0,
    this.sessionId,
  });

  final String chatId;
  final String teacherId;
  final String studentId;
  final DateTime createdAt;
  final String? teacherName;
  final String? studentName;
  final String? lastMessage;
  final DateTime? lastMessageAt;
  final int unreadCount;
  final String? sessionId;

  factory ChatModel.fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data()!;
    return ChatModel(
      chatId:        doc.id,
      teacherId:     d['teacherId'] as String,
      studentId:     d['studentId'] as String,
      createdAt:     (d['createdAt'] as Timestamp).toDate(),
      teacherName:   d['teacherName'] as String?,
      studentName:   d['studentName'] as String?,
      lastMessage:   d['lastMessage'] as String?,
      lastMessageAt: (d['lastMessageAt'] as Timestamp?)?.toDate(),
      unreadCount:   d['unreadCount'] as int? ?? 0,
      sessionId:     d['sessionId'] as String?,
    );
  }

  Map<String, dynamic> toFirestore() => {
        'teacherId':     teacherId,
        'studentId':     studentId,
        'createdAt':     Timestamp.fromDate(createdAt),
        'teacherName':   teacherName,
        'studentName':   studentName,
        'lastMessage':   lastMessage,
        'lastMessageAt': lastMessageAt != null ? Timestamp.fromDate(lastMessageAt!) : null,
        'unreadCount':   unreadCount,
        'sessionId':     sessionId,
      };

  ChatEntity toEntity() => ChatEntity(
        chatId:        chatId,
        teacherId:     teacherId,
        studentId:     studentId,
        createdAt:     createdAt,
        teacherName:   teacherName,
        studentName:   studentName,
        lastMessage:   lastMessage,
        lastMessageAt: lastMessageAt,
        unreadCount:   unreadCount,
        sessionId:     sessionId,
      );
}
