import 'package:cloud_firestore/cloud_firestore.dart';

import '../../../../core/constants/firestore_paths.dart';
import '../../domain/entities/message_entity.dart';
import '../../domain/repositories/chat_repository.dart';
import '../models/chat_models.dart';

class ChatRepositoryImpl implements ChatRepository {
  ChatRepositoryImpl(this._db);
  final FirebaseFirestore _db;

  @override
  Stream<List<ChatEntity>> watchMyChats(String userId) =>
      _db.collection(FirestorePaths.chats)
          .where(Filter.or(
            Filter('teacherId', isEqualTo: userId),
            Filter('studentId', isEqualTo: userId),
          ))
          .orderBy('lastMessageAt', descending: true)
          .snapshots()
          .map((s) => s.docs.map((d) => ChatModel.fromFirestore(d).toEntity()).toList());

  @override
  Stream<List<MessageEntity>> watchMessages(String chatId) =>
      _db.collection(FirestorePaths.chats)
          .doc(chatId)
          .collection(FirestorePaths.messages)
          .orderBy('createdAt')
          .snapshots()
          .map((s) => s.docs.map((d) => MessageModel.fromFirestore(d).toEntity()).toList());

  @override
  Future<ChatEntity> getOrCreateChat({
    required String teacherId,
    required String studentId,
    String? teacherName,
    String? studentName,
    String? sessionId,
  }) async {
    // Tìm chat đã tồn tại
    final existing = await _db.collection(FirestorePaths.chats)
        .where('teacherId', isEqualTo: teacherId)
        .where('studentId', isEqualTo: studentId)
        .limit(1)
        .get();
    if (existing.docs.isNotEmpty) {
      return ChatModel.fromFirestore(existing.docs.first).toEntity();
    }
    // Tạo mới
    final ref = _db.collection(FirestorePaths.chats).doc();
    final model = ChatModel(
      chatId:      ref.id,
      teacherId:   teacherId,
      studentId:   studentId,
      createdAt:   DateTime.now(),
      teacherName: teacherName,
      studentName: studentName,
      sessionId:   sessionId,
    );
    await ref.set(model.toFirestore());
    return model.toEntity();
  }

  @override
  Future<MessageEntity> sendMessage({
    required String chatId,
    required String senderId,
    required String content,
    String? senderName,
  }) async {
    final msgRef = _db.collection(FirestorePaths.chats)
        .doc(chatId)
        .collection(FirestorePaths.messages)
        .doc();
    final model = MessageModel(
      messageId:  msgRef.id,
      chatId:     chatId,
      senderId:   senderId,
      content:    content,
      type:       'text',
      createdAt:  DateTime.now(),
      senderName: senderName,
    );
    final batch = _db.batch();
    batch.set(msgRef, model.toFirestore());
    batch.update(_db.collection(FirestorePaths.chats).doc(chatId), {
      'lastMessage':   content,
      'lastMessageAt': FieldValue.serverTimestamp(),
    });
    await batch.commit();
    return model.toEntity();
  }

  @override
  Future<void> markAsRead(String chatId, String userId) =>
      _db.collection(FirestorePaths.chats).doc(chatId).update({'unreadCount': 0});
}
