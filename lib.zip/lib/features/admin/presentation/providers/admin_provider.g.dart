// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'admin_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(appStats)
const appStatsProvider = AppStatsProvider._();

final class AppStatsProvider extends $FunctionalProvider<
        AsyncValue<Map<String, int>>,
        Map<String, int>,
        FutureOr<Map<String, int>>>
    with $FutureModifier<Map<String, int>>, $FutureProvider<Map<String, int>> {
  const AppStatsProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'appStatsProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$appStatsHash();

  @$internal
  @override
  $FutureProviderElement<Map<String, int>> $createElement(
          $ProviderPointer pointer) =>
      $FutureProviderElement(pointer);

  @override
  FutureOr<Map<String, int>> create(Ref ref) {
    return appStats(ref);
  }
}

String _$appStatsHash() => r'f1912ad2855cb9a07406a5568645883171ced4fa';

@ProviderFor(allUsers)
const allUsersProvider = AllUsersProvider._();

final class AllUsersProvider extends $FunctionalProvider<
        AsyncValue<List<UserEntity>>,
        List<UserEntity>,
        FutureOr<List<UserEntity>>>
    with $FutureModifier<List<UserEntity>>, $FutureProvider<List<UserEntity>> {
  const AllUsersProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'allUsersProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$allUsersHash();

  @$internal
  @override
  $FutureProviderElement<List<UserEntity>> $createElement(
          $ProviderPointer pointer) =>
      $FutureProviderElement(pointer);

  @override
  FutureOr<List<UserEntity>> create(Ref ref) {
    return allUsers(ref);
  }
}

String _$allUsersHash() => r'27109739db6f5d050009cf3bade026eb286b010e';

@ProviderFor(pendingCourses)
const pendingCoursesProvider = PendingCoursesProvider._();

final class PendingCoursesProvider extends $FunctionalProvider<
        AsyncValue<List<Map<String, dynamic>>>,
        List<Map<String, dynamic>>,
        FutureOr<List<Map<String, dynamic>>>>
    with
        $FutureModifier<List<Map<String, dynamic>>>,
        $FutureProvider<List<Map<String, dynamic>>> {
  const PendingCoursesProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'pendingCoursesProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$pendingCoursesHash();

  @$internal
  @override
  $FutureProviderElement<List<Map<String, dynamic>>> $createElement(
          $ProviderPointer pointer) =>
      $FutureProviderElement(pointer);

  @override
  FutureOr<List<Map<String, dynamic>>> create(Ref ref) {
    return pendingCourses(ref);
  }
}

String _$pendingCoursesHash() => r'bc370a2e39650b215f31dd4a93336ded08afce4a';

@ProviderFor(bugReports)
const bugReportsProvider = BugReportsProvider._();

final class BugReportsProvider extends $FunctionalProvider<
        AsyncValue<List<Map<String, dynamic>>>,
        List<Map<String, dynamic>>,
        FutureOr<List<Map<String, dynamic>>>>
    with
        $FutureModifier<List<Map<String, dynamic>>>,
        $FutureProvider<List<Map<String, dynamic>>> {
  const BugReportsProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'bugReportsProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$bugReportsHash();

  @$internal
  @override
  $FutureProviderElement<List<Map<String, dynamic>>> $createElement(
          $ProviderPointer pointer) =>
      $FutureProviderElement(pointer);

  @override
  FutureOr<List<Map<String, dynamic>>> create(Ref ref) {
    return bugReports(ref);
  }
}

String _$bugReportsHash() => r'8d906de28b11eb5e40e06daa174c012ac7babcbb';

@ProviderFor(AdminViewModel)
const adminViewModelProvider = AdminViewModelProvider._();

final class AdminViewModelProvider
    extends $NotifierProvider<AdminViewModel, AsyncValue<void>> {
  const AdminViewModelProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'adminViewModelProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$adminViewModelHash();

  @$internal
  @override
  AdminViewModel create() => AdminViewModel();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AsyncValue<void> value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AsyncValue<void>>(value),
    );
  }
}

String _$adminViewModelHash() => r'5c225739859c4b2f6f60329d67dec666603d9700';

abstract class _$AdminViewModel extends $Notifier<AsyncValue<void>> {
  AsyncValue<void> build();
  @$mustCallSuper
  @override
  void runBuild() {
    final created = build();
    final ref = this.ref as $Ref<AsyncValue<void>, AsyncValue<void>>;
    final element = ref.element as $ClassProviderElement<
        AnyNotifier<AsyncValue<void>, AsyncValue<void>>,
        AsyncValue<void>,
        Object?,
        Object?>;
    element.handleValue(ref, created);
  }
}
