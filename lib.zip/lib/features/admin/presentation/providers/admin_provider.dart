import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

import '../../../../core/constants/firestore_paths.dart';
import '../../../../core/di/firebase_providers.dart';
import '../../../auth/domain/entities/user_entity.dart';
import '../../../auth/data/models/user_model.dart';

part 'admin_provider.g.dart';

// ── Stats ─────────────────────────────────────────────────────
@riverpod
Future<Map<String, int>> appStats(Ref ref) async {
  final db = ref.read(firebaseFirestoreProvider);
  final usersCount    = await db.collection(FirestorePaths.users).count().get();
  final coursesCount  = await db.collection(FirestorePaths.courses).count().get();
  final sessionsCount = await db.collection(FirestorePaths.sessions).count().get();
  final bookingsCount = await db.collection(FirestorePaths.bookings).count().get();
  return {
    'users':    usersCount.count    ?? 0,
    'courses':  coursesCount.count  ?? 0,
    'sessions': sessionsCount.count ?? 0,
    'bookings': bookingsCount.count ?? 0,
  };
}

// ── All users ─────────────────────────────────────────────────
@riverpod
Future<List<UserEntity>> allUsers(Ref ref) async {
  final db = ref.read(firebaseFirestoreProvider);
  final snap = await db.collection(FirestorePaths.users)
      .orderBy('createdAt', descending: true)
      .get();
  return snap.docs.map((d) => UserModel.fromFirestore(d).toEntity()).toList();
}

// ── Pending courses (chờ admin duyệt) ────────────────────────
@riverpod
Future<List<Map<String, dynamic>>> pendingCourses(Ref ref) async {
  final db = ref.read(firebaseFirestoreProvider);
  final snap = await db.collection(FirestorePaths.courses)
      .where('status', isEqualTo: 'pending')
      .orderBy('createdAt', descending: true)
      .get();
  return snap.docs.map((d) => {'id': d.id, ...d.data()}).toList();
}

// ── Bug reports ───────────────────────────────────────────────
@riverpod
Future<List<Map<String, dynamic>>> bugReports(Ref ref) async {
  final db = ref.read(firebaseFirestoreProvider);
  try {
    final snap = await db.collection('bug_reports')
        .where('resolved', isEqualTo: false)
        .orderBy('createdAt', descending: true)
        .get();
    return snap.docs.map((d) => {'id': d.id, ...d.data()}).toList();
  } catch (_) {
    return [];
  }
}

// ── ViewModel ─────────────────────────────────────────────────
@riverpod
class AdminViewModel extends _$AdminViewModel {
  @override
  AsyncValue<void> build() => const AsyncData(null);

  Future<void> approveCourse(String courseId) async {
    state = const AsyncLoading();
    try {
      final db = ref.read(firebaseFirestoreProvider);
      await db.collection(FirestorePaths.courses).doc(courseId).update({
        'status': 'open',
        'approvedAt': FieldValue.serverTimestamp(),
      });
      ref.invalidate(pendingCoursesProvider);
      state = const AsyncData(null);
    } catch (e, st) {
      state = AsyncError(e, st);
    }
  }

  Future<void> rejectCourse(String courseId) async {
    state = const AsyncLoading();
    try {
      final db = ref.read(firebaseFirestoreProvider);
      await db.collection(FirestorePaths.courses).doc(courseId).update({
        'status': 'rejected',
        'rejectedAt': FieldValue.serverTimestamp(),
      });
      ref.invalidate(pendingCoursesProvider);
      state = const AsyncData(null);
    } catch (e, st) {
      state = AsyncError(e, st);
    }
  }

  Future<void> toggleUserActive(String userId, bool isActive) async {
    try {
      final db = ref.read(firebaseFirestoreProvider);
      await db.collection(FirestorePaths.users).doc(userId).update({
        'isActive': isActive,
      });
      ref.invalidate(allUsersProvider);
    } catch (_) {}
  }

  Future<void> resolveBugReport(String reportId) async {
    try {
      final db = ref.read(firebaseFirestoreProvider);
      await db.collection('bug_reports').doc(reportId).update({
        'resolved': true,
        'resolvedAt': FieldValue.serverTimestamp(),
      });
      ref.invalidate(bugReportsProvider);
    } catch (_) {}
  }
}
