import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../../app/theme/app_theme.dart';
import '../../../../core/constants/app_enums.dart';
import '../../../../core/utils/responsive.dart';
import '../../../auth/domain/entities/user_entity.dart';
import '../providers/admin_provider.dart';

class AdminDashboardScreen extends ConsumerWidget {
  const AdminDashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Quản trị hệ thống'),
          bottom: const TabBar(
            isScrollable: true,
            tabAlignment: TabAlignment.start,
            tabs: [
              Tab(text: 'Tổng quan'),
              Tab(text: 'Khóa học chờ duyệt'),
              Tab(text: 'Người dùng'),
              Tab(text: 'Báo cáo lỗi'),
            ],
          ),
        ),
        body: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 1000),
            child: const TabBarView(
              children: [
                _OverviewTab(),
                _PendingCoursesTab(),
                _UsersTab(),
                _BugReportsTab(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ── Tab 1: Tổng quan ──────────────────────────────────────────
class _OverviewTab extends ConsumerWidget {
  const _OverviewTab();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final statsAsync = ref.watch(appStatsProvider);
    final isWide = MediaQuery.of(context).size.width >= 600;

    return RefreshIndicator(
      onRefresh: () async => ref.invalidate(appStatsProvider),
      child: ListView(
        padding: Responsive.pagePadding(context),
        children: [
          statsAsync.when(
            loading: () => const LinearProgressIndicator(),
            error: (e, _) => Text('Lỗi: $e'),
            data: (stats) => GridView.count(
              crossAxisCount: isWide ? 4 : 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.4,
              children: [
                _StatCard('Người dùng', stats['users'] ?? 0, Icons.people_outline, AppColors.primary),
                _StatCard('Khóa học', stats['courses'] ?? 0, Icons.menu_book_outlined, AppColors.success),
                _StatCard('Buổi học', stats['sessions'] ?? 0, Icons.video_call_outlined, AppColors.info),
                _StatCard('Đặt lịch', stats['bookings'] ?? 0, Icons.calendar_today_outlined, AppColors.warning),
              ],
            ),
          ),
          const SizedBox(height: 24),
          Text('Hoạt động gần đây', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 12),
          const _RecentActivity(),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard(this.label, this.count, this.icon, this.color);
  final String label;
  final int count;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('$count',
                  style: TextStyle(
                      fontSize: 22, fontWeight: FontWeight.w800, color: color)),
              Text(label,
                  style: const TextStyle(
                      fontSize: 11, color: AppColors.textSub)),
            ],
          ),
        ],
      ),
    ),
  );
}

class _RecentActivity extends ConsumerWidget {
  const _RecentActivity();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final usersAsync = ref.watch(allUsersProvider);
    return usersAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => Text('Lỗi: $e'),
      data: (users) {
        final recent = users.take(5).toList();
        return Column(
          children: recent.map((u) => ListTile(
            leading: CircleAvatar(
              backgroundColor: u.role.color.withValues(alpha: 0.12),
              child: Text(u.initials, style: TextStyle(
                  color: u.role.color, fontWeight: FontWeight.w700)),
            ),
            title: Text(u.displayName),
            subtitle: Text(u.email),
            trailing: _RoleChip(role: u.role),
            contentPadding: EdgeInsets.zero,
          )).toList(),
        );
      },
    );
  }
}

// ── Tab 2: Khóa học chờ duyệt ─────────────────────────────────
class _PendingCoursesTab extends ConsumerWidget {
  const _PendingCoursesTab();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final coursesAsync = ref.watch(pendingCoursesProvider);

    return RefreshIndicator(
      onRefresh: () async => ref.invalidate(pendingCoursesProvider),
      child: coursesAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Lỗi: $e')),
        data: (courses) {
          if (courses.isEmpty) {
            return const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.check_circle_outline,
                      size: 56, color: AppColors.success),
                  SizedBox(height: 16),
                  Text('Không có khóa học nào cần duyệt',
                      style: TextStyle(color: AppColors.textSub)),
                ],
              ),
            );
          }
          return ListView.builder(
            padding: Responsive.pagePadding(context),
            itemCount: courses.length,
            itemBuilder: (_, i) => _PendingCourseCard(course: courses[i]),
          );
        },
      ),
    );
  }
}

class _PendingCourseCard extends ConsumerWidget {
  const _PendingCourseCard({required this.course});
  final Map<String, dynamic> course;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 48, height: 48,
                  decoration: BoxDecoration(
                    color: AppColors.secondary.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.menu_book,
                      color: AppColors.secondary, size: 24),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(course['title'] ?? 'Khóa học',
                          style: const TextStyle(fontWeight: FontWeight.w700)),
                      Text('GV: ${course['teacherName'] ?? "Giáo viên"}',
                          style: const TextStyle(
                              fontSize: 13, color: AppColors.textSub)),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppColors.warning.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Text('Chờ duyệt',
                      style: TextStyle(
                          color: AppColors.warning,
                          fontSize: 11,
                          fontWeight: FontWeight.w600)),
                ),
              ],
            ),
            if (course['description'] != null) ...[
              const SizedBox(height: 10),
              Text(course['description'],
                  style: const TextStyle(
                      color: AppColors.textSecondary, fontSize: 13),
                  maxLines: 2, overflow: TextOverflow.ellipsis),
            ],
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size(0, 42),
                      foregroundColor: AppColors.error,
                      side: const BorderSide(color: AppColors.error),
                    ),
                    onPressed: () => ref
                        .read(adminViewModelProvider.notifier)
                        .rejectCourse(course['id']),
                    icon: const Icon(Icons.close, size: 16),
                    label: const Text('Từ chối'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                        minimumSize: const Size(0, 42)),
                    onPressed: () => ref
                        .read(adminViewModelProvider.notifier)
                        .approveCourse(course['id']),
                    icon: const Icon(Icons.check, size: 16),
                    label: const Text('Duyệt'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ── Tab 3: Người dùng ─────────────────────────────────────────
class _UsersTab extends ConsumerWidget {
  const _UsersTab();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final usersAsync = ref.watch(allUsersProvider);

    return RefreshIndicator(
      onRefresh: () async => ref.invalidate(allUsersProvider),
      child: usersAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Lỗi: $e')),
        data: (users) => ListView.builder(
          padding: Responsive.pagePadding(context),
          itemCount: users.length,
          itemBuilder: (_, i) => _UserAdminTile(user: users[i]),
        ),
      ),
    );
  }
}

class _UserAdminTile extends ConsumerWidget {
  const _UserAdminTile({required this.user});
  final UserEntity user;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final df = DateFormat('dd/MM/yyyy');
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: CircleAvatar(
          backgroundColor: user.role.color.withValues(alpha: 0.12),
          child: Text(user.initials,
              style: TextStyle(
                  color: user.role.color, fontWeight: FontWeight.w700)),
        ),
        title: Text(user.displayName,
            style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(user.email, style: const TextStyle(fontSize: 12)),
            Text('Tham gia: ${df.format(user.createdAt)}',
                style: const TextStyle(
                    fontSize: 11, color: AppColors.textSub)),
          ],
        ),
        isThreeLine: true,
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _RoleChip(role: user.role),
            const SizedBox(height: 4),
            Container(
              width: 8, height: 8,
              decoration: BoxDecoration(
                color: user.isActive ? AppColors.success : AppColors.textSub,
                shape: BoxShape.circle,
              ),
            ),
          ],
        ),
        onTap: () => _showUserDetail(context, ref, user),
      ),
    );
  }

  void _showUserDetail(BuildContext ctx, WidgetRef ref, UserEntity user) {
    showModalBottomSheet(
      context: ctx,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(user.displayName,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            Text(user.email, style: const TextStyle(color: AppColors.textSub)),
            const SizedBox(height: 16),
            if (user.bio != null && user.bio!.isNotEmpty)
              Text(user.bio!, style: const TextStyle(color: AppColors.textSecondary)),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size(0, 44),
                      foregroundColor: AppColors.error,
                      side: const BorderSide(color: AppColors.error),
                    ),
                    onPressed: () {
                      Navigator.pop(ctx);
                      ref.read(adminViewModelProvider.notifier)
                          .toggleUserActive(user.id, !user.isActive);
                    },
                    child: Text(user.isActive ? 'Vô hiệu hoá' : 'Kích hoạt'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ── Tab 4: Báo cáo lỗi ────────────────────────────────────────
class _BugReportsTab extends ConsumerWidget {
  const _BugReportsTab();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final reportsAsync = ref.watch(bugReportsProvider);

    return RefreshIndicator(
      onRefresh: () async => ref.invalidate(bugReportsProvider),
      child: reportsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Lỗi: $e')),
        data: (reports) {
          if (reports.isEmpty) {
            return const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.check_circle_outline,
                      size: 56, color: AppColors.success),
                  SizedBox(height: 16),
                  Text('Không có báo cáo lỗi nào',
                      style: TextStyle(color: AppColors.textSub)),
                ],
              ),
            );
          }
          return ListView.builder(
            padding: Responsive.pagePadding(context),
            itemCount: reports.length,
            itemBuilder: (_, i) {
              final r = reports[i];
              return Card(
                margin: const EdgeInsets.only(bottom: 8),
                child: ListTile(
                  leading: const Icon(Icons.bug_report,
                      color: AppColors.error),
                  title: Text(r['message'] ?? 'Lỗi không xác định'),
                  subtitle: Text('${r['userEmail'] ?? ""} · ${r['createdAt'] ?? ""}',
                      style: const TextStyle(fontSize: 12)),
                  trailing: IconButton(
                    icon: const Icon(Icons.check_circle_outline,
                        color: AppColors.success),
                    onPressed: () => ref
                        .read(adminViewModelProvider.notifier)
                        .resolveBugReport(r['id']),
                    tooltip: 'Đánh dấu đã xử lý',
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class _RoleChip extends StatelessWidget {
  const _RoleChip({required this.role});
  final UserRole role;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
    decoration: BoxDecoration(
      color: role.color.withValues(alpha: 0.1),
      borderRadius: BorderRadius.circular(20),
    ),
    child: Text(
      role == UserRole.teacher ? 'GV'
          : role == UserRole.admin ? 'Admin' : 'HS',
      style: TextStyle(
          color: role.color, fontSize: 10, fontWeight: FontWeight.w700),
    ),
  );
}
