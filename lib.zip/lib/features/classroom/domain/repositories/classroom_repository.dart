import '../entities/whiteboard_stroke_entity.dart';

abstract interface class ClassroomRepository {
  /// Lắng nghe các nét vẽ realtime từ Firestore
  Stream<List<WhiteboardStrokeEntity>> watchStrokes(String sessionId);

  /// Thêm một nét vẽ mới
  Future<void> addStroke(WhiteboardStrokeEntity stroke);

  /// Xoá toàn bộ bảng (chỉ giáo viên)
  Future<void> clearBoard(String sessionId);

  /// Cập nhật trạng thái session (ongoing / completed)
  Future<void> updateSessionStatus(String sessionId, String status);
}
