import '../entities/whiteboard_stroke_entity.dart';
import '../repositories/classroom_repository.dart';

class WatchStrokesUseCase {
  const WatchStrokesUseCase(this._repo);
  final ClassroomRepository _repo;

  Stream<List<WhiteboardStrokeEntity>> call(String sessionId) =>
      _repo.watchStrokes(sessionId);
}

class AddStrokeUseCase {
  const AddStrokeUseCase(this._repo);
  final ClassroomRepository _repo;

  Future<void> call(WhiteboardStrokeEntity stroke) => _repo.addStroke(stroke);
}

class ClearBoardUseCase {
  const ClearBoardUseCase(this._repo);
  final ClassroomRepository _repo;

  Future<void> call(String sessionId) => _repo.clearBoard(sessionId);
}

class UpdateSessionStatusUseCase {
  const UpdateSessionStatusUseCase(this._repo);
  final ClassroomRepository _repo;

  Future<void> call(String sessionId, String status) =>
      _repo.updateSessionStatus(sessionId, status);
}
