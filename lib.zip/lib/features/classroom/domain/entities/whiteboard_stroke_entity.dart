import 'package:flutter/material.dart';

/// Một nét vẽ trên bảng trắng
class WhiteboardStrokeEntity {
  const WhiteboardStrokeEntity({
    required this.strokeId,
    required this.sessionId,
    required this.authorId,
    required this.points,
    required this.color,
    required this.strokeWidth,
    required this.tool,
    required this.createdAt,
  });

  final String strokeId;
  final String sessionId;
  final String authorId;
  final List<Offset> points;
  final Color color;
  final double strokeWidth;
  final WhiteboardTool tool;
  final DateTime createdAt;

  bool get isEraser => tool == WhiteboardTool.eraser;
}

enum WhiteboardTool { pen, highlighter, eraser, laser }

extension WhiteboardToolX on WhiteboardTool {
  String get label => switch (this) {
        WhiteboardTool.pen         => 'Bút',
        WhiteboardTool.highlighter => 'Highlight',
        WhiteboardTool.eraser      => 'Tẩy',
        WhiteboardTool.laser       => 'Laser',
      };

  IconData get icon => switch (this) {
        WhiteboardTool.pen         => Icons.edit_outlined,
        WhiteboardTool.highlighter => Icons.highlight_outlined,
        WhiteboardTool.eraser      => Icons.auto_fix_normal_outlined,
        WhiteboardTool.laser       => Icons.lens_outlined,
      };
}
