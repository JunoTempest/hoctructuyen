// lib/features/classroom/presentation/widgets/video_tile_stub.dart
// Fallback cho các platform không phải web/mobile (desktop, test)

import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:flutter/material.dart';

class VideoTile extends StatelessWidget {
  const VideoTile({
    super.key,
    required this.uid,
    required this.engine,
    required this.isLocal,
    this.channelId,
    this.name,
    this.isMuted = false,
    this.isVideoMuted = false,
  });

  final int uid;
  final RtcEngine engine;
  final bool isLocal;
  final String? channelId;
  final String? name;
  final bool isMuted;
  final bool isVideoMuted;

  @override
  Widget build(BuildContext context) => Container(
        color: const Color(0xFF1e293b),
        child: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            CircleAvatar(
              radius: 20,
              backgroundColor: const Color(0xFF334155),
              child: Text(
                name?.isNotEmpty == true ? name![0].toUpperCase() : '?',
                style: const TextStyle(
                    fontSize: 18,
                    color: Colors.white70,
                    fontWeight: FontWeight.w700),
              ),
            ),
            if (name != null) ...[
              const SizedBox(height: 4),
              Text(name!,
                  style: const TextStyle(
                      color: Colors.white54, fontSize: 9)),
            ],
          ]),
        ),
      );
}
