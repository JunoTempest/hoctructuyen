import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter/material.dart';

import '../../domain/entities/whiteboard_stroke_entity.dart';
import '../providers/whiteboard_provider.dart';

class WhiteboardToolbar extends ConsumerWidget {
  const WhiteboardToolbar({
    super.key,
    required this.sessionId,
    required this.isTeacher,
    this.studentCanDraw    = false,
    this.onToggleStudentDraw,
  });

  final String sessionId;
  final bool isTeacher;
  final bool studentCanDraw;
  final VoidCallback? onToggleStudentDraw;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final vm       = ref.watch(whiteboardViewModelProvider);
    final notifier = ref.read(whiteboardViewModelProvider.notifier);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: const Color(0xFF1e293b),
        borderRadius: BorderRadius.circular(14),
        boxShadow: [BoxShadow(
            color: Colors.black.withOpacity(0.25),
            blurRadius: 8, offset: const Offset(0, 2))],
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [

        // ── Tools ─────────────────────────────────────
        ...WhiteboardTool.values.map((tool) => _ToolBtn(
          icon:       tool.icon,
          label:      tool.label,
          isSelected: vm.tool == tool,
          onTap:      () => notifier.setTool(tool),
        )),

        _Sep(),

        // ── Stroke width ──────────────────────────────
        _StrokeBtn(current: vm.strokeWidth, onChange: notifier.setStrokeWidth),

        _Sep(),

        // ── Colors (hidden when eraser) ───────────────
        if (vm.tool != WhiteboardTool.eraser) ...[
          ...kBoardColors.map((c) => _ColorDot(
            color: c, isSelected: vm.color == c,
            onTap: () => notifier.setColor(c),
          )),
          _Sep(),
        ],

        // ── Student draw permission (teacher only) ────
        if (isTeacher && onToggleStudentDraw != null)
          _PermBtn(
            studentCanDraw: studentCanDraw,
            onTap: onToggleStudentDraw!,
          ),

        // ── Clear board (teacher only) ────────────────
        if (isTeacher) ...[
          if (onToggleStudentDraw != null) _Sep(),
          _ToolBtn(
            icon: Icons.delete_sweep_outlined, label: 'Xoá hết',
            isSelected: false, danger: true,
            onTap: () => _confirmClear(context, ref),
          ),
        ],
      ]),
    );
  }

  void _confirmClear(BuildContext context, WidgetRef ref) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1e293b),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        title: const Text('Xoá bảng?',
            style: TextStyle(color: Colors.white, fontSize: 15)),
        content: const Text('Toàn bộ nét vẽ sẽ bị xoá.',
            style: TextStyle(color: Colors.white60, fontSize: 13)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context),
              child: const Text('Huỷ',
                  style: TextStyle(color: Color(0xFF94a3b8)))),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10))),
            onPressed: () {
              Navigator.pop(context);
              ref.read(whiteboardViewModelProvider.notifier)
                  .clearBoard(sessionId);
            },
            child: const Text('Xoá'),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────
class _ToolBtn extends StatelessWidget {
  const _ToolBtn({
    required this.icon, required this.label,
    required this.isSelected, required this.onTap,
    this.danger = false,
  });
  final IconData icon; final String label;
  final bool isSelected, danger; final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Tooltip(
    message: label,
    child: GestureDetector(onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        margin: const EdgeInsets.symmetric(horizontal: 1),
        padding: const EdgeInsets.all(7),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF3b82f6) : Colors.transparent,
          borderRadius: BorderRadius.circular(9),
        ),
        child: Icon(icon, size: 18,
          color: danger ? Colors.redAccent
              : isSelected ? Colors.white : Colors.white60),
      ),
    ),
  );
}

class _ColorDot extends StatelessWidget {
  const _ColorDot({required this.color, required this.isSelected, required this.onTap});
  final Color color; final bool isSelected; final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 150),
      margin: const EdgeInsets.symmetric(horizontal: 2),
      width: isSelected ? 22 : 16, height: isSelected ? 22 : 16,
      decoration: BoxDecoration(
        color: color, shape: BoxShape.circle,
        border: Border.all(
            color: isSelected ? Colors.white : Colors.white24,
            width: isSelected ? 2 : 1),
      ),
    ),
  );
}

class _StrokeBtn extends StatelessWidget {
  const _StrokeBtn({required this.current, required this.onChange});
  final double current; final ValueChanged<double> onChange;

  @override
  Widget build(BuildContext context) => PopupMenuButton<double>(
    tooltip: 'Độ dày', color: const Color(0xFF334155), padding: EdgeInsets.zero,
    icon: const Icon(Icons.line_weight, color: Colors.white60, size: 18),
    onSelected: onChange,
    itemBuilder: (_) => [2.0, 4.0, 8.0, 14.0].map((w) => PopupMenuItem(
      value: w,
      child: Row(children: [
        Container(width: 50, height: w,
            color: current == w ? const Color(0xFF3b82f6) : Colors.white),
        const SizedBox(width: 8),
        Text('${w.toInt()}px', style: TextStyle(
            color: current == w ? const Color(0xFF3b82f6) : Colors.white,
            fontSize: 12)),
      ]),
    )).toList(),
  );
}

class _PermBtn extends StatelessWidget {
  const _PermBtn({required this.studentCanDraw, required this.onTap});
  final bool studentCanDraw; final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Tooltip(
    message: studentCanDraw ? 'Khoá bảng HS' : 'Cho HS vẽ',
    child: GestureDetector(onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.symmetric(horizontal: 1),
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
        decoration: BoxDecoration(
          color: studentCanDraw
              ? const Color(0xFF22c55e).withOpacity(0.18)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(9),
          border: Border.all(
              color: studentCanDraw
                  ? const Color(0xFF22c55e).withOpacity(0.5)
                  : Colors.white12),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.draw_outlined, size: 14,
              color: studentCanDraw
                  ? const Color(0xFF22c55e) : Colors.white38),
          const SizedBox(width: 3),
          Text(studentCanDraw ? 'HS: ON' : 'HS: OFF',
              style: TextStyle(fontSize: 9, fontWeight: FontWeight.w700,
                  color: studentCanDraw
                      ? const Color(0xFF22c55e) : Colors.white38)),
        ]),
      ),
    ),
  );
}

class _Sep extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Container(
    width: 1, height: 20,
    margin: const EdgeInsets.symmetric(horizontal: 4),
    color: Colors.white12,
  );
}
