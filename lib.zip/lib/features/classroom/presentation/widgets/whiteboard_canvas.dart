// lib/features/classroom/presentation/widgets/whiteboard_canvas.dart
// Fix cho web: dùng Listener thay GestureDetector để bắt pointer events chính xác hơn

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/entities/whiteboard_stroke_entity.dart';
import '../providers/whiteboard_provider.dart';

class WhiteboardCanvas extends ConsumerStatefulWidget {
  const WhiteboardCanvas({
    super.key,
    required this.sessionId,
    required this.strokes,
    this.readonly = false,
  });

  final String sessionId;
  final List<WhiteboardStrokeEntity> strokes;
  final bool readonly;

  @override
  ConsumerState<WhiteboardCanvas> createState() => _WhiteboardCanvasState();
}

class _WhiteboardCanvasState extends ConsumerState<WhiteboardCanvas> {
  bool _pointerDown = false;

  Offset _local(PointerEvent e) {
    final box = context.findRenderObject() as RenderBox?;
    return box?.globalToLocal(e.position) ?? e.localPosition;
  }

  @override
  Widget build(BuildContext context) {
    final vm       = ref.watch(whiteboardViewModelProvider);
    final notifier = ref.read(whiteboardViewModelProvider.notifier);
    final readonly = widget.readonly;

    return MouseRegion(
      cursor: readonly
          ? SystemMouseCursors.basic
          : (vm.tool == WhiteboardTool.eraser
              ? SystemMouseCursors.precise
              : SystemMouseCursors.precise),
      child: Listener(
        behavior: HitTestBehavior.opaque,
        // ── Pointer down ──────────────────────────────────────────
        onPointerDown: readonly
            ? null
            : (e) {
                // Chỉ xử lý chuột trái hoặc stylus/touch
                if (e.kind == PointerDeviceKind.mouse &&
                    e.buttons != kPrimaryButton) return;
                _pointerDown = true;
                notifier.onPanStart(_local(e));
              },
        // ── Pointer move ──────────────────────────────────────────
        onPointerMove: readonly
            ? null
            : (e) {
                if (!_pointerDown) return;
                notifier.onPanUpdate(_local(e));
              },
        // ── Pointer up ────────────────────────────────────────────
        onPointerUp: readonly
            ? null
            : (e) {
                if (!_pointerDown) return;
                _pointerDown = false;
                notifier.onPanEnd(widget.sessionId);
              },
        onPointerCancel: readonly
            ? null
            : (e) {
                if (!_pointerDown) return;
                _pointerDown = false;
                notifier.onPanEnd(widget.sessionId);
              },
        child: RepaintBoundary(
          child: CustomPaint(
            painter: _BoardPainter(
              strokes:       widget.strokes,
              currentPoints: notifier.currentStrokePoints,
              currentColor:  switch (vm.tool) {
                WhiteboardTool.eraser      => Colors.white,
                WhiteboardTool.highlighter => vm.color.withOpacity(0.35),
                _                          => vm.color,
              },
              currentWidth: switch (vm.tool) {
                WhiteboardTool.eraser      => vm.strokeWidth * 5,
                WhiteboardTool.highlighter => vm.strokeWidth * 3,
                _                          => vm.strokeWidth,
              },
            ),
            isComplex:  true,
            willChange: true,
            child: Container(color: Colors.white),
          ),
        ),
      ),
    );
  }
}

// ── Painter ────────────────────────────────────────────────────

class _BoardPainter extends CustomPainter {
  _BoardPainter({
    required this.strokes,
    required this.currentPoints,
    required this.currentColor,
    required this.currentWidth,
  });

  final List<WhiteboardStrokeEntity> strokes;
  final List<Offset> currentPoints;
  final Color currentColor;
  final double currentWidth;

  @override
  void paint(Canvas canvas, Size size) {
    // Vẽ nét đã lưu
    for (final s in strokes) {
      _draw(
        canvas,
        points: s.points,
        color:  s.tool == WhiteboardTool.eraser ? Colors.white : s.color,
        width:  s.strokeWidth,
      );
    }
    // Vẽ nét đang vẽ (local preview)
    if (currentPoints.length >= 2) {
      _draw(canvas,
          points: currentPoints,
          color:  currentColor,
          width:  currentWidth);
    }
  }

  void _draw(
    Canvas canvas, {
    required List<Offset> points,
    required Color color,
    required double width,
  }) {
    if (points.length < 2) return;
    final paint = Paint()
      ..color       = color
      ..strokeWidth = width
      ..strokeCap   = StrokeCap.round
      ..strokeJoin  = StrokeJoin.round
      ..style       = PaintingStyle.stroke;

    final path = Path()..moveTo(points.first.dx, points.first.dy);
    if (points.length == 2) {
      path.lineTo(points[1].dx, points[1].dy);
    } else {
      for (var i = 1; i < points.length - 1; i++) {
        final mid = Offset(
          (points[i].dx + points[i + 1].dx) / 2,
          (points[i].dy + points[i + 1].dy) / 2,
        );
        path.quadraticBezierTo(
            points[i].dx, points[i].dy, mid.dx, mid.dy);
      }
      path.lineTo(points.last.dx, points.last.dy);
    }
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(_BoardPainter old) =>
      old.strokes != strokes ||
      old.currentPoints.length != currentPoints.length ||
      old.currentColor != currentColor ||
      old.currentWidth != currentWidth;
}
