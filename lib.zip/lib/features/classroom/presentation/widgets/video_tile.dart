import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:flutter/material.dart';

class VideoTile extends StatelessWidget {
  const VideoTile({
    super.key,
    required this.uid,
    required this.engine,
    required this.isLocal,
    this.channelId,
    this.name,
    this.isMuted      = false,
    this.isVideoMuted = false,
    this.isTeacher    = false,
  });

  final int uid;
  final RtcEngine engine;
  final bool isLocal;
  final String? channelId;
  final String? name;
  final bool isMuted;
  final bool isVideoMuted;
  final bool isTeacher;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(10),
      child: Stack(fit: StackFit.expand, children: [
        // ── Video surface ──────────────────────────────
        if (!isVideoMuted)
          isLocal
              ? AgoraVideoView(
                  controller: VideoViewController(
                    rtcEngine: engine,
                    canvas:    const VideoCanvas(uid: 0),
                  ),
                )
              : AgoraVideoView(
                  controller: VideoViewController.remote(
                    rtcEngine: engine,
                    canvas:    VideoCanvas(uid: uid),
                    connection: RtcConnection(channelId: channelId ?? ''),
                  ),
                )
        else
          _AvatarPlaceholder(name: name, isTeacher: isTeacher),

        // ── Bottom overlay: name + mic ─────────────────
        Positioned(
          left: 0, right: 0, bottom: 0,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.bottomCenter,
                end:   Alignment.topCenter,
                colors: [Colors.black54, Colors.transparent],
              ),
            ),
            child: Row(children: [
              if (name != null)
                Expanded(child: Text(name!,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        color: Colors.white, fontSize: 10,
                        fontWeight: FontWeight.w600))),
              if (isMuted)
                const Icon(Icons.mic_off, size: 12, color: Colors.redAccent),
            ]),
          ),
        ),

        // ── Role badge ─────────────────────────────────
        Positioned(
          top: 5, left: 5,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
            decoration: BoxDecoration(
              color: isLocal
                  ? const Color(0xFF2563eb).withValues(alpha: 0.85)
                  : isTeacher
                      ? Colors.orange.withValues(alpha: 0.85)
                      : Colors.black45,
              borderRadius: BorderRadius.circular(6),
            ),
            child: Text(
              isLocal ? 'Bạn' : (isTeacher ? 'GV' : 'HS'),
              style: const TextStyle(
                  color: Colors.white, fontSize: 8,
                  fontWeight: FontWeight.w700),
            ),
          ),
        ),
      ]),
    );
  }
}

class _AvatarPlaceholder extends StatelessWidget {
  const _AvatarPlaceholder({this.name, this.isTeacher = false});
  final String? name;
  final bool isTeacher;

  @override
  Widget build(BuildContext context) => Container(
    color: isTeacher ? const Color(0xFF1a1a2e) : const Color(0xFF1e293b),
    child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
      CircleAvatar(
        radius: 20,
        backgroundColor: isTeacher
            ? Colors.orange.withValues(alpha: 0.3)
            : const Color(0xFF334155),
        child: Text(
          name?.isNotEmpty == true ? name![0].toUpperCase() : '?',
          style: TextStyle(
              fontSize: 18,
              color: isTeacher ? Colors.orange : Colors.white70,
              fontWeight: FontWeight.w700),
        ),
      ),
      if (name != null) ...[
        const SizedBox(height: 4),
        Text(name!,
            textAlign: TextAlign.center, maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Colors.white54, fontSize: 9)),
      ],
    ])),
  );
}
