// lib/features/classroom/presentation/widgets/video_tile_mobile.dart
// Dùng cho Android / iOS — native agora_rtc_engine

import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:flutter/material.dart';

class VideoTile extends StatelessWidget {
  const VideoTile({
    super.key,
    required this.uid,
    required this.engine,
    required this.isLocal,
    this.channelId,
    this.name,
    this.isMuted = false,
    this.isVideoMuted = false,
  });

  final int uid;
  final RtcEngine engine;
  final bool isLocal;
  final String? channelId;
  final String? name;
  final bool isMuted;
  final bool isVideoMuted;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: Stack(fit: StackFit.expand, children: [
        if (!isVideoMuted)
          isLocal
              ? AgoraVideoView(
                  controller: VideoViewController(
                    rtcEngine: engine,
                    canvas: const VideoCanvas(uid: 0),
                  ),
                )
              : AgoraVideoView(
                  controller: VideoViewController.remote(
                    rtcEngine: engine,
                    canvas: VideoCanvas(uid: uid),
                    connection: RtcConnection(channelId: channelId ?? ''),
                  ),
                )
        else
          _AvatarPlaceholder(name: name),
        _NameOverlay(name: name, isMuted: isMuted, isLocal: isLocal),
      ]),
    );
  }
}

class _NameOverlay extends StatelessWidget {
  const _NameOverlay(
      {required this.name, required this.isMuted, required this.isLocal});
  final String? name;
  final bool isMuted;
  final bool isLocal;

  @override
  Widget build(BuildContext context) => Stack(children: [
        Positioned(
          left: 0, right: 0, bottom: 0,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.bottomCenter,
                end: Alignment.topCenter,
                colors: [Colors.black54, Colors.transparent],
              ),
            ),
            child: Row(children: [
              if (name != null)
                Expanded(
                  child: Text(name!,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.w600),
                      overflow: TextOverflow.ellipsis),
                ),
              if (isMuted)
                const Icon(Icons.mic_off, size: 12, color: Colors.redAccent),
            ]),
          ),
        ),
        if (isLocal)
          Positioned(
            top: 6, left: 6,
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                  color: const Color(0xFF2563eb).withOpacity(0.85),
                  borderRadius: BorderRadius.circular(20)),
              child: const Text('Bạn',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 9,
                      fontWeight: FontWeight.w700)),
            ),
          ),
      ]);
}

class _AvatarPlaceholder extends StatelessWidget {
  const _AvatarPlaceholder({this.name});
  final String? name;

  @override
  Widget build(BuildContext context) => Container(
        color: const Color(0xFF1e293b),
        child: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            CircleAvatar(
              radius: 20,
              backgroundColor: const Color(0xFF334155),
              child: Text(
                name?.isNotEmpty == true ? name![0].toUpperCase() : '?',
                style: const TextStyle(
                    fontSize: 18,
                    color: Colors.white70,
                    fontWeight: FontWeight.w700),
              ),
            ),
            if (name != null) ...[
              const SizedBox(height: 4),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Text(name!,
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white54, fontSize: 9)),
              ),
            ],
          ]),
        ),
      );
}
