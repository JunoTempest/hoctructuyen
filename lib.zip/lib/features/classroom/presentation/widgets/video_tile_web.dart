// lib/features/classroom/presentation/widgets/video_tile_web.dart
//
// Web implementation: KHÔNG dùng AgoraVideoView native.
// Dùng HtmlElementView + JS interop để render video qua Agora Web SDK.
// agora_rtc_engine trên web đã tự tích hợp qua dart:js_interop.

// ignore: avoid_web_libraries_in_flutter
import 'dart:ui_web' as ui_web;
import 'dart:html' as html;

import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:flutter/material.dart';

// Dummy type để tương thích với import ở classroom_provider
// (engine vẫn là RtcEngine, chỉ VideoTile thay đổi cách render)

class VideoTile extends StatefulWidget {
  const VideoTile({
    super.key,
    required this.uid,
    required this.engine,
    required this.isLocal,
    this.channelId,
    this.name,
    this.isMuted = false,
    this.isVideoMuted = false,
  });

  final int uid;
  final RtcEngine engine;
  final bool isLocal;
  final String? channelId;
  final String? name;
  final bool isMuted;
  final bool isVideoMuted;

  @override
  State<VideoTile> createState() => _VideoTileWebState();
}

class _VideoTileWebState extends State<VideoTile> {
  late final String _viewId;

  @override
  void initState() {
    super.initState();
    _viewId = 'agora-video-${widget.isLocal ? 'local' : 'remote-${widget.uid}'}';

    // Đăng ký HTML element với Flutter web engine
    // ignore: undefined_prefixed_name
    ui_web.platformViewRegistry.registerViewFactory(_viewId, (int id) {
      final div = html.DivElement()
        ..id = _viewId
        ..style.width = '100%'
        ..style.height = '100%'
        ..style.backgroundColor = '#1e293b'
        ..style.overflow = 'hidden';
      return div;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (widget.isVideoMuted) {
      return _AvatarPlaceholder(name: widget.name);
    }

    return ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: Stack(fit: StackFit.expand, children: [
        // Video view qua AgoraVideoView — trên web agora_rtc_engine v6
        // đã handle platformViewRegistry nội bộ
        widget.isLocal
            ? AgoraVideoView(
                controller: VideoViewController(
                  rtcEngine: widget.engine,
                  canvas: const VideoCanvas(uid: 0),
                ),
              )
            : AgoraVideoView(
                controller: VideoViewController.remote(
                  rtcEngine: widget.engine,
                  canvas: VideoCanvas(uid: widget.uid),
                  connection:
                      RtcConnection(channelId: widget.channelId ?? ''),
                ),
              ),
        _NameOverlay(
            name: widget.name,
            isMuted: widget.isMuted,
            isLocal: widget.isLocal),
      ]),
    );
  }
}

class _NameOverlay extends StatelessWidget {
  const _NameOverlay(
      {required this.name, required this.isMuted, required this.isLocal});
  final String? name;
  final bool isMuted;
  final bool isLocal;

  @override
  Widget build(BuildContext context) => Stack(children: [
        Positioned(
          left: 0, right: 0, bottom: 0,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.bottomCenter,
                end: Alignment.topCenter,
                colors: [Colors.black54, Colors.transparent],
              ),
            ),
            child: Row(children: [
              if (name != null)
                Expanded(
                  child: Text(name!,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.w600),
                      overflow: TextOverflow.ellipsis),
                ),
              if (isMuted)
                const Icon(Icons.mic_off, size: 12, color: Colors.redAccent),
            ]),
          ),
        ),
        if (isLocal)
          Positioned(
            top: 6, left: 6,
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                  color: const Color(0xFF2563eb).withOpacity(0.85),
                  borderRadius: BorderRadius.circular(20)),
              child: const Text('Bạn',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 9,
                      fontWeight: FontWeight.w700)),
            ),
          ),
      ]);
}

class _AvatarPlaceholder extends StatelessWidget {
  const _AvatarPlaceholder({this.name});
  final String? name;

  @override
  Widget build(BuildContext context) => Container(
        color: const Color(0xFF1e293b),
        child: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            CircleAvatar(
              radius: 20,
              backgroundColor: const Color(0xFF334155),
              child: Text(
                name?.isNotEmpty == true ? name![0].toUpperCase() : '?',
                style: const TextStyle(
                    fontSize: 18,
                    color: Colors.white70,
                    fontWeight: FontWeight.w700),
              ),
            ),
            if (name != null) ...[
              const SizedBox(height: 4),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Text(name!,
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style:
                        const TextStyle(color: Colors.white54, fontSize: 9)),
              ),
            ],
          ]),
        ),
      );
}
