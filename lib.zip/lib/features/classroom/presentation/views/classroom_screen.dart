import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import '../../../../core/constants/app_constants.dart';
import '../../../auth/presentation/providers/auth_provider.dart';
import '../providers/classroom_provider.dart';
import '../providers/whiteboard_provider.dart';
import '../../domain/entities/whiteboard_stroke_entity.dart';
import '../widgets/toolbar_widget.dart';
import '../widgets/video_tile.dart';
import '../widgets/whiteboard_canvas.dart';

// ═══════════════════════════════════════════════════════════════
//  Chat message model (local + Firestore free — chỉ dùng RAM)
// ═══════════════════════════════════════════════════════════════
class _ChatMsg {
  const _ChatMsg({
    required this.sender,
    required this.text,
    required this.isAI,
    required this.time,
  });
  final String sender;
  final String text;
  final bool isAI;
  final DateTime time;
}

// ═══════════════════════════════════════════════════════════════
//  ClassroomScreen
// ═══════════════════════════════════════════════════════════════
class ClassroomScreen extends ConsumerStatefulWidget {
  const ClassroomScreen({
    super.key,
    required this.sessionId,
    required this.channelName,
    required this.sessionTitle,
    this.startTime,
  });

  final String sessionId;
  final String channelName;
  final String sessionTitle;
  final DateTime? startTime;

  @override
  ConsumerState<ClassroomScreen> createState() => _ClassroomScreenState();
}

class _ClassroomScreenState extends ConsumerState<ClassroomScreen>
    with TickerProviderStateMixin {
  // Chat
  final _chatCtrl   = TextEditingController();
  final _chatScroll = ScrollController();
  final _msgs       = <_ChatMsg>[];
  bool _chatOpen    = false;
  bool _aiLoading   = false;
  int  _unread      = 0;

  // Timer
  Timer? _timer;
  Duration _elapsed = Duration.zero;

  // Layout tabs (portrait)
  late TabController _tabCtrl;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    WidgetsBinding.instance.addPostFrameCallback((_) => _joinRoom());
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() {
        _elapsed = DateTime.now()
            .difference(widget.startTime ?? DateTime.now());
      });
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _chatCtrl.dispose();
    _chatScroll.dispose();
    _tabCtrl.dispose();
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    super.dispose();
  }

  Future<void> _joinRoom() async {
    final user = ref.read(authStateStreamProvider).value;
    if (user == null) return;
    await ref.read(classroomViewModelProvider.notifier).joinRoom(
      channelName: widget.channelName,
      sessionId:   widget.sessionId,
      isTeacher:   user.isTeacher,
    );
  }

  Future<void> _leaveRoom() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1e293b),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Kết thúc buổi học?',
            style: TextStyle(color: Colors.white, fontSize: 15)),
        content: const Text('Bạn có chắc muốn rời khỏi phòng?',
            style: TextStyle(color: Colors.white60, fontSize: 13)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Ở lại',
                style: TextStyle(color: Color(0xFF94a3b8))),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10))),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Rời phòng'),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    await ref
        .read(classroomViewModelProvider.notifier)
        .leaveRoom(widget.sessionId);
    if (mounted) context.canPop() ? context.pop() : context.go('/schedule');
  }

  // ── Chat & AI ─────────────────────────────────────────────────

  void _sendChat() {
    final text = _chatCtrl.text.trim();
    if (text.isEmpty) return;
    final user = ref.read(authStateStreamProvider).value;
    final isAI = text.startsWith('@trợ giảng') || text.startsWith('@tro giang');

    setState(() {
      _msgs.add(_ChatMsg(
        sender: user?.displayName ?? 'Bạn',
        text:   text,
        isAI:   false,
        time:   DateTime.now(),
      ));
    });
    _chatCtrl.clear();
    _scrollChat();

    if (isAI) {
      _askAI(text.replaceFirst(RegExp(r'@trợ giảng|@tro giang', caseSensitive: false), '').trim());
    }
  }

  Future<void> _askAI(String question) async {
    if (question.isEmpty) return;
    setState(() => _aiLoading = true);

    try {
      final prompt = '''Bạn là trợ giảng AI trong lớp học trực tuyến.
Nhiệm vụ: KHÔNG giải toàn bộ bài, chỉ hướng dẫn từng bước nhỏ.
Trả lời ngắn gọn, rõ ràng bằng tiếng Việt.
Nếu học sinh hỏi đáp án thẳng, hãy từ chối nhẹ nhàng và gợi ý hướng suy nghĩ.
Câu hỏi: $question''';

      final res = await http
          .post(
        Uri.parse(
            'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${AppConstants.geminiApiKey}'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'contents': [
            {
              'parts': [
                {'text': prompt}
              ]
            }
          ],
          'generationConfig': {'maxOutputTokens': 300, 'temperature': 0.7},
        }),
      )
          .timeout(const Duration(seconds: 15));

      if (res.statusCode == 200) {
        final data   = jsonDecode(res.body);
        final answer = data['candidates']?[0]?['content']?['parts']?[0]?['text']
        as String? ?? 'Xin lỗi, tôi không thể trả lời lúc này.';
        setState(() {
          _msgs.add(_ChatMsg(
              sender: '🤖 Trợ giảng AI',
              text:   answer.trim(),
              isAI:   true,
              time:   DateTime.now()));
        });
      } else {
        setState(() {
          _msgs.add(_ChatMsg(
              sender: '🤖 Trợ giảng AI',
              text:   'Lỗi kết nối AI (${res.statusCode}). Thêm Gemini API key vào app_constants.dart',
              isAI:   true,
              time:   DateTime.now()));
        });
      }
    } catch (e) {
      setState(() {
        _msgs.add(_ChatMsg(
            sender: '🤖 Trợ giảng AI',
            text:   'Không kết nối được AI: $e',
            isAI:   true,
            time:   DateTime.now()));
      });
    } finally {
      setState(() => _aiLoading = false);
      _scrollChat();
    }
  }

  void _scrollChat() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_chatScroll.hasClients) {
        _chatScroll.animateTo(
          _chatScroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  String get _elapsedStr {
    final m = _elapsed.inMinutes.toString().padLeft(2, '0');
    final s = (_elapsed.inSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  // ─────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final user      = ref.watch(authStateStreamProvider).value;
    final agora     = ref.watch(classroomViewModelProvider);
    final session   = ref.watch(classroomSessionProvider);
    final strokes   = ref.watch(boardStrokesProvider(widget.sessionId));
    final isSyncing = ref.watch(whiteboardViewModelProvider).isSyncing;
    final isTeacher = user?.isTeacher ?? false;
    final canDraw   = isTeacher || session.studentCanDraw;
    final engine    = ref.read(classroomViewModelProvider.notifier).engine;
    final connected = agora is AgoraConnected ? (agora as AgoraConnected) : null;
    final isLandscape =
        MediaQuery.of(context).orientation == Orientation.landscape;

    ref.listen<AgoraState>(classroomViewModelProvider, (_, next) {
      if (next is AgoraEnded && mounted) {
        context.canPop() ? context.pop() : context.go('/schedule');
      }
    });

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) { if (!didPop) _leaveRoom(); },
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: const Color(0xFF0a0f1e),
        body: SafeArea(
          child: Column(children: [
            // ── TOP BAR ─────────────────────────────────
            _buildTopBar(isTeacher, session),

            // ── MAIN CONTENT ─────────────────────────────
            Expanded(
              child: isLandscape
                  ? _buildLandscape(
                  user, agora, session, connected, engine,
                  strokes, canDraw, isTeacher, isSyncing)
                  : _buildPortrait(
                  user, agora, session, connected, engine,
                  strokes, canDraw, isTeacher, isSyncing),
            ),

            // ── TOOLBAR (draw tools) ─────────────────────
            if (canDraw || isTeacher)
              _buildToolbarRow(isTeacher, session),

            // ── BOTTOM BAR ───────────────────────────────
            _buildBottomBar(agora, session, isTeacher, connected),
          ]),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════
  //  TOP BAR
  // ═══════════════════════════════════════════════════

  Widget _buildTopBar(bool isTeacher, dynamic session) {
    return Container(
      color: const Color(0xFF080e1d),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Row(children: [
        // Title + Room ID
        Expanded(child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(widget.sessionTitle,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                    color: Colors.white, fontSize: 13,
                    fontWeight: FontWeight.w700)),
            GestureDetector(
              onTap: () {
                Clipboard.setData(
                    ClipboardData(text: widget.channelName));
                ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Đã sao chép Room ID'),
                        duration: Duration(seconds: 1),
                        backgroundColor: Color(0xFF1e293b)));
              },
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Text('ID: ${widget.channelName}',
                    style: const TextStyle(
                        color: Color(0xFF475569), fontSize: 9)),
                const SizedBox(width: 3),
                const Icon(Icons.copy_outlined,
                    size: 9, color: Color(0xFF475569)),
              ]),
            ),
          ],
        )),

        // Timer
        Text(_elapsedStr,
            style: const TextStyle(
                color: Color(0xFF64748b), fontSize: 11,
                fontFamily: 'monospace')),
        const SizedBox(width: 8),

        // LIVE badge
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
          decoration: BoxDecoration(
              color: Colors.red.withValues(alpha: 0.85),
              borderRadius: BorderRadius.circular(20)),
          child: const Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.circle, size: 6, color: Colors.white),
            SizedBox(width: 3),
            Text('LIVE', style: TextStyle(
                color: Colors.white, fontSize: 9,
                fontWeight: FontWeight.w800)),
          ]),
        ),

        // Chat button
        const SizedBox(width: 6),
        Stack(clipBehavior: Clip.none, children: [
          IconButton(
            icon: const Icon(Icons.chat_bubble_outline,
                color: Colors.white60, size: 20),
            padding: const EdgeInsets.all(4),
            constraints: const BoxConstraints(),
            onPressed: () => setState(() {
              _chatOpen = !_chatOpen;
              if (_chatOpen) _unread = 0;
            }),
          ),
          if (_unread > 0)
            Positioned(
              top: -2, right: -2,
              child: Container(
                width: 14, height: 14,
                decoration: const BoxDecoration(
                    color: Colors.red, shape: BoxShape.circle),
                child: Center(child: Text('$_unread',
                    style: const TextStyle(
                        color: Colors.white, fontSize: 8))),
              ),
            ),
        ]),
      ]),
    );
  }

  // ═══════════════════════════════════════════════════
  //  PORTRAIT layout: Tab (Bảng / Chat) + Video strip
  // ═══════════════════════════════════════════════════

  Widget _buildPortrait(dynamic user, AgoraState agora, dynamic session, AgoraConnected? connected, dynamic engine,
      AsyncValue<List<WhiteboardStrokeEntity>> strokes, bool canDraw, bool isTeacher, bool isSyncing) {
    return Column(children: [
      // Video strip (ngang, cố định 72px)
      _HVideoStrip(
          engine: engine, connected: connected,
          localName: user?.displayName, isTeacher: isTeacher,
          channelId: widget.channelName),

      // Tab bar
      Container(
        color: const Color(0xFF080e1d),
        child: TabBar(
          controller: _tabCtrl,
          indicatorColor: const Color(0xFF3b82f6),
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white38,
          labelStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
          tabs: const [
            Tab(text: '📋 Bảng vẽ'),
            Tab(text: '💬 Chat'),
          ],
        ),
      ),

      // Tab content
      Expanded(child: TabBarView(
        controller: _tabCtrl,
        children: [
          // Tab 1: Whiteboard
          _buildBoardArea(agora, session, strokes, canDraw, isSyncing),
          // Tab 2: Chat
          _buildChatPanel(user),
        ],
      )),
    ]);
  }

  // ═══════════════════════════════════════════════════
  //  LANDSCAPE layout: Board | Video strip | Chat
  // ═══════════════════════════════════════════════════

  Widget _buildLandscape(dynamic user, AgoraState agora, dynamic session, AgoraConnected? connected, dynamic engine,
      AsyncValue<List<WhiteboardStrokeEntity>> strokes, bool canDraw, bool isTeacher, bool isSyncing) {
    return Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      // Board (chiếm hết còn lại)
      Expanded(
        child: _buildBoardArea(agora, session, strokes, canDraw, isSyncing),
      ),

      // Video strip (dọc, 88px)
      _VVideoStrip(
          engine: engine, connected: connected,
          localName: user?.displayName, isTeacher: isTeacher,
          channelId: widget.channelName),

      // Chat panel (240px khi mở)
      if (_chatOpen)
        SizedBox(width: 240, child: _buildChatPanel(user)),
    ]);
  }

  // ═══════════════════════════════════════════════════
  //  BOARD AREA
  // ═══════════════════════════════════════════════════

  Widget _buildBoardArea(AgoraState agora, dynamic session, AsyncValue<List<WhiteboardStrokeEntity>> strokes, bool canDraw, bool isSyncing) {
    return Stack(children: [
      // Whiteboard — nền trắng
      Positioned.fill(child: () {
        if (agora is AgoraJoining) {
          return const ColoredBox(color: Colors.white,
              child: Center(child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(color: Color(0xFF3b82f6)),
                  SizedBox(height: 10),
                  Text('Đang vào phòng...', style: TextStyle(color: Colors.black54)),
                ],
              )));
        }
        return strokes.when(
          loading: () => const ColoredBox(
              color: Colors.white,
              child: Center(child: CircularProgressIndicator(
                  color: Color(0xFF3b82f6)))),
          error:   (e, _) => ColoredBox(
              color: Colors.white,
              child: Center(child: Text('Lỗi: $e',
                  style: const TextStyle(color: Colors.black54)))),
          data: (list) => WhiteboardCanvas(
            sessionId: widget.sessionId,
            strokes:   list,
            readonly:  !canDraw,
          ),
        );
      }()),

      // Syncing badge
      if (isSyncing)
        const Positioned(top: 8, right: 8, child: _SyncBadge()),

      // Error toast
      if (agora is AgoraError)
        Positioned(bottom: 8, left: 8, right: 8,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                  color: Colors.red.withValues(alpha: 0.9),
                  borderRadius: BorderRadius.circular(10)),
              child: Row(children: [
                const Icon(Icons.error_outline, color: Colors.white, size: 16),
                const SizedBox(width: 8),
                Expanded(child: Text(
                    (agora as AgoraError).message,
                    style: const TextStyle(color: Colors.white, fontSize: 11),
                    maxLines: 2)),
              ]),
            )),
    ]);
  }

  // ═══════════════════════════════════════════════════
  //  CHAT PANEL
  // ═══════════════════════════════════════════════════

  Widget _buildChatPanel(user) {
    return Container(
      color: const Color(0xFF0f172a),
      child: Column(children: [
        // Header
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          color: const Color(0xFF1e293b),
          child: Row(children: [
            const Icon(Icons.chat_bubble_outline,
                size: 14, color: Color(0xFF3b82f6)),
            const SizedBox(width: 6),
            const Text('Chat lớp học',
                style: TextStyle(color: Colors.white,
                    fontSize: 12, fontWeight: FontWeight.w700)),
            const Spacer(),
            // AI hint
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                  color: const Color(0xFF3b82f6).withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                      color: const Color(0xFF3b82f6).withValues(alpha: 0.3))),
              child: const Text('@trợ giảng',
                  style: TextStyle(color: Color(0xFF60a5fa),
                      fontSize: 9, fontWeight: FontWeight.w600)),
            ),
          ]),
        ),

        // AI hint banner
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          color: const Color(0xFF1a2744),
          child: Row(children: const [
            Icon(Icons.info_outline, size: 11, color: Color(0xFF60a5fa)),
            SizedBox(width: 5),
            Expanded(child: Text(
              'Gõ @trợ giảng [câu hỏi] để nhận gợi ý từng bước',
              style: TextStyle(color: Color(0xFF94a3b8), fontSize: 10),
            )),
          ]),
        ),

        // Messages
        Expanded(child: ListView.builder(
          controller: _chatScroll,
          padding: const EdgeInsets.symmetric(vertical: 8),
          itemCount: _msgs.length + (_aiLoading ? 1 : 0),
          itemBuilder: (_, i) {
            if (i == _msgs.length) return _TypingIndicator();
            return _ChatBubble(msg: _msgs[i],
                isMe: _msgs[i].sender == (user?.displayName ?? ''));
          },
        )),

        // Input
        Container(
          color: const Color(0xFF1e293b),
          padding: const EdgeInsets.fromLTRB(10, 6, 6, 6),
          child: Row(children: [
            Expanded(child: TextField(
              controller: _chatCtrl,
              style: const TextStyle(color: Colors.white, fontSize: 13),
              maxLines: null,
              textInputAction: TextInputAction.send,
              onSubmitted: (_) => _sendChat(),
              decoration: InputDecoration(
                hintText: 'Nhắn tin... hoặc @trợ giảng',
                hintStyle: const TextStyle(
                    color: Colors.white30, fontSize: 12),
                border: InputBorder.none,
                isDense: true,
              ),
            )),
            GestureDetector(
              onTap: _sendChat,
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                    color: const Color(0xFF2563eb),
                    borderRadius: BorderRadius.circular(8)),
                child: const Icon(Icons.send,
                    size: 16, color: Colors.white),
              ),
            ),
          ]),
        ),
      ]),
    );
  }

  // ═══════════════════════════════════════════════════
  //  TOOLBAR ROW
  // ═══════════════════════════════════════════════════

  Widget _buildToolbarRow(bool isTeacher, dynamic session) {
    return Container(
      color: const Color(0xFF080e1d),
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: WhiteboardToolbar(
          sessionId:           widget.sessionId,
          isTeacher:           isTeacher,
          studentCanDraw:      session.studentCanDraw,
          onToggleStudentDraw: isTeacher
              ? () => ref
              .read(classroomSessionProvider.notifier)
              .toggleStudentDraw()
              : null,
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════
  //  BOTTOM BAR
  // ═══════════════════════════════════════════════════

  Widget _buildBottomBar(AgoraState agora, dynamic session,
      bool isTeacher, AgoraConnected? connected) {
    return Container(
      color: const Color(0xFF080e1d),
      padding: const EdgeInsets.fromLTRB(10, 5, 10, 8),
      child: Row(children: [
        // Mic
        _CtrlBtn(
          icon:   connected?.localAudioMuted == true
              ? Icons.mic_off : Icons.mic,
          label:  connected?.localAudioMuted == true ? 'Tắt' : 'Mic',
          red:    connected?.localAudioMuted == true,
          onTap:  connected != null
              ? () => ref.read(classroomViewModelProvider.notifier).toggleAudio()
              : null,
        ),
        const SizedBox(width: 6),

        // Camera
        _CtrlBtn(
          icon:   connected?.localVideoMuted == true
              ? Icons.videocam_off : Icons.videocam,
          label:  connected?.localVideoMuted == true ? 'Tắt' : 'Camera',
          red:    connected?.localVideoMuted == true,
          onTap:  connected != null
              ? () => ref.read(classroomViewModelProvider.notifier).toggleVideo()
              : null,
        ),

        // Teacher-only: Share screen + Upload file
        if (isTeacher) ...[
          const SizedBox(width: 6),
          _CtrlBtn(
            icon:   session.isScreenSharing
                ? Icons.stop_screen_share_outlined
                : Icons.screen_share_outlined,
            label:  session.isScreenSharing ? 'Dừng' : 'Màn hình',
            active: session.isScreenSharing,
            onTap:  () => session.isScreenSharing
                ? ref.read(classroomViewModelProvider.notifier)
                .stopScreenShare()
                : ref.read(classroomViewModelProvider.notifier)
                .startScreenShare(),
          ),
          const SizedBox(width: 6),
          _CtrlBtn(
            icon:  Icons.upload_file_outlined,
            label: 'Tài liệu',
            onTap: () => _showDocSheet(),
          ),
        ],

        const Spacer(),

        // End button
        GestureDetector(
          onTap: _leaveRoom,
          child: Container(
            padding: const EdgeInsets.symmetric(
                horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
                color: Colors.red,
                borderRadius: BorderRadius.circular(24)),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.call_end, color: Colors.white, size: 18),
              const SizedBox(width: 5),
              Text(isTeacher ? 'Kết thúc' : 'Rời phòng',
                  style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 12)),
            ]),
          ),
        ),
      ]),
    );
  }

  void _showDocSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1e293b),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 36, height: 4, margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(color: Colors.white24,
                  borderRadius: BorderRadius.circular(2))),
          const Text('Tải tài liệu',
              style: TextStyle(color: Colors.white,
                  fontSize: 16, fontWeight: FontWeight.w700)),
          const SizedBox(height: 16),
          _DocOption(
            icon: Icons.image_outlined,
            title: 'Ảnh / Slide',
            sub: 'JPG, PNG, PDF',
            onTap: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                content: Text(
                    'Thêm firebase_storage + image_picker vào pubspec để bật tính năng này'),
                backgroundColor: Color(0xFF334155),
              ));
            },
          ),
          const SizedBox(height: 8),
          _DocOption(
            icon: Icons.link_outlined,
            title: 'Chia sẻ link',
            sub: 'Google Slide, YouTube...',
            onTap: () {
              Navigator.pop(context);
              _shareLink();
            },
          ),
        ]),
      ),
    );
  }

  Future<void> _shareLink() async {
    final ctrl = TextEditingController();
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1e293b),
        title: const Text('Nhập link', style: TextStyle(color: Colors.white)),
        content: TextField(
          controller: ctrl, autofocus: true,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(
              hintText: 'https://',
              hintStyle: TextStyle(color: Colors.white30),
              enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.white24)),
              focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Color(0xFF3b82f6)))),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context),
              child: const Text('Huỷ',
                  style: TextStyle(color: Color(0xFF94a3b8)))),
          FilledButton(
            onPressed: () {
              Navigator.pop(context);
              final link = ctrl.text.trim();
              if (link.isNotEmpty) {
                setState(() {
                  _msgs.add(_ChatMsg(
                    sender: ref.read(authStateStreamProvider).value
                        ?.displayName ?? 'GV',
                    text:   '📎 Link tài liệu: $link',
                    isAI:   false,
                    time:   DateTime.now(),
                  ));
                });
                _scrollChat();
                // Switch to chat tab on portrait
                _tabCtrl.animateTo(1);
              }
            },
            child: const Text('Chia sẻ'),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════
//  VIDEO STRIPS
// ═══════════════════════════════════════════════════

class _HVideoStrip extends StatelessWidget {
  const _HVideoStrip({
    required this.engine,
    required this.connected,
    required this.localName,
    required this.isTeacher,
    required this.channelId,
  });
  final dynamic engine;
  final AgoraConnected? connected;
  final String? localName;
  final bool isTeacher;
  final String channelId;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 76, color: const Color(0xFF080e1d),
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 5),
        children: [
          _HVTile(isTeacher: isTeacher, isMe: true,
              child: engine != null
                  ? VideoTile(uid: 0, engine: engine, channelId: channelId,
                  isLocal: true, name: localName,
                  isTeacher: isTeacher,
                  isVideoMuted: connected?.localVideoMuted ?? false,
                  isMuted: connected?.localAudioMuted ?? false)
                  : null),
          if ((connected?.remoteUids ?? []).isEmpty)
            _HVTile(isTeacher: false, isMe: false, child: null)
          else
            for (final uid in (connected?.remoteUids ?? <int>[]))
              _HVTile(isTeacher: !isTeacher, isMe: false,
                  child: engine != null
                      ? VideoTile(uid: uid, engine: engine, channelId: channelId,
                      isLocal: false, isTeacher: !isTeacher)
                      : null),
        ],
      ),
    );
  }
}

class _HVTile extends StatelessWidget {
  const _HVTile({required this.isMe, required this.isTeacher, required this.child});
  final bool isMe, isTeacher; final Widget? child;
  @override
  Widget build(BuildContext context) => Container(
    width: 96, margin: const EdgeInsets.only(right: 6),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(8),
      border: Border.all(
          color: isTeacher ? Colors.orange.withValues(alpha: 0.6)
              : isMe ? const Color(0xFF2563eb)
              : const Color(0xFF334155),
          width: 1.5),
      color: const Color(0xFF1e293b),
    ),
    clipBehavior: Clip.antiAlias,
    child: child ?? const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(Icons.person_outline, color: Color(0xFF334155), size: 20),
      Text('Chờ...', style: TextStyle(color: Color(0xFF334155), fontSize: 8)),
    ])),
  );
}

class _VVideoStrip extends StatelessWidget {
  const _VVideoStrip({
    required this.engine,
    required this.connected,
    required this.localName,
    required this.isTeacher,
    required this.channelId,
  });
  final dynamic engine;
  final AgoraConnected? connected;
  final String? localName;
  final bool isTeacher;
  final String channelId;

  @override
  Widget build(BuildContext context) {
    final uids = connected?.remoteUids ?? <int>[];
    return Container(
      width: 92, color: const Color(0xFF080e1d),
      child: ListView(
        children: [
          _VVTile(isTeacher: isTeacher, isMe: true,
              child: engine != null
                  ? VideoTile(uid: 0, engine: engine, channelId: channelId,
                  isLocal: true, name: localName, isTeacher: isTeacher,
                  isVideoMuted: connected?.localVideoMuted ?? false,
                  isMuted: connected?.localAudioMuted ?? false)
                  : null),
          if (uids.isEmpty)
            const _VVTile(isTeacher: false, isMe: false, child: null)
          else
            for (final uid in uids)
              _VVTile(isTeacher: !isTeacher, isMe: false,
                  child: engine != null
                      ? VideoTile(uid: uid, engine: engine, channelId: channelId,
                      isLocal: false, isTeacher: !isTeacher)
                      : null),
        ],
      ),
    );
  }
}

class _VVTile extends StatelessWidget {
  const _VVTile({required this.isMe, required this.isTeacher, required this.child});
  final bool isMe, isTeacher; final Widget? child;
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.fromLTRB(5, 5, 5, 0), height: 74,
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(8),
      border: Border.all(
          color: isTeacher ? Colors.orange.withValues(alpha: 0.6)
              : isMe ? const Color(0xFF2563eb)
              : const Color(0xFF334155),
          width: 1.5),
      color: const Color(0xFF1e293b),
    ),
    clipBehavior: Clip.antiAlias,
    child: child ?? const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(Icons.person_outline, color: Color(0xFF334155), size: 18),
      Text('Chờ...', style: TextStyle(color: Color(0xFF334155), fontSize: 8)),
    ])),
  );
}

// ═══════════════════════════════════════════════════
//  CHAT WIDGETS
// ═══════════════════════════════════════════════════

class _ChatBubble extends StatelessWidget {
  const _ChatBubble({required this.msg, required this.isMe});
  final _ChatMsg msg; final bool isMe;

  @override
  Widget build(BuildContext context) {
    final isAI = msg.isAI;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
      child: Column(
        crossAxisAlignment:
        isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          // Sender name
          Padding(
            padding: const EdgeInsets.only(bottom: 2, left: 4, right: 4),
            child: Text(
              '${msg.sender} · ${msg.time.hour.toString().padLeft(2, '0')}:${msg.time.minute.toString().padLeft(2, '0')}',
              style: TextStyle(
                  color: isAI
                      ? const Color(0xFF60a5fa)
                      : Colors.white38,
                  fontSize: 9),
            ),
          ),
          // Bubble
          Container(
            constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width * 0.72),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            decoration: BoxDecoration(
              color: isAI
                  ? const Color(0xFF1a2744)
                  : isMe
                  ? const Color(0xFF2563eb)
                  : const Color(0xFF1e293b),
              borderRadius: BorderRadius.circular(12),
              border: isAI
                  ? Border.all(
                  color: const Color(0xFF3b82f6).withValues(alpha: 0.3))
                  : null,
            ),
            child: Text(msg.text,
                style: const TextStyle(color: Colors.white, fontSize: 12)),
          ),
        ],
      ),
    );
  }
}

class _TypingIndicator extends StatefulWidget {
  @override State<_TypingIndicator> createState() => _TypingIndicatorState();
}

class _TypingIndicatorState extends State<_TypingIndicator>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _a;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 800))
      ..repeat(reverse: true);
    _a = Tween<double>(begin: 0.3, end: 1.0).animate(_c);
  }
  @override void dispose() { _c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
    child: Row(children: [
      AnimatedBuilder(animation: _a, builder: (_, __) =>
          Opacity(opacity: _a.value, child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            decoration: BoxDecoration(color: const Color(0xFF1a2744),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFF3b82f6).withValues(alpha: 0.3))),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.auto_awesome, size: 12, color: Color(0xFF60a5fa)),
              const SizedBox(width: 5),
              const Text('Trợ giảng đang suy nghĩ...',
                  style: TextStyle(color: Color(0xFF60a5fa), fontSize: 11)),
            ]),
          ))),
    ]),
  );
}

// ═══════════════════════════════════════════════════
//  CONTROL BUTTON
// ═══════════════════════════════════════════════════

class _CtrlBtn extends StatelessWidget {
  const _CtrlBtn({
    required this.icon, required this.label, required this.onTap,
    this.red = false, this.active = false,
  });
  final IconData icon; final String label;
  final bool red, active; final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Opacity(
      opacity: onTap == null ? 0.35 : 1.0,
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          width: 42, height: 42,
          decoration: BoxDecoration(
            color: red
                ? Colors.red.withValues(alpha: 0.2)
                : active
                ? const Color(0xFF2563eb).withValues(alpha: 0.2)
                : Colors.white.withValues(alpha: 0.07),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, size: 19,
              color: red ? Colors.redAccent
                  : active ? const Color(0xFF60a5fa) : Colors.white70),
        ),
        const SizedBox(height: 2),
        Text(label,
            style: const TextStyle(color: Color(0xFF64748b), fontSize: 9)),
      ]),
    ),
  );
}

// ═══════════════════════════════════════════════════
//  MISC WIDGETS
// ═══════════════════════════════════════════════════

class _SyncBadge extends StatelessWidget {
  const _SyncBadge();
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
    decoration: BoxDecoration(color: Colors.black54,
        borderRadius: BorderRadius.circular(16)),
    child: const Row(mainAxisSize: MainAxisSize.min, children: [
      SizedBox(width: 10, height: 10,
          child: CircularProgressIndicator(strokeWidth: 1.5, color: Colors.white60)),
      SizedBox(width: 6),
      Text('Đang đồng bộ...', style: TextStyle(color: Colors.white60, fontSize: 10)),
    ]),
  );
}

class _DocOption extends StatelessWidget {
  const _DocOption({
    required this.icon, required this.title,
    required this.sub, required this.onTap,
  });
  final IconData icon; final String title, sub; final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(color: const Color(0xFF0f172a),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFF334155))),
      child: Row(children: [
        Container(padding: const EdgeInsets.all(7),
            decoration: BoxDecoration(
                color: const Color(0xFF3b82f6).withValues(alpha: 0.14),
                borderRadius: BorderRadius.circular(7)),
            child: Icon(icon, color: const Color(0xFF3b82f6), size: 16)),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(color: Colors.white,
              fontSize: 13, fontWeight: FontWeight.w600)),
          Text(sub, style: const TextStyle(color: Colors.white38, fontSize: 10)),
        ])),
        const Icon(Icons.chevron_right, color: Colors.white24, size: 15),
      ]),
    ),
  );
}