// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'whiteboard_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(boardStrokes)
const boardStrokesProvider = BoardStrokesFamily._();

final class BoardStrokesProvider extends $FunctionalProvider<
        AsyncValue<List<WhiteboardStrokeEntity>>,
        List<WhiteboardStrokeEntity>,
        Stream<List<WhiteboardStrokeEntity>>>
    with
        $FutureModifier<List<WhiteboardStrokeEntity>>,
        $StreamProvider<List<WhiteboardStrokeEntity>> {
  const BoardStrokesProvider._(
      {required BoardStrokesFamily super.from, required String super.argument})
      : super(
          retry: null,
          name: r'boardStrokesProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$boardStrokesHash();

  @override
  String toString() {
    return r'boardStrokesProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $StreamProviderElement<List<WhiteboardStrokeEntity>> $createElement(
          $ProviderPointer pointer) =>
      $StreamProviderElement(pointer);

  @override
  Stream<List<WhiteboardStrokeEntity>> create(Ref ref) {
    final argument = this.argument as String;
    return boardStrokes(
      ref,
      argument,
    );
  }

  @override
  bool operator ==(Object other) {
    return other is BoardStrokesProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$boardStrokesHash() => r'ffc8110b78c81f74b19f8eda2f17e3103bd625bc';

final class BoardStrokesFamily extends $Family
    with
        $FunctionalFamilyOverride<Stream<List<WhiteboardStrokeEntity>>,
            String> {
  const BoardStrokesFamily._()
      : super(
          retry: null,
          name: r'boardStrokesProvider',
          dependencies: null,
          $allTransitiveDependencies: null,
          isAutoDispose: true,
        );

  BoardStrokesProvider call(
    String sessionId,
  ) =>
      BoardStrokesProvider._(argument: sessionId, from: this);

  @override
  String toString() => r'boardStrokesProvider';
}

@ProviderFor(WhiteboardViewModel)
const whiteboardViewModelProvider = WhiteboardViewModelProvider._();

final class WhiteboardViewModelProvider
    extends $NotifierProvider<WhiteboardViewModel, WhiteboardState> {
  const WhiteboardViewModelProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'whiteboardViewModelProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$whiteboardViewModelHash();

  @$internal
  @override
  WhiteboardViewModel create() => WhiteboardViewModel();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(WhiteboardState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<WhiteboardState>(value),
    );
  }
}

String _$whiteboardViewModelHash() =>
    r'2beecde3592f21a2ba2328e025ff84ea0f32b18a';

abstract class _$WhiteboardViewModel extends $Notifier<WhiteboardState> {
  WhiteboardState build();
  @$mustCallSuper
  @override
  void runBuild() {
    final created = build();
    final ref = this.ref as $Ref<WhiteboardState, WhiteboardState>;
    final element = ref.element as $ClassProviderElement<
        AnyNotifier<WhiteboardState, WhiteboardState>,
        WhiteboardState,
        Object?,
        Object?>;
    element.handleValue(ref, created);
  }
}
