// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'classroom_provider.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$AgoraState implements DiagnosticableTreeMixin {
  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    properties..add(DiagnosticsProperty('type', 'AgoraState'));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is AgoraState);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'AgoraState()';
  }
}

/// @nodoc
class $AgoraStateCopyWith<$Res> {
  $AgoraStateCopyWith(AgoraState _, $Res Function(AgoraState) __);
}

/// Adds pattern-matching-related methods to [AgoraState].
extension AgoraStatePatterns on AgoraState {
  /// A variant of `map` that fallback to returning `orElse`.
  ///
  /// It is equivalent to doing:
  /// ```dart
  /// switch (sealedClass) {
  ///   case final Subclass value:
  ///     return ...;
  ///   case _:
  ///     return orElse();
  /// }
  /// ```

  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(AgoraIdle value)? idle,
    TResult Function(AgoraJoining value)? joining,
    TResult Function(AgoraConnected value)? connected,
    TResult Function(AgoraError value)? error,
    TResult Function(AgoraEnded value)? ended,
    required TResult orElse(),
  }) {
    final _that = this;
    switch (_that) {
      case AgoraIdle() when idle != null:
        return idle(_that);
      case AgoraJoining() when joining != null:
        return joining(_that);
      case AgoraConnected() when connected != null:
        return connected(_that);
      case AgoraError() when error != null:
        return error(_that);
      case AgoraEnded() when ended != null:
        return ended(_that);
      case _:
        return orElse();
    }
  }

  /// A `switch`-like method, using callbacks.
  ///
  /// Callbacks receives the raw object, upcasted.
  /// It is equivalent to doing:
  /// ```dart
  /// switch (sealedClass) {
  ///   case final Subclass value:
  ///     return ...;
  ///   case final Subclass2 value:
  ///     return ...;
  /// }
  /// ```

  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(AgoraIdle value) idle,
    required TResult Function(AgoraJoining value) joining,
    required TResult Function(AgoraConnected value) connected,
    required TResult Function(AgoraError value) error,
    required TResult Function(AgoraEnded value) ended,
  }) {
    final _that = this;
    switch (_that) {
      case AgoraIdle():
        return idle(_that);
      case AgoraJoining():
        return joining(_that);
      case AgoraConnected():
        return connected(_that);
      case AgoraError():
        return error(_that);
      case AgoraEnded():
        return ended(_that);
    }
  }

  /// A variant of `map` that fallback to returning `null`.
  ///
  /// It is equivalent to doing:
  /// ```dart
  /// switch (sealedClass) {
  ///   case final Subclass value:
  ///     return ...;
  ///   case _:
  ///     return null;
  /// }
  /// ```

  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(AgoraIdle value)? idle,
    TResult? Function(AgoraJoining value)? joining,
    TResult? Function(AgoraConnected value)? connected,
    TResult? Function(AgoraError value)? error,
    TResult? Function(AgoraEnded value)? ended,
  }) {
    final _that = this;
    switch (_that) {
      case AgoraIdle() when idle != null:
        return idle(_that);
      case AgoraJoining() when joining != null:
        return joining(_that);
      case AgoraConnected() when connected != null:
        return connected(_that);
      case AgoraError() when error != null:
        return error(_that);
      case AgoraEnded() when ended != null:
        return ended(_that);
      case _:
        return null;
    }
  }

  /// A variant of `when` that fallback to an `orElse` callback.
  ///
  /// It is equivalent to doing:
  /// ```dart
  /// switch (sealedClass) {
  ///   case Subclass(:final field):
  ///     return ...;
  ///   case _:
  ///     return orElse();
  /// }
  /// ```

  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? idle,
    TResult Function()? joining,
    TResult Function(int localUid, List<int> remoteUids, bool localVideoMuted,
            bool localAudioMuted)?
        connected,
    TResult Function(String message)? error,
    TResult Function()? ended,
    required TResult orElse(),
  }) {
    final _that = this;
    switch (_that) {
      case AgoraIdle() when idle != null:
        return idle();
      case AgoraJoining() when joining != null:
        return joining();
      case AgoraConnected() when connected != null:
        return connected(_that.localUid, _that.remoteUids,
            _that.localVideoMuted, _that.localAudioMuted);
      case AgoraError() when error != null:
        return error(_that.message);
      case AgoraEnded() when ended != null:
        return ended();
      case _:
        return orElse();
    }
  }

  /// A `switch`-like method, using callbacks.
  ///
  /// As opposed to `map`, this offers destructuring.
  /// It is equivalent to doing:
  /// ```dart
  /// switch (sealedClass) {
  ///   case Subclass(:final field):
  ///     return ...;
  ///   case Subclass2(:final field2):
  ///     return ...;
  /// }
  /// ```

  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() idle,
    required TResult Function() joining,
    required TResult Function(int localUid, List<int> remoteUids,
            bool localVideoMuted, bool localAudioMuted)
        connected,
    required TResult Function(String message) error,
    required TResult Function() ended,
  }) {
    final _that = this;
    switch (_that) {
      case AgoraIdle():
        return idle();
      case AgoraJoining():
        return joining();
      case AgoraConnected():
        return connected(_that.localUid, _that.remoteUids,
            _that.localVideoMuted, _that.localAudioMuted);
      case AgoraError():
        return error(_that.message);
      case AgoraEnded():
        return ended();
    }
  }

  /// A variant of `when` that fallback to returning `null`
  ///
  /// It is equivalent to doing:
  /// ```dart
  /// switch (sealedClass) {
  ///   case Subclass(:final field):
  ///     return ...;
  ///   case _:
  ///     return null;
  /// }
  /// ```

  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? idle,
    TResult? Function()? joining,
    TResult? Function(int localUid, List<int> remoteUids, bool localVideoMuted,
            bool localAudioMuted)?
        connected,
    TResult? Function(String message)? error,
    TResult? Function()? ended,
  }) {
    final _that = this;
    switch (_that) {
      case AgoraIdle() when idle != null:
        return idle();
      case AgoraJoining() when joining != null:
        return joining();
      case AgoraConnected() when connected != null:
        return connected(_that.localUid, _that.remoteUids,
            _that.localVideoMuted, _that.localAudioMuted);
      case AgoraError() when error != null:
        return error(_that.message);
      case AgoraEnded() when ended != null:
        return ended();
      case _:
        return null;
    }
  }
}

/// @nodoc

class AgoraIdle with DiagnosticableTreeMixin implements AgoraState {
  const AgoraIdle();

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    properties..add(DiagnosticsProperty('type', 'AgoraState.idle'));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is AgoraIdle);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'AgoraState.idle()';
  }
}

/// @nodoc

class AgoraJoining with DiagnosticableTreeMixin implements AgoraState {
  const AgoraJoining();

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    properties..add(DiagnosticsProperty('type', 'AgoraState.joining'));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is AgoraJoining);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'AgoraState.joining()';
  }
}

/// @nodoc

class AgoraConnected with DiagnosticableTreeMixin implements AgoraState {
  const AgoraConnected(
      {required this.localUid,
      required final List<int> remoteUids,
      this.localVideoMuted = false,
      this.localAudioMuted = false})
      : _remoteUids = remoteUids;

  final int localUid;
  final List<int> _remoteUids;
  List<int> get remoteUids {
    if (_remoteUids is EqualUnmodifiableListView) return _remoteUids;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_remoteUids);
  }

  @JsonKey()
  final bool localVideoMuted;
  @JsonKey()
  final bool localAudioMuted;

  /// Create a copy of AgoraState
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @pragma('vm:prefer-inline')
  $AgoraConnectedCopyWith<AgoraConnected> get copyWith =>
      _$AgoraConnectedCopyWithImpl<AgoraConnected>(this, _$identity);

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    properties
      ..add(DiagnosticsProperty('type', 'AgoraState.connected'))
      ..add(DiagnosticsProperty('localUid', localUid))
      ..add(DiagnosticsProperty('remoteUids', remoteUids))
      ..add(DiagnosticsProperty('localVideoMuted', localVideoMuted))
      ..add(DiagnosticsProperty('localAudioMuted', localAudioMuted));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is AgoraConnected &&
            (identical(other.localUid, localUid) ||
                other.localUid == localUid) &&
            const DeepCollectionEquality()
                .equals(other._remoteUids, _remoteUids) &&
            (identical(other.localVideoMuted, localVideoMuted) ||
                other.localVideoMuted == localVideoMuted) &&
            (identical(other.localAudioMuted, localAudioMuted) ||
                other.localAudioMuted == localAudioMuted));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      localUid,
      const DeepCollectionEquality().hash(_remoteUids),
      localVideoMuted,
      localAudioMuted);

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'AgoraState.connected(localUid: $localUid, remoteUids: $remoteUids, localVideoMuted: $localVideoMuted, localAudioMuted: $localAudioMuted)';
  }
}

/// @nodoc
abstract mixin class $AgoraConnectedCopyWith<$Res>
    implements $AgoraStateCopyWith<$Res> {
  factory $AgoraConnectedCopyWith(
          AgoraConnected value, $Res Function(AgoraConnected) _then) =
      _$AgoraConnectedCopyWithImpl;
  @useResult
  $Res call(
      {int localUid,
      List<int> remoteUids,
      bool localVideoMuted,
      bool localAudioMuted});
}

/// @nodoc
class _$AgoraConnectedCopyWithImpl<$Res>
    implements $AgoraConnectedCopyWith<$Res> {
  _$AgoraConnectedCopyWithImpl(this._self, this._then);

  final AgoraConnected _self;
  final $Res Function(AgoraConnected) _then;

  /// Create a copy of AgoraState
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  $Res call({
    Object? localUid = null,
    Object? remoteUids = null,
    Object? localVideoMuted = null,
    Object? localAudioMuted = null,
  }) {
    return _then(AgoraConnected(
      localUid: null == localUid
          ? _self.localUid
          : localUid // ignore: cast_nullable_to_non_nullable
              as int,
      remoteUids: null == remoteUids
          ? _self._remoteUids
          : remoteUids // ignore: cast_nullable_to_non_nullable
              as List<int>,
      localVideoMuted: null == localVideoMuted
          ? _self.localVideoMuted
          : localVideoMuted // ignore: cast_nullable_to_non_nullable
              as bool,
      localAudioMuted: null == localAudioMuted
          ? _self.localAudioMuted
          : localAudioMuted // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class AgoraError with DiagnosticableTreeMixin implements AgoraState {
  const AgoraError(this.message);

  final String message;

  /// Create a copy of AgoraState
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @pragma('vm:prefer-inline')
  $AgoraErrorCopyWith<AgoraError> get copyWith =>
      _$AgoraErrorCopyWithImpl<AgoraError>(this, _$identity);

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    properties
      ..add(DiagnosticsProperty('type', 'AgoraState.error'))
      ..add(DiagnosticsProperty('message', message));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is AgoraError &&
            (identical(other.message, message) || other.message == message));
  }

  @override
  int get hashCode => Object.hash(runtimeType, message);

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'AgoraState.error(message: $message)';
  }
}

/// @nodoc
abstract mixin class $AgoraErrorCopyWith<$Res>
    implements $AgoraStateCopyWith<$Res> {
  factory $AgoraErrorCopyWith(
          AgoraError value, $Res Function(AgoraError) _then) =
      _$AgoraErrorCopyWithImpl;
  @useResult
  $Res call({String message});
}

/// @nodoc
class _$AgoraErrorCopyWithImpl<$Res> implements $AgoraErrorCopyWith<$Res> {
  _$AgoraErrorCopyWithImpl(this._self, this._then);

  final AgoraError _self;
  final $Res Function(AgoraError) _then;

  /// Create a copy of AgoraState
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  $Res call({
    Object? message = null,
  }) {
    return _then(AgoraError(
      null == message
          ? _self.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class AgoraEnded with DiagnosticableTreeMixin implements AgoraState {
  const AgoraEnded();

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    properties..add(DiagnosticsProperty('type', 'AgoraState.ended'));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is AgoraEnded);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'AgoraState.ended()';
  }
}

// dart format on
