// lib/features/classroom/presentation/providers/whiteboard_provider.dart

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:uuid/uuid.dart';

import '../../../auth/presentation/providers/auth_provider.dart';
import '../../domain/entities/whiteboard_stroke_entity.dart';
import 'classroom_provider.dart';

part 'whiteboard_provider.g.dart';

const kBoardColors = [
  Color(0xFF000000),
  Color(0xFFFFFFFF),
  Color(0xFF2563EB),
  Color(0xFFDC2626),
  Color(0xFF16A34A),
  Color(0xFFF59E0B),
  Color(0xFF7C3AED),
  Color(0xFFDB2777),
];

// ── Stream strokes từ Firestore ───────────────────────────────
@riverpod
Stream<List<WhiteboardStrokeEntity>> boardStrokes(
        Ref ref, String sessionId) =>
    ref.watch(watchStrokesUseCaseProvider).call(sessionId);

// ── State ─────────────────────────────────────────────────────
class WhiteboardState {
  const WhiteboardState({
    this.tool        = WhiteboardTool.pen,
    this.color       = const Color(0xFF000000),
    this.strokeWidth = 3.0,
    this.isSyncing   = false,
  });

  final WhiteboardTool tool;
  final Color color;
  final double strokeWidth;
  final bool isSyncing;

  WhiteboardState copyWith({
    WhiteboardTool? tool,
    Color? color,
    double? strokeWidth,
    bool? isSyncing,
  }) =>
      WhiteboardState(
        tool:        tool        ?? this.tool,
        color:       color       ?? this.color,
        strokeWidth: strokeWidth ?? this.strokeWidth,
        isSyncing:   isSyncing   ?? this.isSyncing,
      );
}

// ── ViewModel ─────────────────────────────────────────────────
@riverpod
class WhiteboardViewModel extends _$WhiteboardViewModel {
  final _uuid = const Uuid();

  // Buffer nét đang vẽ
  final List<Offset> _currentPoints = [];

  // Throttle: chỉ rebuild UI tối đa 60fps
  DateTime _lastNotify = DateTime.fromMillisecondsSinceEpoch(0);
  static const _kThrottle = Duration(milliseconds: 8); // ~120fps // ~60fps

  @override
  WhiteboardState build() => const WhiteboardState();

  void setTool(WhiteboardTool tool) => state = state.copyWith(tool: tool);
  void setColor(Color color) => state = state.copyWith(color: color);
  void setStrokeWidth(double w) => state = state.copyWith(strokeWidth: w);

  // ── Pan start: khởi tạo nét mới ──────────────────────────────
  void onPanStart(Offset point) {
    _currentPoints.clear();
    _currentPoints.add(point);
    _throttledNotify();
  }

  // ── Pan update: thêm điểm, notify có throttle ─────────────────
  void onPanUpdate(Offset point) {
    if (_currentPoints.isEmpty) {
      _currentPoints.add(point);
    } else {
      // Bỏ qua điểm quá gần (< 2px) để giảm noise
      final last = _currentPoints.last;
      final dx = point.dx - last.dx;
      final dy = point.dy - last.dy;
      if (dx * dx + dy * dy < 4.0) return;
      _currentPoints.add(point);
    }
    _throttledNotify();
  }

  void _throttledNotify() {
    final now = DateTime.now();
    if (now.difference(_lastNotify) >= _kThrottle) {
      _lastNotify = now;
      // Trigger rebuild bằng cách emit state mới (giữ nguyên data)
      state = state.copyWith();
    }
  }

  // ── Pan end: sync lên Firestore ───────────────────────────────
  Future<void> onPanEnd(String sessionId) async {
    if (_currentPoints.length < 2) {
      _currentPoints.clear();
      return;
    }

    final user = ref.read(authStateStreamProvider).value;
    if (user == null) {
      _currentPoints.clear();
      return;
    }

    // Tính color + width tuỳ tool
    final Color drawColor;
    final double drawWidth;

    switch (state.tool) {
      case WhiteboardTool.eraser:
        drawColor = const Color(0xFFFFFFFF);
        drawWidth = state.strokeWidth * 4; // tẩy rộng hơn
      case WhiteboardTool.highlighter:
        drawColor = state.color.withOpacity(0.4);
        drawWidth = state.strokeWidth * 3;
      default:
        drawColor = state.color;
        drawWidth = state.strokeWidth;
    }

    final stroke = WhiteboardStrokeEntity(
      strokeId:    _uuid.v4(),
      sessionId:   sessionId,
      authorId:    user.id,
      points:      List.of(_currentPoints),
      color:       drawColor,
      strokeWidth: drawWidth,
      tool:        state.tool,
      createdAt:   DateTime.now(),
    );

    _currentPoints.clear();
    state = state.copyWith(isSyncing: true);

    try {
      await ref.read(addStrokeUseCaseProvider).call(stroke);
    } finally {
      state = state.copyWith(isSyncing: false);
    }
  }

  Future<void> clearBoard(String sessionId) =>
      ref.read(clearBoardUseCaseProvider).call(sessionId);

  List<Offset> get currentStrokePoints => List.unmodifiable(_currentPoints);
}
