import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../core/di/firebase_providers.dart';
import '../../data/repositories/classroom_repository_impl.dart';
import '../../domain/repositories/classroom_repository.dart';
import '../../domain/usecases/classroom_usecases.dart';

part 'classroom_provider.freezed.dart';
part 'classroom_provider.g.dart';

@Riverpod(keepAlive: true)
ClassroomRepository classroomRepository(Ref ref) =>
    ClassroomRepositoryImpl(ref.read(firebaseFirestoreProvider));

@riverpod
WatchStrokesUseCase watchStrokesUseCase(Ref ref) =>
    WatchStrokesUseCase(ref.read(classroomRepositoryProvider));

@riverpod
AddStrokeUseCase addStrokeUseCase(Ref ref) =>
    AddStrokeUseCase(ref.read(classroomRepositoryProvider));

@riverpod
ClearBoardUseCase clearBoardUseCase(Ref ref) =>
    ClearBoardUseCase(ref.read(classroomRepositoryProvider));

@riverpod
UpdateSessionStatusUseCase updateSessionStatusUseCase(Ref ref) =>
    UpdateSessionStatusUseCase(ref.read(classroomRepositoryProvider));

// ── Agora State ───────────────────────────────────────────────
@freezed
sealed class AgoraState with _$AgoraState {
  const factory AgoraState.idle()    = AgoraIdle;
  const factory AgoraState.joining() = AgoraJoining;
  const factory AgoraState.connected({
    required int localUid,
    required List<int> remoteUids,
    @Default(false) bool localVideoMuted,
    @Default(false) bool localAudioMuted,
  }) = AgoraConnected;
  const factory AgoraState.error(String message) = AgoraError;
  const factory AgoraState.ended()               = AgoraEnded;
}

// ── Session meta (permission, screen share...) ────────────────
@riverpod
class ClassroomSession extends _$ClassroomSession {
  @override
  _SessionMeta build() => const _SessionMeta();

  void setStudentCanDraw(bool v) =>
      state = state.copyWith(studentCanDraw: v);

  void toggleStudentDraw() =>
      state = state.copyWith(studentCanDraw: !state.studentCanDraw);

  void setScreenSharing(bool v) =>
      state = state.copyWith(isScreenSharing: v);
}

class _SessionMeta {
  const _SessionMeta({
    this.studentCanDraw  = false,
    this.isScreenSharing = false,
  });
  final bool studentCanDraw;
  final bool isScreenSharing;

  _SessionMeta copyWith({bool? studentCanDraw, bool? isScreenSharing}) =>
      _SessionMeta(
        studentCanDraw:  studentCanDraw  ?? this.studentCanDraw,
        isScreenSharing: isScreenSharing ?? this.isScreenSharing,
      );
}

// ── Classroom ViewModel ───────────────────────────────────────
@riverpod
class ClassroomViewModel extends _$ClassroomViewModel {
  RtcEngine? _engine;
  String _channelName = '';

  @override
  AgoraState build() => const AgoraState.idle();

  Future<void> joinRoom({
    required String channelName,
    required String sessionId,
    required bool isTeacher,
  }) async {
    _channelName = channelName;
    state = const AgoraState.joining();
    try {
      _engine = createAgoraRtcEngine();
      await _engine!.initialize(RtcEngineContext(
        appId: AppConstants.agoraAppId,
        channelProfile: ChannelProfileType.channelProfileCommunication,
      ));

      await _engine!.enableVideo();
      await _engine!.enableAudio();

      // FIX web: startPreview crash trên Flutter Web
      if (!kIsWeb) {
        await _engine!.startPreview();
      }

      _engine!.registerEventHandler(RtcEngineEventHandler(
        onJoinChannelSuccess: (connection, elapsed) {
          state = AgoraState.connected(
            localUid:        connection.localUid ?? 0,
            remoteUids:      const [],
            localVideoMuted: false,
            localAudioMuted: false,
          );
        },
        onUserJoined: (connection, remoteUid, elapsed) {
          final cur = state;
          if (cur is AgoraConnected) {
            state = cur.copyWith(
                remoteUids: [...cur.remoteUids, remoteUid]);
          }
        },
        onUserOffline: (connection, remoteUid, reason) {
          final cur = state;
          if (cur is AgoraConnected) {
            state = cur.copyWith(
                remoteUids: cur.remoteUids
                    .where((id) => id != remoteUid)
                    .toList());
          }
        },
        onError: (err, msg) {
          // Minor errors (mic emulator, etc.) — chỉ log
          debugPrint('Agora onError $err: $msg');
        },
      ));

      await _engine!.joinChannel(
        token:     '',
        channelId: channelName,
        uid:       0,
        options:   const ChannelMediaOptions(
          clientRoleType: ClientRoleType.clientRoleBroadcaster,
          channelProfile: ChannelProfileType.channelProfileCommunication,
        ),
      );

      // Lưu Firestore presence
      await _writePresence(sessionId, isTeacher);

      await ref
          .read(updateSessionStatusUseCaseProvider)
          .call(sessionId, 'ongoing');
    } catch (e) {
      state = AgoraState.error(e.toString());
    }
  }

  Future<void> _writePresence(String sessionId, bool isTeacher) async {
    try {
      final uid = (state is AgoraConnected)
          ? (state as AgoraConnected).localUid
          : 0;
      await ref
          .read(firebaseFirestoreProvider)
          .collection('sessions')
          .doc(sessionId)
          .collection('presence')
          .doc(uid.toString())
          .set({
        'uid':       uid,
        'isTeacher': isTeacher,
        'joinedAt':  FieldValue.serverTimestamp(),
      });
    } catch (_) {}
  }

  Future<void> toggleVideo() async {
    final cur = state;
    if (cur is! AgoraConnected) return;
    final muted = !cur.localVideoMuted;
    await _engine?.muteLocalVideoStream(muted);
    if (!kIsWeb) await _engine?.enableLocalVideo(!muted);
    state = cur.copyWith(localVideoMuted: muted);
  }

  Future<void> toggleAudio() async {
    final cur = state;
    if (cur is! AgoraConnected) return;
    final muted = !cur.localAudioMuted;
    await _engine?.muteLocalAudioStream(muted);
    await _engine?.enableLocalAudio(!muted);
    state = cur.copyWith(localAudioMuted: muted);
  }

  Future<void> startScreenShare() async {
    if (kIsWeb) {
      // Web: dùng Agora Web SDK screen share
      try {
        await _engine?.startScreenCapture(const ScreenCaptureParameters2(
          captureAudio: true,
          captureVideo: true,
        ));
        ref.read(classroomSessionProvider.notifier).setScreenSharing(true);
      } catch (e) {
        debugPrint('Screen share not supported (web): $e');
      }
    } else {
      try {
        await _engine?.startScreenCapture(const ScreenCaptureParameters2(
          captureAudio: true,
          captureVideo: true,
        ));
        await _engine?.updateChannelMediaOptions(const ChannelMediaOptions(
          publishScreenTrack: true,
          publishCameraTrack: false,
        ));
        ref.read(classroomSessionProvider.notifier).setScreenSharing(true);
      } catch (e) {
        debugPrint('Screen share not supported: $e');
      }
    }
  }

  Future<void> stopScreenShare() async {
    try {
      await _engine?.stopScreenCapture();
      if (!kIsWeb) {
        await _engine?.updateChannelMediaOptions(const ChannelMediaOptions(
          publishScreenTrack: false,
          publishCameraTrack: true,
        ));
      }
      ref.read(classroomSessionProvider.notifier).setScreenSharing(false);
    } catch (_) {
      ref.read(classroomSessionProvider.notifier).setScreenSharing(false);
    }
  }

  Future<void> leaveRoom(String sessionId) async {
    await _engine?.leaveChannel();
    await _engine?.release();
    _engine = null;
    await ref
        .read(updateSessionStatusUseCaseProvider)
        .call(sessionId, 'completed');
    state = const AgoraState.ended();
  }

  RtcEngine? get engine      => _engine;
  String     get channelName => _channelName;
}
