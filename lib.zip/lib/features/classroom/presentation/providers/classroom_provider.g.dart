// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'classroom_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(classroomRepository)
const classroomRepositoryProvider = ClassroomRepositoryProvider._();

final class ClassroomRepositoryProvider extends $FunctionalProvider<
    ClassroomRepository,
    ClassroomRepository,
    ClassroomRepository> with $Provider<ClassroomRepository> {
  const ClassroomRepositoryProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'classroomRepositoryProvider',
          isAutoDispose: false,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$classroomRepositoryHash();

  @$internal
  @override
  $ProviderElement<ClassroomRepository> $createElement(
          $ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  ClassroomRepository create(Ref ref) {
    return classroomRepository(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ClassroomRepository value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ClassroomRepository>(value),
    );
  }
}

String _$classroomRepositoryHash() =>
    r'c5b53e5903be33608ae9d6385b9c72b92a982c1b';

@ProviderFor(watchStrokesUseCase)
const watchStrokesUseCaseProvider = WatchStrokesUseCaseProvider._();

final class WatchStrokesUseCaseProvider extends $FunctionalProvider<
    WatchStrokesUseCase,
    WatchStrokesUseCase,
    WatchStrokesUseCase> with $Provider<WatchStrokesUseCase> {
  const WatchStrokesUseCaseProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'watchStrokesUseCaseProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$watchStrokesUseCaseHash();

  @$internal
  @override
  $ProviderElement<WatchStrokesUseCase> $createElement(
          $ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  WatchStrokesUseCase create(Ref ref) {
    return watchStrokesUseCase(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(WatchStrokesUseCase value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<WatchStrokesUseCase>(value),
    );
  }
}

String _$watchStrokesUseCaseHash() =>
    r'8c7d71613655fb42716096ea2a6d02b6ccd6fd7f';

@ProviderFor(addStrokeUseCase)
const addStrokeUseCaseProvider = AddStrokeUseCaseProvider._();

final class AddStrokeUseCaseProvider extends $FunctionalProvider<
    AddStrokeUseCase,
    AddStrokeUseCase,
    AddStrokeUseCase> with $Provider<AddStrokeUseCase> {
  const AddStrokeUseCaseProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'addStrokeUseCaseProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$addStrokeUseCaseHash();

  @$internal
  @override
  $ProviderElement<AddStrokeUseCase> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  AddStrokeUseCase create(Ref ref) {
    return addStrokeUseCase(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AddStrokeUseCase value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AddStrokeUseCase>(value),
    );
  }
}

String _$addStrokeUseCaseHash() => r'55db576e1697663a0274723e6a90ae369779a782';

@ProviderFor(clearBoardUseCase)
const clearBoardUseCaseProvider = ClearBoardUseCaseProvider._();

final class ClearBoardUseCaseProvider extends $FunctionalProvider<
    ClearBoardUseCase,
    ClearBoardUseCase,
    ClearBoardUseCase> with $Provider<ClearBoardUseCase> {
  const ClearBoardUseCaseProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'clearBoardUseCaseProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$clearBoardUseCaseHash();

  @$internal
  @override
  $ProviderElement<ClearBoardUseCase> $createElement(
          $ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  ClearBoardUseCase create(Ref ref) {
    return clearBoardUseCase(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ClearBoardUseCase value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ClearBoardUseCase>(value),
    );
  }
}

String _$clearBoardUseCaseHash() => r'2e59874fd8c158d73ee7a8e53493a6fb6a182fcb';

@ProviderFor(updateSessionStatusUseCase)
const updateSessionStatusUseCaseProvider =
    UpdateSessionStatusUseCaseProvider._();

final class UpdateSessionStatusUseCaseProvider extends $FunctionalProvider<
    UpdateSessionStatusUseCase,
    UpdateSessionStatusUseCase,
    UpdateSessionStatusUseCase> with $Provider<UpdateSessionStatusUseCase> {
  const UpdateSessionStatusUseCaseProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'updateSessionStatusUseCaseProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$updateSessionStatusUseCaseHash();

  @$internal
  @override
  $ProviderElement<UpdateSessionStatusUseCase> $createElement(
          $ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  UpdateSessionStatusUseCase create(Ref ref) {
    return updateSessionStatusUseCase(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(UpdateSessionStatusUseCase value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<UpdateSessionStatusUseCase>(value),
    );
  }
}

String _$updateSessionStatusUseCaseHash() =>
    r'3f37885145bf5c026f782c9f7c4f13d824c9c9e6';

@ProviderFor(ClassroomSession)
const classroomSessionProvider = ClassroomSessionProvider._();

final class ClassroomSessionProvider
    extends $NotifierProvider<ClassroomSession, _SessionMeta> {
  const ClassroomSessionProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'classroomSessionProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$classroomSessionHash();

  @$internal
  @override
  ClassroomSession create() => ClassroomSession();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(_SessionMeta value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<_SessionMeta>(value),
    );
  }
}

String _$classroomSessionHash() => r'8343c3ef550f46e6667efd2792827cd05ae1a2e2';

abstract class _$ClassroomSession extends $Notifier<_SessionMeta> {
  _SessionMeta build();
  @$mustCallSuper
  @override
  void runBuild() {
    final created = build();
    final ref = this.ref as $Ref<_SessionMeta, _SessionMeta>;
    final element = ref.element as $ClassProviderElement<
        AnyNotifier<_SessionMeta, _SessionMeta>,
        _SessionMeta,
        Object?,
        Object?>;
    element.handleValue(ref, created);
  }
}

@ProviderFor(ClassroomViewModel)
const classroomViewModelProvider = ClassroomViewModelProvider._();

final class ClassroomViewModelProvider
    extends $NotifierProvider<ClassroomViewModel, AgoraState> {
  const ClassroomViewModelProvider._()
      : super(
          from: null,
          argument: null,
          retry: null,
          name: r'classroomViewModelProvider',
          isAutoDispose: true,
          dependencies: null,
          $allTransitiveDependencies: null,
        );

  @override
  String debugGetCreateSourceHash() => _$classroomViewModelHash();

  @$internal
  @override
  ClassroomViewModel create() => ClassroomViewModel();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AgoraState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AgoraState>(value),
    );
  }
}

String _$classroomViewModelHash() =>
    r'1761a00640c5b399b8737acfef59b9268f2d1cd3';

abstract class _$ClassroomViewModel extends $Notifier<AgoraState> {
  AgoraState build();
  @$mustCallSuper
  @override
  void runBuild() {
    final created = build();
    final ref = this.ref as $Ref<AgoraState, AgoraState>;
    final element = ref.element as $ClassProviderElement<
        AnyNotifier<AgoraState, AgoraState>, AgoraState, Object?, Object?>;
    element.handleValue(ref, created);
  }
}
