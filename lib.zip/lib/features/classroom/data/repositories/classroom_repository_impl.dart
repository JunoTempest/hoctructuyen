import 'package:cloud_firestore/cloud_firestore.dart';

import '../../domain/entities/whiteboard_stroke_entity.dart';
import '../../domain/repositories/classroom_repository.dart';
import '../models/whiteboard_model.dart';

class ClassroomRepositoryImpl implements ClassroomRepository {
  ClassroomRepositoryImpl(this._db);
  final FirebaseFirestore _db;

  // ── Firestore paths ───────────────────────────────────────────
  CollectionReference<Map<String, dynamic>> _strokesCol(String sessionId) =>
      _db.collection('sessions').doc(sessionId).collection('strokes');

  DocumentReference<Map<String, dynamic>> _sessionDoc(String sessionId) =>
      _db.collection('sessions').doc(sessionId);

  // ── Whiteboard ────────────────────────────────────────────────
  @override
  Stream<List<WhiteboardStrokeEntity>> watchStrokes(String sessionId) =>
      _strokesCol(sessionId)
          .snapshots()
          .map((s) {
            final list = s.docs
                .map((d) => WhiteboardStrokeModel.fromFirestore(d).toEntity())
                .toList();
            // Sort client-side để tránh Firestore composite index error
            list.sort((a, b) => a.createdAt.compareTo(b.createdAt));
            return list;
          });

  @override
  Future<void> addStroke(WhiteboardStrokeEntity stroke) async {
    final model = WhiteboardStrokeModel.fromEntity(stroke);
    await _strokesCol(stroke.sessionId)
        .doc(stroke.strokeId)
        .set(model.toFirestore());
  }

  @override
  Future<void> clearBoard(String sessionId) async {
    // Xoá theo batch để tránh vượt giới hạn 500 docs/batch
    const batchSize = 400;
    while (true) {
      final snap =
          await _strokesCol(sessionId).limit(batchSize).get();
      if (snap.docs.isEmpty) break;
      final batch = _db.batch();
      for (final doc in snap.docs) {
        batch.delete(doc.reference);
      }
      await batch.commit();
    }
  }

  @override
  Future<void> updateSessionStatus(String sessionId, String status) =>
      _sessionDoc(sessionId).update({'status': status});
}
