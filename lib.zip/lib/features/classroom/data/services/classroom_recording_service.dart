// lib/features/classroom/data/services/classroom_recording_service.dart
//
// Agora Cloud Recording – gọi qua Firebase Cloud Functions để bảo vệ credentials.
//
// ═══════════════════════════════════════════════════════════════
//  SETUP (1 lần duy nhất):
//  1. Agora Console → Project → Cloud Recording → bật lên
//  2. Agora Console → RESTful API → tạo Customer ID + Secret
//  3. Firebase Console → Functions → deploy functions/index.js (xem bên dưới)
//  4. Chọn nơi lưu file: Agora hỗ trợ AWS S3, Alibaba OSS, Google GCS
//     → Đơn giản nhất: dùng Agora Storage (agora.io/cloud-recording-storage)
//     hoặc Google Cloud Storage bucket của project Firebase
// ═══════════════════════════════════════════════════════════════

import 'dart:convert';
import 'package:http/http.dart' as http;

// ── Cloud Function URLs (deploy từ functions/index.js) ───────
// Đổi thành URL thực sau khi deploy
const _kFunctionsBase =
    'https://YOUR_REGION-YOUR_PROJECT.cloudfunctions.net';

class ClassroomRecordingService {
  ClassroomRecordingService._();
  static final instance = ClassroomRecordingService._();

  String? _resourceId;
  String? _sid;

  bool get isRecording => _sid != null;

  // ── Acquire → Start ──────────────────────────────────────────

  Future<({String resourceId, String sid})?> startRecording({
    required String channelName,
    required String uid, // UID dùng cho recorder bot (ví dụ "12345")
  }) async {
    try {
      // 1. Acquire resource
      final acquireRes = await http.post(
        Uri.parse('$_kFunctionsBase/acquireRecording'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'channelName': channelName, 'uid': uid}),
      );
      if (acquireRes.statusCode != 200) return null;
      final acquireData = jsonDecode(acquireRes.body) as Map<String, dynamic>;
      _resourceId = acquireData['resourceId'] as String;

      // 2. Start recording
      final startRes = await http.post(
        Uri.parse('$_kFunctionsBase/startRecording'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'channelName': channelName,
          'uid': uid,
          'resourceId': _resourceId,
        }),
      );
      if (startRes.statusCode != 200) return null;
      final startData = jsonDecode(startRes.body) as Map<String, dynamic>;
      _sid = startData['sid'] as String;

      return (resourceId: _resourceId!, sid: _sid!);
    } catch (_) {
      return null;
    }
  }

  // ── Stop ─────────────────────────────────────────────────────

  Future<String?> stopRecording({
    required String channelName,
    required String uid,
  }) async {
    if (_resourceId == null || _sid == null) return null;
    try {
      final res = await http.post(
        Uri.parse('$_kFunctionsBase/stopRecording'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'channelName': channelName,
          'uid': uid,
          'resourceId': _resourceId,
          'sid': _sid,
        }),
      );
      _resourceId = null;
      _sid = null;
      if (res.statusCode != 200) return null;
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      // Trả về URL file recording nếu có
      return data['fileUrl'] as String?;
    } catch (_) {
      _resourceId = null;
      _sid = null;
      return null;
    }
  }
}

/*
══════════════════════════════════════════════════════════════════
  Firebase Cloud Functions – functions/index.js
  Deploy: firebase deploy --only functions

  Thay YOUR_AGORA_* bằng giá trị thật từ Agora Console.
══════════════════════════════════════════════════════════════════

const functions = require("firebase-functions");
const axios = require("axios");

const AGORA_APP_ID      = "YOUR_AGORA_APP_ID";
const AGORA_CUSTOMER_ID = "YOUR_CUSTOMER_ID";      // RESTful API
const AGORA_CUSTOMER_SECRET = "YOUR_CUSTOMER_SECRET";

// Nơi lưu recording – Google Cloud Storage bucket của Firebase
const STORAGE_CONFIG = {
  vendor: 3,          // 3 = Google Cloud Storage
  region: 0,
  bucket: "YOUR_GCS_BUCKET",          // e.g. "my-project.appspot.com"
  accessKey: "YOUR_GCS_HMAC_ACCESS_KEY",
  secretKey: "YOUR_GCS_HMAC_SECRET",
  fileNamePrefix: ["recordings"],
};

const authHeader = Buffer.from(
  `${AGORA_CUSTOMER_ID}:${AGORA_CUSTOMER_SECRET}`
).toString("base64");

const agoraApi = axios.create({
  baseURL: `https://api.agora.io/v1/apps/${AGORA_APP_ID}`,
  headers: { Authorization: `Basic ${authHeader}` },
});

// ── Acquire ──────────────────────────────────────────────────
exports.acquireRecording = functions.https.onRequest(async (req, res) => {
  const { channelName, uid } = req.body;
  const r = await agoraApi.post("/cloud_recording/acquire", {
    cname: channelName,
    uid,
    clientRequest: { resourceExpiredHour: 24 },
  });
  res.json({ resourceId: r.data.resourceId });
});

// ── Start ────────────────────────────────────────────────────
exports.startRecording = functions.https.onRequest(async (req, res) => {
  const { channelName, uid, resourceId } = req.body;
  const r = await agoraApi.post(
    `/cloud_recording/resourceid/${resourceId}/mode/mix/start`,
    {
      cname: channelName,
      uid,
      clientRequest: {
        token: "",           // dùng token nếu project có bật token
        recordingConfig: {
          maxIdleTime: 30,
          streamTypes: 2,    // 0=audio, 1=video, 2=both
          channelType: 0,
          videoStreamType: 0,
          transcodingConfig: {
            height: 720, width: 1280,
            bitrate: 1500, fps: 15,
            mixedVideoLayout: 1,
          },
        },
        storageConfig: STORAGE_CONFIG,
      },
    }
  );
  res.json({ sid: r.data.sid });
});

// ── Stop ─────────────────────────────────────────────────────
exports.stopRecording = functions.https.onRequest(async (req, res) => {
  const { channelName, uid, resourceId, sid } = req.body;
  const r = await agoraApi.post(
    `/cloud_recording/resourceid/${resourceId}/sid/${sid}/mode/mix/stop`,
    { cname: channelName, uid, clientRequest: {} }
  );
  // Lấy URL file từ GCS
  const files = r.data?.serverResponse?.fileList ?? [];
  const fileUrl = files.length > 0
    ? `https://storage.googleapis.com/${STORAGE_CONFIG.bucket}/recordings/${files[0].fileName}`
    : null;
  res.json({ fileUrl, files });
});
*/
