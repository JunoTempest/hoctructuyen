import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../../domain/entities/whiteboard_stroke_entity.dart';

class WhiteboardStrokeModel {
  const WhiteboardStrokeModel({
    required this.strokeId,
    required this.sessionId,
    required this.authorId,
    required this.points,
    required this.colorValue,
    required this.strokeWidth,
    required this.tool,
    required this.createdAt,
  });

  final String strokeId;
  final String sessionId;
  final String authorId;
  final List<Map<String, double>> points; // [{x, y}, ...]
  final int colorValue;
  final double strokeWidth;
  final String tool;
  final DateTime createdAt;

  factory WhiteboardStrokeModel.fromFirestore(
      DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data()!;
    return WhiteboardStrokeModel(
      strokeId:    doc.id,
      sessionId:   d['sessionId'] as String,
      authorId:    d['authorId'] as String,
      points:      (d['points'] as List<dynamic>)
          .map((p) => Map<String, double>.from(p as Map))
          .toList(),
      colorValue:  d['colorValue'] as int,
      strokeWidth: (d['strokeWidth'] as num).toDouble(),
      tool:        d['tool'] as String,
      createdAt:   (d['createdAt'] as Timestamp).toDate(),
    );
  }

  Map<String, dynamic> toFirestore() => {
        'sessionId':   sessionId,
        'authorId':    authorId,
        'points':      points,
        'colorValue':  colorValue,
        'strokeWidth': strokeWidth,
        'tool':        tool,
        'createdAt':   Timestamp.fromDate(createdAt),
      };

  WhiteboardStrokeEntity toEntity() => WhiteboardStrokeEntity(
        strokeId:    strokeId,
        sessionId:   sessionId,
        authorId:    authorId,
        points:      points.map((p) => Offset(p['x']!, p['y']!)).toList(),
        color:       Color(colorValue),
        strokeWidth: strokeWidth,
        tool:        WhiteboardToolX.fromString(tool),
        createdAt:   createdAt,
      );

  static WhiteboardStrokeModel fromEntity(WhiteboardStrokeEntity e) =>
      WhiteboardStrokeModel(
        strokeId:    e.strokeId,
        sessionId:   e.sessionId,
        authorId:    e.authorId,
        points:      e.points.map((o) => {'x': o.dx, 'y': o.dy}).toList(),
        colorValue:  e.color.value,
        strokeWidth: e.strokeWidth,
        tool:        e.tool.name,
        createdAt:   e.createdAt,
      );
}

extension WhiteboardToolX on WhiteboardTool {
  static WhiteboardTool fromString(String s) => switch (s) {
        'highlighter' => WhiteboardTool.highlighter,
        'eraser'      => WhiteboardTool.eraser,
        'laser'       => WhiteboardTool.laser,
        _             => WhiteboardTool.pen,
      };
}
